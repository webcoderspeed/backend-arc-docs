// ─── Rate Limit Decorators ─────────────────────────────────────────────
// Per-endpoint rate limit tiers and plan-based limits.
// Works alongside NestJS @nestjs/throttler for enforcement.

import { SetMetadata } from '@nestjs/common';

// ─── Rate Limit Tier Metadata ──────────────────────────────────────────

export const RATE_LIMIT_TIER_KEY = 'rate_limit_tier';

export type RateLimitTier =
  | 'auth'
  | 'general'
  | 'readonly'
  | 'heavy'
  | 'custom';

export interface RateLimitTierConfig {
  /** Tier name for identification */
  tier: RateLimitTier;
  /** Max requests in the window */
  limit: number;
  /** Time window in seconds */
  windowSeconds: number;
}

/** Pre-defined rate limit tiers */
export const RATE_LIMIT_TIERS: Record<RateLimitTier, RateLimitTierConfig> = {
  /** Authentication endpoints: 10 requests/minute */
  auth: { tier: 'auth', limit: 10, windowSeconds: 60 },
  /** General API: 100 requests/minute */
  general: { tier: 'general', limit: 100, windowSeconds: 60 },
  /** Read-only endpoints: 1000 requests/minute */
  readonly: { tier: 'readonly', limit: 1000, windowSeconds: 60 },
  /** Heavy operations: 5 requests/minute */
  heavy: { tier: 'heavy', limit: 5, windowSeconds: 60 },
  /** Custom — overridden by decorator params */
  custom: { tier: 'custom', limit: 100, windowSeconds: 60 },
} as const;

/**
 * Set the rate limit tier for an endpoint.
 *
 * @example
 * ```typescript
 * @Post('login')
 * @RateLimitTier('auth')  // 10 req/min
 * async login(@Body() dto: LoginDto) { ... }
 *
 * @Get('leads')
 * @RateLimitTier('readonly')  // 1000 req/min
 * async findAll() { ... }
 *
 * @Post('export')
 * @RateLimitTier('heavy')  // 5 req/min
 * async export(@Body() dto: ExportDto) { ... }
 * ```
 */
export const RateLimitTierDecorator = (tier: RateLimitTier) =>
  SetMetadata(RATE_LIMIT_TIER_KEY, RATE_LIMIT_TIERS[tier]);

// ─── Plan-Based Rate Limit ─────────────────────────────────────────────

export const PLAN_BASED_RATE_LIMIT_KEY = 'plan_based_rate_limit';

export interface PlanBasedRateLimitOptions {
  /** Multiplier applied to the base tier limit based on user plan */
  planMultipliers?: {
    free: number;
    starter: number;
    professional: number;
    enterprise: number;
  };
}

const DEFAULT_PLAN_MULTIPLIERS = {
  free: 0.5, // 50% of base limit
  starter: 1.0, // 100% of base limit
  professional: 2.0, // 200% of base limit
  enterprise: 5.0, // 500% of base limit
};

/**
 * Mark an endpoint to use plan-based rate limiting.
 * The rate limit is determined by the user's subscription plan.
 *
 * @example
 * ```typescript
 * @Get('automations')
 * @PlanBasedRateLimit()
 * async findAll() { ... }
 *
 * @Post('automations')
 * @PlanBasedRateLimit({ planMultipliers: { free: 0.2, starter: 0.5, professional: 1, enterprise: 3 } })
 * async create() { ... }
 * ```
 */
export const PlanBasedRateLimit = (options?: PlanBasedRateLimitOptions) =>
  SetMetadata(PLAN_BASED_RATE_LIMIT_KEY, {
    planMultipliers: options?.planMultipliers ?? DEFAULT_PLAN_MULTIPLIERS,
  });
