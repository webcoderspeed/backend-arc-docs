import { SetMetadata } from '@nestjs/common';
import type { UserRoleType } from '../database';

export const ROLES_KEY = 'roles';

export const Roles = (...roles: UserRoleType[]) =>
  SetMetadata(ROLES_KEY, roles);
