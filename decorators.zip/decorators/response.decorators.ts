// ─── Response Type Decorators ──────────────────────────────────────────
// Mark controller methods with their expected response type.
// The ResponseInterceptor reads this metadata to set correct HTTP status codes.

import { SetMetadata } from '@nestjs/common';
import {
  RESPONSE_TYPE_KEY,
  type ResponseType,
} from '../contracts/responses/base.response';

/**
 * Marks a controller method as returning a specific response type.
 * The ResponseInterceptor uses this to set the correct HTTP status code and headers.
 *
 * @example
 * ```typescript
 * @Post()
 * @ResponseTypeDecorator('created')
 * async create(@Body() dto: CreateAutomationDto) {
 *   const automation = await this.service.create(dto);
 *   return ResponseBuilder.created(automation, `/api/v1/automations/${automation.id}`);
 * }
 *
 * @Delete(':id')
 * @ResponseTypeDecorator('no-content')
 * async remove(@Param('id') id: string) {
 *   await this.service.remove(id);
 *   return ResponseBuilder.noContent();
 * }
 *
 * @Post('batch-delete')
 * @ResponseTypeDecorator('multi-status')
 * async batchDelete(@Body() dto: BatchDeleteDto) {
 *   const results = await this.bulkRunner.execute(dto.ids);
 *   return ResponseBuilder.multiStatus(results);
 * }
 * ```
 */
export const ResponseTypeDecorator = (type: ResponseType) =>
  SetMetadata(RESPONSE_TYPE_KEY, type);
