import { createParamDecorator, type ExecutionContext } from '@nestjs/common';
import type { UserRoleType } from '../database';

declare global {
  interface Request {
    user: UserSession;
  }
}

export interface UserSession {
  sub: string;
  email: string;
  role?: UserRoleType;
  iat?: number;
  exp?: number;
  sessionId?: string;
}

export const UserSession = createParamDecorator(
  (_: unknown, context: ExecutionContext): UserSession => {
    const request = context.switchToHttp().getRequest<Request>();
    return request.user;
  },
);
