// ─── @CacheControl() Decorator ─────────────────────────────────────────
// Sets Cache-Control headers on GET responses.
// Applied per-endpoint to control client and proxy caching behavior.
//
// Usage:
//   @Get('packages')
//   @CacheControl({ maxAge: 300, public: true })    // 5min, shared caches OK
//   async getPackages() { ... }
//
//   @Get('profile')
//   @CacheControl({ maxAge: 0, private: true, mustRevalidate: true })  // No caching
//   async getProfile() { ... }
//
//   @Post('orders')
//   @CacheControl({ noStore: true })  // Never cache mutations
//   async createOrder() { ... }

import { SetMetadata } from '@nestjs/common';

export const CACHE_CONTROL_KEY = 'cache_control';

export interface CacheControlOptions {
  /** Max age in seconds (how long the response is fresh) */
  maxAge?: number;

  /** If true, only the user's browser can cache (not CDN/proxy) */
  private?: boolean;

  /** If true, CDNs and proxies can cache */
  public?: boolean;

  /** If true, cache must revalidate with server before serving stale content */
  mustRevalidate?: boolean;

  /** If true, response must never be stored (for sensitive data) */
  noStore?: boolean;

  /** If true, response must not be served from cache without revalidation */
  noCache?: boolean;

  /** Shared max-age: max age specifically for shared caches (CDN/proxy) */
  sMaxAge?: number;
}

/**
 * Builds the Cache-Control header value from options.
 */
export function buildCacheControlHeader(options: CacheControlOptions): string {
  const directives: string[] = [];

  if (options.noStore) {
    directives.push('no-store');
    return directives.join(', ');
  }

  if (options.noCache) {
    directives.push('no-cache');
  }

  if (options.private) {
    directives.push('private');
  } else if (options.public) {
    directives.push('public');
  }

  if (options.maxAge !== undefined) {
    directives.push(`max-age=${options.maxAge}`);
  }

  if (options.sMaxAge !== undefined) {
    directives.push(`s-maxage=${options.sMaxAge}`);
  }

  if (options.mustRevalidate) {
    directives.push('must-revalidate');
  }

  // Default if nothing was set
  if (directives.length === 0) {
    return 'private, max-age=0, must-revalidate';
  }

  return directives.join(', ');
}

/**
 * Sets Cache-Control headers on the endpoint response.
 * The CacheControlInterceptor (or ResponseInterceptor) reads this metadata
 * and applies the headers.
 *
 * @example
 * ```typescript
 * @Get('packages')
 * @CacheControl({ maxAge: 300, public: true })
 * async getPackages() { ... }
 * ```
 */
export const CacheControl = (options: CacheControlOptions) =>
  SetMetadata(CACHE_CONTROL_KEY, options);
