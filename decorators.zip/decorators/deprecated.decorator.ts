// ─── @Deprecated() Decorator ───────────────────────────────────────────
// Marks an endpoint as deprecated and adds standard headers:
//   Deprecation: true
//   Sunset: <RFC 7231 date>
//   Link: </api/v2/resource>; rel="successor-version"
//   X-Deprecation-Notice: <message>
//
// Usage:
//   @Get()
//   @Deprecated({
//     sunset: '2026-06-01',
//     successor: '/api/v2/automations',
//     message: 'Use /api/v2/automations instead.',
//   })
//   async findAll() { ... }

import { SetMetadata } from '@nestjs/common';
import { RESPONSE_CONSTANTS } from '../contracts/responses/base.response';

export const DEPRECATED_KEY = 'deprecated_endpoint';

export interface DeprecatedOptions {
  /** Date when the endpoint will be removed (ISO 8601 date string, e.g., '2026-06-01') */
  sunset: string;

  /** URL of the replacement endpoint */
  successor?: string;

  /** Human-readable deprecation message */
  message?: string;
}

/**
 * Marks an endpoint as deprecated.
 * A DeprecationInterceptor reads this metadata and sets the appropriate headers.
 */
export const Deprecated = (options: DeprecatedOptions) =>
  SetMetadata(DEPRECATED_KEY, options);

/**
 * Builds deprecation headers from options.
 * Utility for interceptors that need to set these headers.
 */
export function buildDeprecationHeaders(
  options: DeprecatedOptions,
): Record<string, string> {
  const headers: Record<string, string> = {};

  headers[RESPONSE_CONSTANTS.HEADERS.DEPRECATION] = 'true';

  // Convert ISO date to RFC 7231 format
  const sunsetDate = new Date(options.sunset);
  headers[RESPONSE_CONSTANTS.HEADERS.SUNSET] = sunsetDate.toUTCString();

  if (options.successor) {
    headers[RESPONSE_CONSTANTS.HEADERS.LINK] =
      `<${options.successor}>; rel="successor-version"`;
  }

  if (options.message) {
    headers[RESPONSE_CONSTANTS.HEADERS.DEPRECATION_NOTICE] = options.message;
  }

  return headers;
}
