// ─── Version Registry ──────────────────────────────────────────────────
// API version registry and utility functions.
// Maintains version metadata and provides version lookup.

/** Configuration for an API version */
export interface ApiVersionConfig {
  /** Version identifier (date format: YYYY-MM-DD) */
  readonly version: string;
  /** Human-readable description */
  readonly description: string;
  /** Whether this is the current latest version */
  readonly isLatest: boolean;
  /** Date when this version was deprecated (if applicable) */
  readonly deprecatedAt?: string;
}

// Version identifiers
const VERSION_LATEST = '2026-03-01';
const VERSION_2025_12 = '2025-12-01';
const VERSION_2025_09 = '2025-09-01';

/** Internal registry of all versions */
const VERSION_REGISTRY: ReadonlyMap<string, ApiVersionConfig> = new Map([
  [
    VERSION_LATEST,
    {
      version: VERSION_LATEST,
      description:
        'Latest: Cursor pagination, validators, HATEOAS links, API versioning, worker contracts',
      isLatest: true,
    },
  ],
  [
    VERSION_2025_12,
    {
      version: VERSION_2025_12,
      description: 'Sparse fieldsets and field selection',
      isLatest: false,
      deprecatedAt: VERSION_LATEST,
    },
  ],
  [
    VERSION_2025_09,
    {
      version: VERSION_2025_09,
      description: 'Expandable resources and relation includes',
      isLatest: false,
      deprecatedAt: VERSION_2025_12,
    },
  ],
]);

/**
 * Get the latest API version.
 *
 * @returns The latest version string
 */
export function getLatestVersion(): string {
  for (const [version, config] of VERSION_REGISTRY) {
    if (config.isLatest) {
      return version;
    }
  }

  // Fallback (should not happen with proper registry)
  return (
    Array.from(VERSION_REGISTRY.keys()).sort().reverse()[0] ?? VERSION_LATEST
  );
}

/**
 * Check if a version string is valid and registered.
 *
 * @param version - Version to check
 * @returns True if version exists in registry
 */
export function isValidVersion(version: string): boolean {
  return VERSION_REGISTRY.has(version);
}

/**
 * Get the configuration for a specific version.
 *
 * @param version - Version identifier
 * @returns Version config, or undefined if not found
 */
export function getVersionConfig(
  version: string,
): ApiVersionConfig | undefined {
  return VERSION_REGISTRY.get(version);
}

/**
 * Get all registered versions.
 *
 * @returns Array of all version configs
 */
export function getAllVersions(): readonly ApiVersionConfig[] {
  return Array.from(VERSION_REGISTRY.values());
}

/**
 * Check if a version is deprecated.
 *
 * @param version - Version identifier
 * @returns True if deprecated
 */
export function isVersionDeprecated(version: string): boolean {
  const config = VERSION_REGISTRY.get(version);
  return config != null && config.deprecatedAt != null;
}
