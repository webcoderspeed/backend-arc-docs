// ─── API Version Middleware ────────────────────────────────────────────
// NestJS middleware for API versioning via PE-API-Version header.
// Stores version in request object and echoes in response headers.

import { Injectable, NestMiddleware } from '@nestjs/common';
import type { Request, Response, NextFunction } from 'express';
import { getLatestVersion, isValidVersion } from './version-registry';

// Extend Express Request with apiVersion property
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      /**
       * The resolved API version for this request.
       * Set by ApiVersionMiddleware.
       */
      apiVersion?: string;
    }
  }
}

/** Header name for API version */
const API_VERSION_HEADER = 'PE-API-Version';

/**
 * NestJS middleware for API version handling.
 * Reads version from request headers, validates, and stores on request object.
 * Echoes version back in response headers.
 *
 * Usage in module:
 * ```typescript
 * export class AppModule implements NestModule {
 *   configure(consumer: MiddlewareConsumer) {
 *     consumer.apply(ApiVersionMiddleware).forRoutes('*');
 *   }
 * }
 * ```
 */
@Injectable()
export class ApiVersionMiddleware implements NestMiddleware {
  /**
   * Process the request and apply versioning.
   *
   * @param request - Express request object
   * @param response - Express response object
   * @param next - Next middleware function
   */
  use(request: Request, response: Response, next: NextFunction): void {
    // Read version from request header
    const requestedVersion = request.get(API_VERSION_HEADER);

    // Determine version to use
    const resolvedVersion = this.resolveVersion(requestedVersion);

    // Store on request for downstream access
    request.apiVersion = resolvedVersion;

    // Echo version back in response header
    response.setHeader(API_VERSION_HEADER, resolvedVersion);

    next();
  }

  /**
   * Resolve the API version to use.
   * Falls back to latest if not specified or invalid.
   *
   * @param requestedVersion - Version from request header (if any)
   * @returns Resolved version string
   */
  private resolveVersion(requestedVersion: string | undefined): string {
    // No version specified → use latest
    if (!requestedVersion) {
      return getLatestVersion();
    }

    // Invalid version → log warning, use latest
    if (!isValidVersion(requestedVersion)) {
      console.warn(
        `Invalid API version requested: "${requestedVersion}". Using latest.`,
      );
      return getLatestVersion();
    }

    // Valid version → use it
    return requestedVersion;
  }
}
