// ─── Expansion Registry ───────────────────────────────────────────────
// Central registry of all expandable fields per resource.
// Used by ExpandPipe to validate and by ExpansionService to resolve.

import type { ResourceType } from '../ids/resource-prefixes';
import type { ExpandableField } from './types';

/** Registry mapping resource types to their expandable fields */
const EXPANSION_REGISTRY: ReadonlyMap<
  ResourceType,
  readonly ExpandableField[]
> = new Map<ResourceType, readonly ExpandableField[]>([
  [
    'automation',
    [
      {
        field: 'bot',
        resourceType: 'bot',
        foreignKey: 'bot_id',
        relationship: 'belongs_to',
      },
      {
        field: 'social_account',
        resourceType: 'social_account',
        foreignKey: 'social_account_id',
        relationship: 'belongs_to',
      },
      {
        field: 'user',
        resourceType: 'user',
        foreignKey: 'user_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'bot',
    [
      {
        field: 'brand_voice',
        resourceType: 'brand_voice',
        foreignKey: 'brand_voice_id',
        relationship: 'belongs_to',
      },
      {
        field: 'social_account',
        resourceType: 'social_account',
        foreignKey: 'social_account_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'lead',
    [
      {
        field: 'social_account',
        resourceType: 'social_account',
        foreignKey: 'social_account_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'conversation',
    [
      {
        field: 'social_account',
        resourceType: 'social_account',
        foreignKey: 'social_account_id',
        relationship: 'belongs_to',
      },
      {
        field: 'messages',
        resourceType: 'message',
        foreignKey: 'conversation_id',
        relationship: 'has_many',
        inverseForeignKey: 'conversation_id',
      },
    ],
  ],
  [
    'voice_dna',
    [
      {
        field: 'brand_voice',
        resourceType: 'brand_voice',
        foreignKey: 'brand_voice_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'order',
    [
      {
        field: 'user',
        resourceType: 'user',
        foreignKey: 'user_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'payment',
    [
      {
        field: 'order',
        resourceType: 'order',
        foreignKey: 'order_id',
        relationship: 'belongs_to',
      },
      {
        field: 'user',
        resourceType: 'user',
        foreignKey: 'user_id',
        relationship: 'belongs_to',
      },
    ],
  ],
  [
    'notification',
    [
      {
        field: 'user',
        resourceType: 'user',
        foreignKey: 'user_id',
        relationship: 'belongs_to',
      },
    ],
  ],
]);

/**
 * Get all expandable fields for a resource type.
 * Returns an empty array if the resource has no expandable fields.
 */
export function getExpandableFields(
  resourceType: ResourceType,
): readonly ExpandableField[] {
  return EXPANSION_REGISTRY.get(resourceType) ?? [];
}

/**
 * Check if a field name is a valid expandable field for a resource type.
 */
export function isExpandableField(
  resourceType: ResourceType,
  fieldName: string,
): boolean {
  const fields = getExpandableFields(resourceType);

  return fields.some((f) => f.field === fieldName);
}

/**
 * Get a specific expandable field config by resource type and field name.
 */
export function getExpandableFieldConfig(
  resourceType: ResourceType,
  fieldName: string,
): ExpandableField | undefined {
  const fields = getExpandableFields(resourceType);

  return fields.find((f) => f.field === fieldName);
}

/**
 * Get all valid expansion field names for a resource type.
 * Useful for error messages listing valid options.
 */
export function getExpandableFieldNames(
  resourceType: ResourceType,
): readonly string[] {
  return getExpandableFields(resourceType).map((f) => f.field);
}
