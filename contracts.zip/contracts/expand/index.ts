// ─── Expandable Objects — Barrel Export ────────────────────────────────

export {
  type ExpandableField,
  type ExpansionConfig,
  type ParsedExpansion,
  parseExpansions,
} from './types';

export {
  getExpandableFields,
  isExpandableField,
  getExpandableFieldConfig,
  getExpandableFieldNames,
} from './expansion-registry';

export { Expand, EXPAND_METADATA_KEY } from './expand.decorator';

export { ExpandPipe } from './expand.pipe';

export {
  ExpansionService,
  type ModelResolver,
  type ModelResolverRegistry,
} from './expansion.service';
