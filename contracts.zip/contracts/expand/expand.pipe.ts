// ─── Expand Pipe ──────────────────────────────────────────────────────
// Validates ?expand[] query params against the expansion registry.
// Returns a validated set of expansion field names.

import { Injectable, BadRequestException } from '@nestjs/common';
import type { PipeTransform } from '@nestjs/common';
import type { ResourceType } from '../ids/resource-prefixes';
import {
  isExpandableField,
  getExpandableFieldNames,
} from './expansion-registry';

/** Maximum depth for nested expansions (e.g., bot.brand_voice = depth 2) */
const MAX_EXPANSION_DEPTH = 3;

@Injectable()
export class ExpandPipe implements PipeTransform<string | string[], string[]> {
  private readonly resourceType: ResourceType;

  constructor(resourceType: ResourceType) {
    this.resourceType = resourceType;
  }

  /**
   * Validate and parse ?expand[] query parameter.
   *
   * @param value - Raw expand parameter (string or string[])
   * @returns Array of validated expansion field names
   */
  transform(value: string | string[]): string[] {
    if (!value) {
      return [];
    }

    const expandFields = this.normalizeToArray(value);

    if (expandFields.length === 0) {
      return [];
    }

    this.validateFields(expandFields);

    return expandFields;
  }

  /** Normalize input to a flat array of field names */
  private normalizeToArray(value: string | string[]): string[] {
    if (typeof value === 'string') {
      return value
        .split(',')
        .map((v) => v.trim())
        .filter(Boolean);
    }

    return Array.isArray(value)
      ? value.flatMap((v) =>
          v
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
        )
      : [];
  }

  /** Validate each expansion field against the registry */
  private validateFields(fields: string[]): void {
    const validFields = getExpandableFieldNames(this.resourceType);

    for (const field of fields) {
      const parts = field.split('.');
      const topLevel = parts[0];

      // Check depth limit
      if (parts.length > MAX_EXPANSION_DEPTH) {
        throw new BadRequestException(
          `Expansion depth exceeds maximum of ${MAX_EXPANSION_DEPTH}: "${field}". ` +
            'Reduce nesting level.',
        );
      }

      // Check if top-level field is expandable
      if (!isExpandableField(this.resourceType, topLevel)) {
        throw new BadRequestException(
          `Invalid expansion field "${topLevel}" for resource "${this.resourceType}". ` +
            `Valid fields: [${validFields.join(', ')}].`,
        );
      }
    }
  }
}
