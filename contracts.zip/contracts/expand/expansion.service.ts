// ─── Expansion Service ────────────────────────────────────────────────
// Resolves expandable fields by batch-loading related documents.
// Uses N+1 prevention: collects all IDs, batch queries, maps back.

import { Injectable } from '@nestjs/common';
import type { ResourceType } from '../ids/resource-prefixes';
import { getExpandableFieldConfig } from './expansion-registry';
import type { ExpandableField } from './types';

/** Interface for model resolvers injected at module level */
export interface ModelResolver {
  /** Batch-load documents by their ObjectId strings */
  findByIds(ids: string[]): Promise<ReadonlyMap<string, unknown>>;
  /** For hasMany: find all docs matching a foreign key value */
  findByForeignKey?(
    foreignKey: string,
    parentIds: string[],
  ): Promise<ReadonlyMap<string, readonly unknown[]>>;
}

/** Registry of model resolvers keyed by resource type */
export type ModelResolverRegistry = ReadonlyMap<ResourceType, ModelResolver>;

@Injectable()
export class ExpansionService {
  private readonly resolvers: Map<ResourceType, ModelResolver> = new Map();

  /**
   * Register a model resolver for a resource type.
   * Called during module initialization.
   */
  registerResolver(resourceType: ResourceType, resolver: ModelResolver): void {
    this.resolvers.set(resourceType, resolver);
  }

  /**
   * Resolve expansions for a single document.
   * Returns a Map of field name → resolved document(s).
   *
   * @param resourceType - The type of the parent resource
   * @param document - The parent document (must have the foreign key fields)
   * @param expandFields - Array of field names to expand
   */
  async resolveForSingle(
    resourceType: ResourceType,
    document: Record<string, unknown>,
    expandFields: readonly string[],
  ): Promise<Map<string, unknown>> {
    const result = new Map<string, unknown>();

    for (const fieldName of expandFields) {
      const topLevel = fieldName.split('.')[0];
      const config = getExpandableFieldConfig(resourceType, topLevel);

      if (!config) {
        continue;
      }

      const resolved = await this.resolveField(config, document);

      if (resolved !== undefined) {
        result.set(topLevel, resolved);
      }
    }

    return result;
  }

  /**
   * Resolve expansions for a list of documents (batch mode).
   * Returns a Map of parentId → Map of field name → resolved document(s).
   *
   * @param resourceType - The type of the parent resource
   * @param documents - Array of parent documents
   * @param expandFields - Array of field names to expand
   */
  async resolveForList(
    resourceType: ResourceType,
    documents: readonly Record<string, unknown>[],
    expandFields: readonly string[],
  ): Promise<Map<string, Map<string, unknown>>> {
    const resultByParent = new Map<string, Map<string, unknown>>();

    for (const fieldName of expandFields) {
      const topLevel = fieldName.split('.')[0];
      const config = getExpandableFieldConfig(resourceType, topLevel);

      if (!config) {
        continue;
      }

      await this.batchResolveField(config, documents, resultByParent);
    }

    return resultByParent;
  }

  // ─── Private Helpers ──────────────────────────────────────────────

  /** Resolve a single field for a single document */
  private async resolveField(
    config: ExpandableField,
    document: Record<string, unknown>,
  ): Promise<unknown> {
    const resolver = this.resolvers.get(config.resourceType);

    if (!resolver) {
      return undefined;
    }

    if (config.relationship === 'belongs_to') {
      const foreignKeyValue = document[config.foreignKey];

      if (!foreignKeyValue) {
        return null;
      }

      const idString = this.toIdString(foreignKeyValue);
      const results = await resolver.findByIds([idString]);

      return results.get(idString) ?? null;
    }

    if (config.relationship === 'has_many' && resolver.findByForeignKey) {
      const parentId = this.toIdString(document._id);
      const results = await resolver.findByForeignKey(
        config.inverseForeignKey ?? config.foreignKey,
        [parentId],
      );

      return results.get(parentId) ?? [];
    }

    return undefined;
  }

  /** Batch-resolve a field across multiple documents */
  private async batchResolveField(
    config: ExpandableField,
    documents: readonly Record<string, unknown>[],
    resultByParent: Map<string, Map<string, unknown>>,
  ): Promise<void> {
    const resolver = this.resolvers.get(config.resourceType);

    if (!resolver) {
      return;
    }

    if (config.relationship === 'belongs_to') {
      await this.batchResolveBelongsTo(
        config,
        documents,
        resolver,
        resultByParent,
      );
    }

    if (config.relationship === 'has_many' && resolver.findByForeignKey) {
      await this.batchResolveHasMany(
        config,
        documents,
        resolver,
        resultByParent,
      );
    }
  }

  /** Batch-resolve belongs_to relationships */
  private async batchResolveBelongsTo(
    config: ExpandableField,
    documents: readonly Record<string, unknown>[],
    resolver: ModelResolver,
    resultByParent: Map<string, Map<string, unknown>>,
  ): Promise<void> {
    // Collect all unique foreign key values
    const foreignKeyValues = new Set<string>();

    for (const document of documents) {
      const value = document[config.foreignKey];

      if (value) {
        foreignKeyValues.add(this.toIdString(value));
      }
    }

    if (foreignKeyValues.size === 0) {
      return;
    }

    // Batch load all related documents
    const resolved = await resolver.findByIds([...foreignKeyValues]);

    // Map results back to parent documents
    for (const document of documents) {
      const parentId = this.toIdString(document._id);
      const foreignKeyValue = document[config.foreignKey];
      const relatedDocument = foreignKeyValue
        ? (resolved.get(this.toIdString(foreignKeyValue)) ?? null)
        : null;

      const parentResults =
        resultByParent.get(parentId) ?? new Map<string, unknown>();
      parentResults.set(config.field, relatedDocument);
      resultByParent.set(parentId, parentResults);
    }
  }

  /** Batch-resolve has_many relationships */
  private async batchResolveHasMany(
    config: ExpandableField,
    documents: readonly Record<string, unknown>[],
    resolver: ModelResolver,
    resultByParent: Map<string, Map<string, unknown>>,
  ): Promise<void> {
    const parentIds = documents.map((d) => this.toIdString(d._id));

    if (parentIds.length === 0 || !resolver.findByForeignKey) {
      return;
    }

    const resolved = await resolver.findByForeignKey(
      config.inverseForeignKey ?? config.foreignKey,
      parentIds,
    );

    for (const document of documents) {
      const parentId = this.toIdString(document._id);
      const relatedDocuments = resolved.get(parentId) ?? [];

      const parentResults =
        resultByParent.get(parentId) ?? new Map<string, unknown>();
      parentResults.set(config.field, relatedDocuments);
      resultByParent.set(parentId, parentResults);
    }
  }

  /**
   * Safely convert an unknown ID value to a string.
   * Handles ObjectId instances (which have toString()) and plain strings.
   */
  private toIdString(value: unknown): string {
    if (typeof value === 'string') {
      return value;
    }

    if (
      value !== null &&
      value !== undefined &&
      typeof value === 'object' &&
      'toHexString' in value &&
      typeof (value as { toHexString: () => string }).toHexString === 'function'
    ) {
      return (value as { toHexString: () => string }).toHexString();
    }

    if (
      value !== null &&
      value !== undefined &&
      typeof value === 'object' &&
      'toString' in value &&
      typeof (value as { toString: () => string }).toString === 'function'
    ) {
      return (value as { toString: () => string }).toString();
    }

    return '';
  }
}
