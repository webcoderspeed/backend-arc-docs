// ─── Expandable Object Types ──────────────────────────────────────────
// Defines the structure for declaring expandable relationships per resource.

import type { ResourceType } from '../ids/resource-prefixes';

/** Describes a single expandable field on a resource */
export interface ExpandableField {
  /** The field name as it appears in the response (e.g., 'bot') */
  readonly field: string;

  /** The resource type of the related resource */
  readonly resourceType: ResourceType;

  /** The foreign key field on the parent document (e.g., 'bot_id') */
  readonly foreignKey: string;

  /** Relationship type: belongsTo (single doc) or hasMany (array) */
  readonly relationship: 'belongs_to' | 'has_many';

  /** For hasMany: the foreign key on the child document pointing to parent */
  readonly inverseForeignKey?: string;

  /** Maximum allowed depth for nested expansions (default: 1) */
  readonly maxDepth?: number;
}

/** Configuration for a resource's expandable fields */
export interface ExpansionConfig {
  /** The resource type this config applies to */
  readonly resourceType: ResourceType;

  /** All expandable fields for this resource */
  readonly fields: readonly ExpandableField[];
}

/** Parsed expansion request from query params */
export interface ParsedExpansion {
  /** Top-level field to expand */
  readonly field: string;

  /** Nested fields to expand (e.g., 'bot.brand_voice' → nested = ['brand_voice']) */
  readonly nested: readonly string[];
}

/**
 * Parse an expand parameter value into structured expansions.
 *
 * @example
 * parseExpansions(['bot', 'social_account', 'bot.brand_voice'])
 * // → [
 * //   { field: 'bot', nested: ['brand_voice'] },
 * //   { field: 'social_account', nested: [] }
 * // ]
 */
export function parseExpansions(
  expandParams: readonly string[],
): readonly ParsedExpansion[] {
  const expansionMap = new Map<string, string[]>();

  for (const parameter of expandParams) {
    const parts = parameter.split('.');
    const topLevel = parts[0];
    const nested = parts.slice(1);

    const existing = expansionMap.get(topLevel) ?? [];

    if (nested.length > 0) {
      existing.push(nested.join('.'));
    }

    expansionMap.set(topLevel, existing);
  }

  return [...expansionMap.entries()].map(([field, nested]) => ({
    field,
    nested,
  }));
}
