// ─── @Expand() Decorator ──────────────────────────────────────────────
// Method decorator that declares which resource type a controller method
// returns, enabling the ExpandPipe to validate ?expand[] params.

import { SetMetadata } from '@nestjs/common';
import type { ResourceType } from '../ids/resource-prefixes';

/** Metadata key for the expand decorator */
export const EXPAND_METADATA_KEY = 'pe:expandable_resource';

/**
 * Declares the resource type for a controller method, enabling expansion support.
 * Used alongside ExpandPipe to validate ?expand[] query parameters.
 *
 * Usage: Apply Expand('automation') decorator to a controller method.
 */
export const Expand = (resourceType: ResourceType): MethodDecorator =>
  SetMetadata(EXPAND_METADATA_KEY, resourceType);
