// ─── 200 OK — Standard Success ─────────────────────────────────────────
// The default response type for all successful GET, POST, PUT, PATCH requests.

import type { ResponseMeta } from './base.response';

export interface SuccessResponse<T> {
  success: true;
  data: T;
  meta: ResponseMeta;
}
