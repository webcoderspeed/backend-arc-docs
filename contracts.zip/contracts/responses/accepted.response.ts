// ─── 202 Accepted — Async Job Started ──────────────────────────────────
// Returned when a long-running operation is queued for async processing.
// The interceptor sets Location + Retry-After headers.

import type { ResponseMeta } from './base.response';

// ─── Accepted Response (returned from POST that starts async job) ──────

export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed';

export interface AcceptedResponseData {
  /** Unique job identifier (format: job_<random>) */
  job_id: string;

  /** Current job status */
  status: 'queued' | 'processing';

  /** URL to poll for job status: GET /api/v1/jobs/{job_id} */
  status_url: string;

  /** Estimated completion time (ISO 8601) */
  estimated_completion?: string;
}

export interface AcceptedResponse {
  success: true;
  data: AcceptedResponseData;
  meta: ResponseMeta;
}

// ─── Job Status Response (returned from GET /api/v1/jobs/:id) ──────────

export interface JobError {
  code: string;
  message: string;
}

export interface JobStatusData<T = unknown> {
  /** Unique job identifier */
  job_id: string;

  /** Current job status */
  status: JobStatus;

  /** Progress percentage (0-100) */
  progress?: number;

  /** Result data (only when status === 'completed') */
  result?: T;

  /** Error details (only when status === 'failed') */
  error?: JobError;

  /** ISO 8601 timestamp when the job was created */
  created_at: string;

  /** ISO 8601 timestamp of the last status update */
  updated_at: string;

  /** ISO 8601 timestamp when the job completed (success or failure) */
  completed_at?: string;
}

export interface JobStatusResponse<T = unknown> {
  success: true;
  data: JobStatusData<T>;
  meta: ResponseMeta;
}

// ─── Marker for ResponseInterceptor detection ──────────────────────────

export const ACCEPTED_RESPONSE_MARKER = Symbol('AcceptedResponse');

export interface AcceptedResponseMarker {
  [ACCEPTED_RESPONSE_MARKER]: true;
  job_id: string;
  status_url: string;
  estimated_completion?: string;
}

/**
 * Wraps controller return data with an accepted marker for the interceptor.
 * Usage: `return markAccepted('job_abc', '/api/v1/jobs/job_abc', 30000);`
 */
export function markAccepted(
  job_id: string,
  status_url: string,
  estimated_ms?: number,
): AcceptedResponseMarker {
  return {
    [ACCEPTED_RESPONSE_MARKER]: true,
    job_id,
    status_url,
    estimated_completion: estimated_ms
      ? new Date(Date.now() + estimated_ms).toISOString()
      : undefined,
  };
}
