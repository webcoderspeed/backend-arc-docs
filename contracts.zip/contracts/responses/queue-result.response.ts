// ─── Queue Job Result Envelope ─────────────────────────────────────────
// Standardizes all queue job processor return values.
// Used by Worker processors to return consistent results.
//
// NOTE: Named `StandardJobResult` (not `QueueJobResult`) to avoid conflict
// with the existing `QueueJobResult` in `queue/queue.types.ts`.

export interface StandardJobMeta {
  /** BullMQ job ID */
  job_id: string;

  /** Queue name (e.g., 'lead-export', 'instagram-webhook') */
  queue: string;

  /** Correlation ID linking back to the originating request */
  correlation_id?: string;

  /** Processing duration in milliseconds */
  duration_ms: number;

  /** Number of attempts (including retries) */
  attempts: number;

  /** ISO 8601 timestamp of result creation */
  timestamp: string;

  /** Allow additional metadata properties */
  [key: string]: unknown;
}

export interface StandardJobError {
  code: string;
  message: string;
}

export interface StandardJobResult<T = unknown> {
  /** Whether the job completed successfully */
  success: boolean;

  /** Result data (present on success) */
  data?: T;

  /** Error details (present on failure) */
  error?: StandardJobError;

  /** Job execution metadata */
  meta: StandardJobMeta;
}
