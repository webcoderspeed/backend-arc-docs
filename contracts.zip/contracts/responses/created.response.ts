// ─── 201 Created — Resource Created ────────────────────────────────────
// Returned when a new resource is successfully created.
// The interceptor sets the `Location` header pointing to the new resource.

import type { ResponseMeta } from './base.response';

export interface CreatedResponseMeta extends ResponseMeta {
  /** URL of the newly created resource (also set as Location header) */
  location: string;
}

export interface CreatedResponse<T> {
  success: true;
  data: T;
  meta: CreatedResponseMeta;
}

// ─── Marker for ResponseInterceptor detection ──────────────────────────

export const CREATED_RESPONSE_MARKER = Symbol('CreatedResponse');

export interface CreatedResponseMarker<T> {
  [CREATED_RESPONSE_MARKER]: true;
  data: T;
  location: string;
}

/**
 * Wraps controller return data with a created marker for the interceptor.
 * Usage: `return markCreated(automation, '/api/v1/automations/abc123');`
 */
export function markCreated<T>(
  data: T,
  location: string,
): CreatedResponseMarker<T> {
  return {
    [CREATED_RESPONSE_MARKER]: true,
    data,
    location,
  };
}
