// ─── Paginated Responses ───────────────────────────────────────────────
// Two pagination strategies: offset-based and cursor-based.
// Both use the existing PaginationResult/CursorPaginationResult types
// from pagination.utility.ts as the internal data format.
// The ResponseInterceptor detects these and wraps with meta.

import type { ResponseMeta } from './base.response';

// ─── Offset-Based Pagination ───────────────────────────────────────────

export interface OffsetPaginationInfo {
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

export interface PaginatedResponse<T> {
  success: true;
  data: T[];
  pagination: OffsetPaginationInfo;
  meta: ResponseMeta;
}

// ─── Cursor-Based Pagination ───────────────────────────────────────────

export interface CursorPaginationInfo {
  limit: number;
  next_cursor?: string;
  previous_cursor?: string;
  has_next_page: boolean;
  has_previous_page: boolean;
}

export interface CursorPaginatedResponse<T> {
  success: true;
  data: T[];
  pagination: CursorPaginationInfo;
  meta: ResponseMeta;
}
