// ─── Response Type Contracts ───────────────────────────────────────────
// All response interfaces, markers, and helpers for the PostEngage.ai API.

// Base
export {
  type ResponseMeta,
  type ResponseType,
  RESPONSE_TYPE_KEY,
  RESPONSE_CONSTANTS,
} from './base.response';

// 200 OK
export { type SuccessResponse } from './success.response';

// 201 Created
export {
  type CreatedResponse,
  type CreatedResponseMeta,
  type CreatedResponseMarker,
  CREATED_RESPONSE_MARKER,
  markCreated,
} from './created.response';

// 202 Accepted
export {
  type AcceptedResponse,
  type AcceptedResponseData,
  type AcceptedResponseMarker,
  type JobStatus,
  type JobError,
  type JobStatusData,
  type JobStatusResponse,
  ACCEPTED_RESPONSE_MARKER,
  markAccepted,
} from './accepted.response';

// 204 No Content
export {
  type NoContentMarker,
  NO_CONTENT_MARKER,
  markNoContent,
} from './no-content.response';

// 207 Multi-Status
export {
  type MultiStatusResponse,
  type MultiStatusData,
  type MultiStatusMarker,
  type BulkItemResult,
  type BulkItemError,
  MULTI_STATUS_MARKER,
  markMultiStatus,
} from './multi-status.response';

// Paginated
export {
  type PaginatedResponse,
  type CursorPaginatedResponse,
  type OffsetPaginationInfo,
  type CursorPaginationInfo,
} from './paginated.response';

// WebSocket
export { type WsEventEnvelope, type WsEventMeta } from './ws-event.response';

// Queue Job Result (Standard envelope — avoids conflict with queue/queue.types.ts QueueJobResult)
export {
  type StandardJobResult,
  type StandardJobMeta,
  type StandardJobError,
} from './queue-result.response';
