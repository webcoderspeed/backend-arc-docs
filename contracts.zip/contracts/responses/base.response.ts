// ─── Base Response Meta ────────────────────────────────────────────────
// Present on every HTTP response. Provides correlation, versioning, and timing.

export interface ResponseMeta {
  /** Unique request identifier for debugging/tracing (format: req_<timestamp>_<random>) */
  request_id: string;

  /** ISO 8601 timestamp of the response */
  timestamp: string;

  /** API version date string (e.g., '2026-01-01') */
  api_version: string;

  /** Original request path (e.g., '/api/v1/automations') */
  path: string;

  /** HTTP status code */
  status: number;
}

// ─── Response Type Identifiers ─────────────────────────────────────────
// Used by ResponseInterceptor to detect and format different response types.

export const RESPONSE_TYPE_KEY = 'response_type';

export type ResponseType =
  | 'success'
  | 'created'
  | 'accepted'
  | 'no-content'
  | 'multi-status'
  | 'paginated'
  | 'cursor-paginated';

// ─── Response Constants ────────────────────────────────────────────────

export const RESPONSE_CONSTANTS = {
  /** Current API version */
  API_VERSION: '2026-01-01',

  /** Request ID prefix */
  REQUEST_ID_PREFIX: 'req_',

  /** Header names */
  HEADERS: {
    REQUEST_ID: 'X-Request-ID',
    API_VERSION: 'X-API-Version',
    RESPONSE_TIME: 'X-Response-Time',
    LOCATION: 'Location',
    RETRY_AFTER: 'Retry-After',
    TOTAL_COUNT: 'X-Total-Count',
    IDEMPOTENCY_KEY: 'Idempotency-Key',
    IDEMPOTENT_REPLAYED: 'Idempotent-Replayed',
    RATE_LIMIT_LIMIT: 'X-RateLimit-Limit',
    RATE_LIMIT_REMAINING: 'X-RateLimit-Remaining',
    RATE_LIMIT_RESET: 'X-RateLimit-Reset',
    ETAG: 'ETag',
    IF_NONE_MATCH: 'If-None-Match',
    CACHE_CONTROL: 'Cache-Control',
    VARY: 'Vary',
    DEPRECATION: 'Deprecation',
    SUNSET: 'Sunset',
    LINK: 'Link',
    DEPRECATION_NOTICE: 'X-Deprecation-Notice',
  },
} as const;
