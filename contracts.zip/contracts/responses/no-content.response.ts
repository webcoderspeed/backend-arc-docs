// ─── 204 No Content — Empty Success ────────────────────────────────────
// Used for: DELETE, toggles, acknowledgments.
// Response has NO body — only headers (X-Request-ID, X-API-Version).

export const NO_CONTENT_MARKER = Symbol('NoContentResponse');

export interface NoContentMarker {
  [NO_CONTENT_MARKER]: true;
}

/**
 * Returns a marker that tells the ResponseInterceptor to send 204 with no body.
 * Usage: `return markNoContent();`
 */
export function markNoContent(): NoContentMarker {
  return { [NO_CONTENT_MARKER]: true };
}
