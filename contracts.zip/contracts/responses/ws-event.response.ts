// ─── WebSocket Event Envelope ──────────────────────────────────────────
// Standardizes all real-time events emitted by the Pulse gateway.
// Event naming convention: {resource}.{action}
// Examples: "automation.executed", "lead.created", "job.progress", "payment.verified"

export interface WsEventMeta {
  /** Correlation ID linking related events (e.g., the request_id that started the flow) */
  readonly correlation_id?: string;

  /** ISO 8601 timestamp of the event */
  readonly timestamp: string;

  /** User ID the event belongs to */
  readonly user_id: string;
}

export interface WsEventEnvelope<T> {
  /** Event name in {resource}.{action} format */
  readonly event: string;

  /** Event payload */
  readonly data: T;

  /** Event metadata */
  readonly meta: WsEventMeta;
}
