// ─── 207 Multi-Status — Bulk Operation Results ────────────────────────
// Returned when a batch operation produces per-item success/failure results.

import type { ResponseMeta } from './base.response';

// ─── Per-Item Result ───────────────────────────────────────────────────

export interface BulkItemError {
  code: string;
  message: string;
}

export interface BulkItemResult<T> {
  /** Position in the original request array (0-based) */
  index: number;

  /** HTTP status for this specific item (200, 201, 400, 409, 422, etc.) */
  status: number;

  /** Result data (present when status indicates success) */
  data?: T;

  /** Error details (present when status indicates failure) */
  error?: BulkItemError;
}

// ─── Aggregate Summary ─────────────────────────────────────────────────

export interface MultiStatusData<T> {
  /** Total number of items processed */
  total: number;

  /** Number of items that succeeded */
  succeeded: number;

  /** Number of items that failed */
  failed: number;

  /** Per-item results (ordered by index) */
  results: BulkItemResult<T>[];
}

// ─── Full Response ─────────────────────────────────────────────────────

export interface MultiStatusResponse<T> {
  success: true;
  data: MultiStatusData<T>;
  meta: ResponseMeta;
}

// ─── Marker for ResponseInterceptor detection ──────────────────────────

export const MULTI_STATUS_MARKER = Symbol('MultiStatusResponse');

export interface MultiStatusMarker<T> {
  [MULTI_STATUS_MARKER]: true;
  results: BulkItemResult<T>[];
}

/**
 * Wraps bulk operation results with a multi-status marker for the interceptor.
 * Usage: `return markMultiStatus(results);`
 */
export function markMultiStatus<T>(
  results: BulkItemResult<T>[],
): MultiStatusMarker<T> {
  return {
    [MULTI_STATUS_MARKER]: true,
    results,
  };
}
