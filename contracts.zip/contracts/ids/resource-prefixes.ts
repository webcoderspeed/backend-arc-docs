// ─── Resource ID Prefix Registry ──────────────────────────────────────────
// Every resource type maps to a unique 3-character prefix.
// Format: {prefix}_{objectId} → e.g., "aut_507f1f77bcf86cd799439011"
// Inspired by Stripe's ch_, cus_, pi_ pattern.

export const RESOURCE_PREFIXES = {
  user: 'usr',
  lead: 'led',
  automation: 'aut',
  automation_trigger: 'atr',
  automation_action: 'aac',
  automation_condition: 'aco',
  automation_execution: 'aex',
  bot: 'bot',
  bot_knowledge_source: 'bks',
  brand_voice: 'bvs',
  voice_dna: 'vdn',
  social_account: 'sac',
  conversation: 'cnv',
  message: 'msg',
  media: 'mda',
  order: 'ord',
  payment: 'pay',
  credit_transaction: 'crt',
  credit_package: 'cpk',
  notification: 'ntf',
  auth_token: 'atk',
  intelligence_log: 'ilg',
  job: 'job',
  activity_log: 'alg',
  newsletter_subscriber: 'nsb',
  user_credit: 'ucr',
  user_engagement_profile: 'uep',
  user_llm_config: 'lcf',
  user_relationship_memory: 'urm',
  user_session: 'usn',
  currency: 'cur',
  few_shot: 'fse',
  negative_example: 'nex',
  escalation: 'esc',
  support_ticket: 'stk',
  webhook_event: 'whe',
} as const;

/** All valid resource type strings */
export type ResourceType = keyof typeof RESOURCE_PREFIXES;

/** All valid prefix strings */
export type ResourcePrefix = (typeof RESOURCE_PREFIXES)[ResourceType];

/** Reverse map: prefix → resource type (built once at module load) */
const PREFIX_TO_RESOURCE: ReadonlyMap<string, ResourceType> = new Map(
  (Object.entries(RESOURCE_PREFIXES) as [ResourceType, string][]).map(
    ([resourceType, prefix]) => [prefix, resourceType],
  ),
);

/**
 * Lookup a resource type by its prefix.
 * @returns The resource type, or undefined if no match
 */
export function getResourceTypeByPrefix(
  prefix: string,
): ResourceType | undefined {
  return PREFIX_TO_RESOURCE.get(prefix);
}
