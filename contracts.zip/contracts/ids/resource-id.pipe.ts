// ─── Resource ID Pipe ──────────────────────────────────────────────────
// NestJS pipe that accepts both prefixed IDs and raw ObjectIds.
// Always converts to raw ObjectId for downstream service/repository usage.
// Used with @Param('id', ResourceIdPipe) in controllers.

import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';
import {
  isPublicId,
  isRawObjectId,
  normalizeToObjectId,
} from './resource-id.service';

@Injectable()
export class ResourceIdPipe implements PipeTransform<string, string> {
  /**
   * Transform a prefixed or raw ID into a raw ObjectId string.
   *
   * @param value - The incoming ID string (e.g., "aut_507f1f77..." or "507f1f77...")
   * @returns Raw ObjectId string
   * @throws BadRequestException if the format is invalid
   */
  transform(value: string): string {
    if (!value || typeof value !== 'string') {
      throw new BadRequestException(
        'Resource ID is required and must be a string.',
      );
    }

    const trimmed = value.trim();

    if (!isPublicId(trimmed) && !isRawObjectId(trimmed)) {
      throw new BadRequestException(
        `Invalid resource ID format: "${trimmed}". ` +
          'Expected a prefixed ID (e.g., "aut_507f1f77bcf86cd799439011") ' +
          'or a raw ObjectId (e.g., "507f1f77bcf86cd799439011").',
      );
    }

    try {
      return normalizeToObjectId(trimmed);
    } catch {
      throw new BadRequestException(
        `Unable to parse resource ID: "${trimmed}".`,
      );
    }
  }
}
