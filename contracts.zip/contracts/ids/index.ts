// ─── Resource ID System — Barrel Export ────────────────────────────────

export {
  RESOURCE_PREFIXES,
  type ResourceType,
  type ResourcePrefix,
  getResourceTypeByPrefix,
} from './resource-prefixes';

export {
  toPublicId,
  fromPublicId,
  isPublicId,
  isRawObjectId,
  normalizeToObjectId,
  getPrefix,
  type ParsedResourceId,
  type DocumentId,
} from './resource-id.service';

export { ResourceIdPipe } from './resource-id.pipe';
