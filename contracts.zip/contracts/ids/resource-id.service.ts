// ─── Resource ID Converter ─────────────────────────────────────────────
// Converts between raw MongoDB ObjectIds and public prefixed IDs.
// All API responses use prefixed IDs. All internal code uses raw ObjectIds.
// Conversion happens at the serialization/deserialization boundary only.

import { Types } from 'mongoose';
import {
  RESOURCE_PREFIXES,
  type ResourceType,
  getResourceTypeByPrefix,
} from './resource-prefixes';

/** Separator between prefix and ObjectId */
const ID_SEPARATOR = '_';

/**
 * ID field type that handles Mongoose populated references.
 * Mongoose ref fields can be: raw ObjectId, string, or populated document (object with _id).
 */
export type DocumentId =
  | Types.ObjectId
  | string
  | { readonly _id: Types.ObjectId | string };

/** RegExp to validate prefixed ID format: 3 lowercase chars + underscore + 24 hex chars */
const PREFIXED_ID_PATTERN = /^[a-z]{3}_[\da-f]{24}$/;

/** RegExp to validate raw ObjectId format: 24 hex chars */
const RAW_OBJECT_ID_PATTERN = /^[\da-f]{24}$/;

/** Result of parsing a prefixed ID */
export interface ParsedResourceId {
  readonly resourceType: ResourceType;
  readonly prefix: string;
  readonly objectId: string;
}

/**
 * Convert a raw ObjectId to a prefixed public ID.
 *
 * @example
 * toPublicId('automation', '507f1f77bcf86cd799439011')
 * // → 'aut_507f1f77bcf86cd799439011'
 */
export function toPublicId(
  resourceType: ResourceType,
  objectId: DocumentId,
): string {
  const prefix = RESOURCE_PREFIXES[resourceType];

  // Handle populated documents (e.g., populated user_id → MongoUserDocument)
  if (
    typeof objectId === 'object' &&
    objectId !== null &&
    '_id' in objectId &&
    !(objectId instanceof Types.ObjectId)
  ) {
    const innerId = objectId._id;
    const idString =
      innerId instanceof Types.ObjectId ? innerId.toHexString() : innerId;
    return `${prefix}${ID_SEPARATOR}${idString}`;
  }

  const idString =
    objectId instanceof Types.ObjectId ? objectId.toHexString() : objectId;

  return `${prefix}${ID_SEPARATOR}${idString}`;
}

/**
 * Parse a prefixed public ID back to its resource type and raw ObjectId.
 *
 * @throws {Error} If the ID format is invalid or prefix is unknown
 *
 * @example
 * fromPublicId('aut_507f1f77bcf86cd799439011')
 * // → { resourceType: 'automation', prefix: 'aut', objectId: '507f1f77bcf86cd799439011' }
 */
export function fromPublicId(prefixedId: string): ParsedResourceId {
  if (!PREFIXED_ID_PATTERN.test(prefixedId)) {
    throw new Error(
      `Invalid prefixed ID format: "${prefixedId}". Expected format: {prefix}_{objectId}`,
    );
  }

  const separatorIndex = prefixedId.indexOf(ID_SEPARATOR);
  const prefix = prefixedId.slice(0, separatorIndex);
  const objectId = prefixedId.slice(separatorIndex + 1);

  const resourceType = getResourceTypeByPrefix(prefix);

  if (!resourceType) {
    throw new Error(
      `Unknown resource prefix: "${prefix}" in ID "${prefixedId}"`,
    );
  }

  return { resourceType, prefix, objectId };
}

/**
 * Check if a value looks like a valid prefixed ID.
 *
 * @example
 * isPublicId('aut_507f1f77bcf86cd799439011') // → true
 * isPublicId('507f1f77bcf86cd799439011')      // → false
 * isPublicId('invalid')                        // → false
 */
export function isPublicId(value: string): boolean {
  return PREFIXED_ID_PATTERN.test(value);
}

/**
 * Check if a value looks like a raw MongoDB ObjectId.
 *
 * @example
 * isRawObjectId('507f1f77bcf86cd799439011') // → true
 * isRawObjectId('aut_507f1f77bcf86cd799439011') // → false
 */
export function isRawObjectId(value: string): boolean {
  return RAW_OBJECT_ID_PATTERN.test(value);
}

/**
 * Normalize an ID to a raw ObjectId string.
 * Accepts both prefixed IDs and raw ObjectIds.
 * This is used at the deserialization boundary (incoming request params).
 *
 * @example
 * normalizeToObjectId('aut_507f1f77bcf86cd799439011') // → '507f1f77bcf86cd799439011'
 * normalizeToObjectId('507f1f77bcf86cd799439011')      // → '507f1f77bcf86cd799439011'
 */
export function normalizeToObjectId(idValue: string): string {
  if (isPublicId(idValue)) {
    return fromPublicId(idValue).objectId;
  }

  if (isRawObjectId(idValue)) {
    return idValue;
  }

  throw new Error(
    `Invalid ID format: "${idValue}". Expected a prefixed ID (e.g., "aut_...") or a raw ObjectId.`,
  );
}

/**
 * Get the prefix for a resource type.
 *
 * @example
 * getPrefix('automation') // → 'aut'
 */
export function getPrefix(resourceType: ResourceType): string {
  return RESOURCE_PREFIXES[resourceType];
}
