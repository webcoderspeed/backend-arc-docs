// ─── Response Envelope Types ──────────────────────────────────────────
// Typed wrapper interfaces for the standard API response envelope.
// These extend the existing contracts with the premium I/O shape.

import type { ResponseMeta } from '../responses/base.response';
import type { CursorPaginationMeta } from './cursor-pagination.dto';

// ─── Single Resource Envelope ─────────────────────────────────────────

export interface SingleResourceEnvelope<T> {
  readonly success: true;
  readonly data: T;
  readonly meta: ResponseMeta;
}

// ─── List Resource Envelope (Cursor Pagination) ───────────────────────

export interface ListResourceEnvelope<T> {
  readonly success: true;
  readonly data: readonly T[];
  readonly pagination: CursorPaginationMeta;
  readonly meta: ResponseMeta;
  readonly _links?: {
    readonly self: { readonly href: string };
    readonly next?: { readonly href: string };
    readonly previous?: { readonly href: string };
  };
}

// ─── Serialization Options ────────────────────────────────────────────
// Passed to serializers so they know what to include.

export interface SerializeOptions {
  /** Fields to expand (e.g., ['bot', 'social_account']) */
  readonly expand: ReadonlySet<string>;

  /** Fields to include (sparse fieldset). undefined = all fields */
  readonly fields?: ReadonlySet<string>;

  /** Whether to include HATEOAS _links (default: true) */
  readonly includeLinks: boolean;

  /** Base URL for building absolute _links (e.g., '/api/v1') */
  readonly basePath: string;

  /** Already-resolved expanded objects keyed by field name */
  readonly expandedData?: ReadonlyMap<string, unknown>;
}

/** Default serialization options */
export const DEFAULT_SERIALIZE_OPTIONS: SerializeOptions = {
  expand: new Set<string>(),
  fields: undefined,
  includeLinks: true,
  basePath: '/api/v1',
};

/**
 * Build SerializeOptions from query parameters.
 * Used in controllers to parse incoming request.
 */
export function buildSerializeOptions(parameters: {
  expand?: readonly string[];
  fields?: string;
  includeLinks?: boolean;
  basePath?: string;
}): SerializeOptions {
  const expandSet = new Set(parameters.expand ?? []);

  const fieldsSet = parameters.fields
    ? new Set(
        parameters.fields
          .split(',')
          .map((f) => f.trim())
          .filter(Boolean),
      )
    : undefined;

  return {
    expand: expandSet,
    fields: fieldsSet,
    includeLinks: parameters.includeLinks ?? true,
    basePath: parameters.basePath ?? '/api/v1',
  };
}
