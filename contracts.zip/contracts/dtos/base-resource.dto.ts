// ─── Base Resource DTO ────────────────────────────────────────────────
// Abstract base class for all API response DTOs.
// Every resource inherits this to ensure consistent id, timestamps, and links.

/** HATEOAS link structure */
export interface ResourceLink {
  /** URL path (relative or absolute) */
  readonly href: string;
  /** HTTP method (default: GET) */
  readonly method?: string;
}

/** Map of named links for a resource */
export interface ResourceLinks {
  readonly self: ResourceLink;
  readonly [key: string]: ResourceLink;
}

/**
 * Abstract base for all response DTOs.
 * Subclasses define resource-specific fields.
 *
 * @example
 * class AutomationResponseDto extends BaseResourceDto {
 *   name: string;
 *   status: 'active' | 'paused';
 *   // ... resource-specific fields
 * }
 */
export abstract class BaseResourceDto {
  /** Prefixed public ID (e.g., "aut_507f1f77bcf86cd799439011") */
  readonly id: string;

  /** ISO 8601 creation timestamp */
  readonly created_at: string;

  /** ISO 8601 last-update timestamp */
  readonly updated_at: string;

  /** HATEOAS links (included by default, opt-out via ?links=false) */
  readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    _links?: ResourceLinks;
  }) {
    this.id = parameters.id;
    this.created_at = parameters.created_at;
    this.updated_at = parameters.updated_at;
    this._links = parameters._links;
  }
}
