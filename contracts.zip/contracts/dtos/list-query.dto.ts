// ─── List Query DTO ───────────────────────────────────────────────────
// Base query DTO for all list endpoints.
// Supports cursor pagination, sorting, expansion, and field selection.
// Controllers extend this for resource-specific filters.

import {
  IsOptional,
  IsString,
  IsInt,
  IsArray,
  IsEnum,
  Min,
  Max,
} from 'class-validator';
import { Transform, Type } from 'class-transformer';

/** Sort direction */
export enum SortOrder {
  ASC = 'asc',
  DESC = 'desc',
}

/**
 * Base query DTO for all list endpoints.
 * Provides cursor pagination, sorting, expansion, and field selection.
 *
 * @example
 * GET /api/v1/automations?limit=20&cursor=eyJ...&sort_by=created_at&sort_order=desc&expand[]=bot&fields=id,name,status
 */
export class ListQueryDto {
  /** Page size (default: 20, max: 100) */
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(100)
  @Type(() => Number)
  limit: number = 20;

  /** Opaque cursor for pagination (from previous response) */
  @IsOptional()
  @IsString()
  cursor?: string;

  /** Sort field name (default: created_at) */
  @IsOptional()
  @IsString()
  @Transform(({ value }: { value: string }) => value?.trim())
  sort_by?: string = 'created_at';

  /** Sort direction */
  @IsOptional()
  @IsEnum(SortOrder)
  sort_order?: SortOrder = SortOrder.DESC;

  /** Expand related resources (e.g., expand[]=bot&expand[]=social_account) */
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Transform(({ value }: { value: string | string[] }) => {
    if (typeof value === 'string') {
      return value.split(',').map((v) => v.trim());
    }

    return Array.isArray(value) ? value : [];
  })
  'expand[]'?: string[];

  /** Sparse fieldset (e.g., fields=id,name,status) */
  @IsOptional()
  @IsString()
  @Transform(({ value }: { value: string }) => value?.trim())
  fields?: string;

  // ─── Backward Compatibility (deprecated) ──────────────────────────

  /** @deprecated Use cursor-based pagination instead. Will be removed in v2. */
  @IsOptional()
  @IsInt()
  @Min(1)
  @Type(() => Number)
  page?: number;
}
