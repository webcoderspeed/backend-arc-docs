// ─── DTOs — Barrel Export ──────────────────────────────────────────────

export {
  BaseResourceDto,
  type ResourceLink,
  type ResourceLinks,
} from './base-resource.dto';

export {
  encodeCursor,
  decodeCursor,
  buildCursorPaginationMeta,
  type CursorPayload,
  type CursorPaginationMeta,
} from './cursor-pagination.dto';

export { ListQueryDto, SortOrder } from './list-query.dto';

export {
  type SingleResourceEnvelope,
  type ListResourceEnvelope,
  type SerializeOptions,
  DEFAULT_SERIALIZE_OPTIONS,
  buildSerializeOptions,
} from './envelope.dto';

// Response DTOs (Phase 2)
export * from './responses';
