// ─── Cursor Pagination DTO ─────────────────────────────────────────────
// Encode/decode opaque cursors for cursor-based pagination.
// Cursor contains: { id, sortField?, sortValue? } → base64url encoded.
// Inspired by Stripe's starting_after / ending_before pattern.

/** Shape of data encoded inside a cursor */
export interface CursorPayload {
  /** The ObjectId of the edge item */
  readonly id: string;
  /** Optional sort field name (e.g., 'created_at') */
  readonly sortField?: string;
  /** Optional sort value for the edge item */
  readonly sortValue?: string | number;
}

/** Pagination metadata returned in API list responses */
export interface CursorPaginationMeta {
  /** Total count of matching resources (may be approximate for large sets) */
  readonly total: number;
  /** Page size used for this request */
  readonly limit: number;
  /** Whether more items exist after the current page */
  readonly has_more: boolean;
  /** Opaque cursor strings for next/previous navigation */
  readonly cursors: {
    readonly next: string | null;
    readonly previous: string | null;
  };
}

/**
 * Encode a cursor payload into a URL-safe base64 string.
 *
 * @example
 * encodeCursor({ id: '507f1f77bcf86cd799439011' })
 * // → 'eyJpZCI6IjUwN2YxZjc3YmNmODZjZDc5OTQzOTAxMSJ9'
 */
export function encodeCursor(payload: CursorPayload): string {
  const json = JSON.stringify(payload);

  return Buffer.from(json, 'utf8').toString('base64url');
}

/**
 * Decode a base64url cursor string back to its payload.
 *
 * @throws {Error} If the cursor is malformed or cannot be parsed
 *
 * @example
 * decodeCursor('eyJpZCI6IjUwN2YxZjc3YmNmODZjZDc5OTQzOTAxMSJ9')
 * // → { id: '507f1f77bcf86cd799439011' }
 */
export function decodeCursor(cursor: string): CursorPayload {
  try {
    const json = Buffer.from(cursor, 'base64url').toString('utf8');
    const parsed: unknown = JSON.parse(json);

    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Cursor payload is not an object');
    }

    const payload = parsed as Record<string, unknown>;

    if (typeof payload.id !== 'string' || payload.id.length === 0) {
      throw new Error('Cursor payload missing required "id" field');
    }

    return {
      id: payload.id,
      sortField:
        typeof payload.sortField === 'string' ? payload.sortField : undefined,
      sortValue: isSortValue(payload.sortValue) ? payload.sortValue : undefined,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid cursor: malformed base64 or JSON — "${cursor}"`);
    }

    throw error;
  }
}

/**
 * Build CursorPaginationMeta from a query result.
 *
 * @param items - The items returned (should be limit + 1 to detect has_more)
 * @param limit - The requested page size
 * @param total - The total count of matching items
 * @param sortField - Optional sort field used in the query
 */
export function buildCursorPaginationMeta<
  T extends { _id?: { toString(): string } },
>(
  items: readonly T[],
  limit: number,
  total: number,
  sortField?: string,
  sortValueAccessor?: (item: T) => string | number,
): CursorPaginationMeta {
  const hasMore = items.length > limit;
  const pageItems = hasMore ? items.slice(0, limit) : items;

  const lastItem = pageItems.at(-1);
  const firstItem = pageItems.at(0);

  const nextCursor =
    hasMore && lastItem?._id
      ? encodeCursor({
          id: lastItem._id.toString(),
          sortField,
          sortValue:
            sortValueAccessor && lastItem
              ? sortValueAccessor(lastItem)
              : undefined,
        })
      : null;

  const previousCursor = firstItem?._id
    ? encodeCursor({
        id: firstItem._id.toString(),
        sortField,
        sortValue:
          sortValueAccessor && firstItem
            ? sortValueAccessor(firstItem)
            : undefined,
      })
    : null;

  return {
    total,
    limit,
    has_more: hasMore,
    cursors: {
      next: nextCursor,
      previous: previousCursor,
    },
  };
}

// ─── Internal Helpers ──────────────────────────────────────────────────

function isSortValue(value: unknown): value is string | number {
  return typeof value === 'string' || typeof value === 'number';
}
