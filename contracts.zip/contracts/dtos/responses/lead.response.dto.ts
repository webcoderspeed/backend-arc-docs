import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';
import type { SocialAccountResponseDto } from './social-account.response.dto';

export interface LeadResponseMetadata {
  readonly [key: string]: string | number | boolean | null;
}

export class LeadResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly platform_user_id: string;

  readonly platform: string;

  readonly username: string;

  readonly full_name: string | null;

  readonly profile_picture: string | null;

  readonly tags: string[];

  readonly captured_from: string;

  readonly captured_at: string;

  readonly last_engaged: string | null;

  readonly metadata: LeadResponseMetadata;

  readonly social_account: SocialAccountResponseDto | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    platform_user_id: string;
    platform: string;
    username: string;
    full_name: string | null;
    profile_picture: string | null;
    tags: string[];
    captured_from: string;
    captured_at: string;
    last_engaged: string | null;
    metadata: LeadResponseMetadata;
    social_account?: SocialAccountResponseDto | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.platform_user_id = parameters.platform_user_id;
    this.platform = parameters.platform;
    this.username = parameters.username;
    this.full_name = parameters.full_name;
    this.profile_picture = parameters.profile_picture;
    this.tags = parameters.tags;
    this.captured_from = parameters.captured_from;
    this.captured_at = parameters.captured_at;
    this.last_engaged = parameters.last_engaged;
    this.metadata = parameters.metadata;
    this.social_account = parameters.social_account ?? null;
  }
}
