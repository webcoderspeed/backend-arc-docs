import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class OrderResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly credit_package_id: string;

  readonly status: string;

  readonly amount: number;

  readonly currency_id: string;

  readonly payment_provider: string | null;

  readonly total_amount: number;

  readonly tax_rate: number;

  readonly discount_amount: number;

  readonly paid_at: string | null;

  readonly cancelled_at: string | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    credit_package_id: string;
    status: string;
    amount: number;
    currency_id: string;
    payment_provider: string | null;
    total_amount: number;
    tax_rate: number;
    discount_amount: number;
    paid_at: string | null;
    cancelled_at: string | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.credit_package_id = parameters.credit_package_id;
    this.status = parameters.status;
    this.amount = parameters.amount;
    this.currency_id = parameters.currency_id;
    this.payment_provider = parameters.payment_provider;
    this.total_amount = parameters.total_amount;
    this.tax_rate = parameters.tax_rate;
    this.discount_amount = parameters.discount_amount;
    this.paid_at = parameters.paid_at;
    this.cancelled_at = parameters.cancelled_at;
  }
}
