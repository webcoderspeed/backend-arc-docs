import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class PaymentResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly order_id: string;

  readonly provider: string;

  readonly provider_payment_id: string;

  readonly status: string;

  readonly amount: number;

  readonly currency_id: string;

  readonly amount_refunded: number | null;

  readonly paid_at: string | null;

  readonly failed_at: string | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    order_id: string;
    provider: string;
    provider_payment_id: string;
    status: string;
    amount: number;
    currency_id: string;
    amount_refunded: number | null;
    paid_at: string | null;
    failed_at: string | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.order_id = parameters.order_id;
    this.provider = parameters.provider;
    this.provider_payment_id = parameters.provider_payment_id;
    this.status = parameters.status;
    this.amount = parameters.amount;
    this.currency_id = parameters.currency_id;
    this.amount_refunded = parameters.amount_refunded;
    this.paid_at = parameters.paid_at;
    this.failed_at = parameters.failed_at;
  }
}
