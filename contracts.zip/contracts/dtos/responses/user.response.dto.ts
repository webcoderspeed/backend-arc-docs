import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class UserResponseDto extends BaseResourceDto {
  readonly email: string;

  readonly first_name: string;

  readonly last_name: string;

  readonly phone: string | null;

  readonly is_verified: boolean;

  readonly status:
    | 'active'
    | 'suspended'
    | 'banned'
    | 'pending_verification'
    | 'inactive';

  readonly avatar_url: string | null;

  readonly timezone: string | null;

  readonly language: string;

  readonly role: 'user' | 'admin';

  readonly last_login_at: string | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    email: string;
    first_name: string;
    last_name: string;
    phone: string | null;
    is_verified: boolean;
    status:
      | 'active'
      | 'suspended'
      | 'banned'
      | 'pending_verification'
      | 'inactive';
    avatar_url: string | null;
    timezone: string | null;
    language: string;
    role: 'user' | 'admin';
    last_login_at: string | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.email = parameters.email;
    this.first_name = parameters.first_name;
    this.last_name = parameters.last_name;
    this.phone = parameters.phone;
    this.is_verified = parameters.is_verified;
    this.status = parameters.status;
    this.avatar_url = parameters.avatar_url;
    this.timezone = parameters.timezone;
    this.language = parameters.language;
    this.role = parameters.role;
    this.last_login_at = parameters.last_login_at;
  }
}
