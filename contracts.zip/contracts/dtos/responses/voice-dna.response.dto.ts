import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';
import type { BrandVoiceResponseDto } from './brand-voice.response.dto';

export class VoiceDnaResponseDto extends BaseResourceDto {
  readonly brand_voice_id: string;

  readonly user_id: string;

  readonly status: 'pending' | 'analyzing' | 'ready' | 'failed';

  readonly source: 'user_configured' | 'auto_inferred' | 'hybrid';

  readonly samples_analyzed: number;

  readonly analysis_model: string | null;

  readonly last_analyzed_at: string | null;

  readonly few_shot_count: number;

  readonly negative_example_count: number;

  readonly brand_voice: BrandVoiceResponseDto | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    brand_voice_id: string;
    user_id: string;
    status: 'pending' | 'analyzing' | 'ready' | 'failed';
    source: 'user_configured' | 'auto_inferred' | 'hybrid';
    samples_analyzed: number;
    analysis_model: string | null;
    last_analyzed_at: string | null;
    few_shot_count: number;
    negative_example_count: number;
    brand_voice?: BrandVoiceResponseDto | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.brand_voice_id = parameters.brand_voice_id;
    this.user_id = parameters.user_id;
    this.status = parameters.status;
    this.source = parameters.source;
    this.samples_analyzed = parameters.samples_analyzed;
    this.analysis_model = parameters.analysis_model;
    this.last_analyzed_at = parameters.last_analyzed_at;
    this.few_shot_count = parameters.few_shot_count;
    this.negative_example_count = parameters.negative_example_count;
    this.brand_voice = parameters.brand_voice ?? null;
  }
}
