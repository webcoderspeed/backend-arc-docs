import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export interface MessageAttachment {
  readonly type: string;
  readonly url: string;
  readonly name?: string;
}

export class MessageResponseDto extends BaseResourceDto {
  readonly conversation_id: string;

  readonly platform_message_id: string;

  readonly sender_id: string;

  readonly recipient_id: string;

  readonly text: string | null;

  readonly attachments: MessageAttachment[];

  readonly timestamp: string;

  readonly is_echo: boolean;

  readonly is_read: boolean;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    conversation_id: string;
    platform_message_id: string;
    sender_id: string;
    recipient_id: string;
    text: string | null;
    attachments: MessageAttachment[];
    timestamp: string;
    is_echo: boolean;
    is_read: boolean;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.conversation_id = parameters.conversation_id;
    this.platform_message_id = parameters.platform_message_id;
    this.sender_id = parameters.sender_id;
    this.recipient_id = parameters.recipient_id;
    this.text = parameters.text;
    this.attachments = parameters.attachments;
    this.timestamp = parameters.timestamp;
    this.is_echo = parameters.is_echo;
    this.is_read = parameters.is_read;
  }
}
