import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class SocialAccountResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly platform:
    | 'twitter'
    | 'instagram'
    | 'facebook'
    | 'linkedin'
    | 'youtube'
    | 'tiktok'
    | 'pinterest';

  readonly platform_user_id: string;

  readonly username: string;

  readonly avatar_url: string | null;

  readonly connected_at: string | null;

  readonly last_synced_at: string | null;

  readonly connection_status:
    | 'connected'
    | 'disconnected'
    | 'expired'
    | 'pending'
    | 'error';

  readonly is_active: boolean;

  readonly is_primary: boolean;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    platform:
      | 'twitter'
      | 'instagram'
      | 'facebook'
      | 'linkedin'
      | 'youtube'
      | 'tiktok'
      | 'pinterest';
    platform_user_id: string;
    username: string;
    avatar_url: string | null;
    connected_at: string | null;
    last_synced_at: string | null;
    connection_status:
      | 'connected'
      | 'disconnected'
      | 'expired'
      | 'pending'
      | 'error';
    is_active: boolean;
    is_primary: boolean;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.platform = parameters.platform;
    this.platform_user_id = parameters.platform_user_id;
    this.username = parameters.username;
    this.avatar_url = parameters.avatar_url;
    this.connected_at = parameters.connected_at;
    this.last_synced_at = parameters.last_synced_at;
    this.connection_status = parameters.connection_status;
    this.is_active = parameters.is_active;
    this.is_primary = parameters.is_primary;
  }
}
