import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';
import type { SocialAccountResponseDto } from './social-account.response.dto';
import type { MessageResponseDto } from './message.response.dto';

export class ConversationResponseDto extends BaseResourceDto {
  readonly social_account_id: string;

  readonly platform: string;

  readonly platform_conversation_id: string;

  readonly participants: string[];

  readonly last_message_at: string;

  readonly unread_count: number;

  readonly tags: string[];

  readonly detected_intent: string | null;

  readonly language: string | null;

  readonly sentiment: string;

  readonly total_interactions: number;

  readonly social_account: SocialAccountResponseDto | null;

  readonly messages: MessageResponseDto[] | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    social_account_id: string;
    platform: string;
    platform_conversation_id: string;
    participants: string[];
    last_message_at: string;
    unread_count: number;
    tags: string[];
    detected_intent: string | null;
    language: string | null;
    sentiment: string;
    total_interactions: number;
    social_account?: SocialAccountResponseDto | null;
    messages?: MessageResponseDto[] | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.social_account_id = parameters.social_account_id;
    this.platform = parameters.platform;
    this.platform_conversation_id = parameters.platform_conversation_id;
    this.participants = parameters.participants;
    this.last_message_at = parameters.last_message_at;
    this.unread_count = parameters.unread_count;
    this.tags = parameters.tags;
    this.detected_intent = parameters.detected_intent;
    this.language = parameters.language;
    this.sentiment = parameters.sentiment;
    this.total_interactions = parameters.total_interactions;
    this.social_account = parameters.social_account ?? null;
    this.messages = parameters.messages ?? null;
  }
}
