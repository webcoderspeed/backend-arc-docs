import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';
import type { BrandVoiceResponseDto } from './brand-voice.response.dto';
import type { SocialAccountResponseDto } from './social-account.response.dto';
/** CTA aggressiveness level for bot behavior */
export type BotCtaAggressiveness = 'none' | 'soft' | 'moderate' | 'aggressive';

export interface BotResponseBehavior {
  readonly auto_reply_enabled: boolean;
  readonly max_replies_per_hour: number;
  readonly max_replies_per_day: number;
  readonly reply_delay_min_seconds: number;
  readonly reply_delay_max_seconds: number;
  readonly escalation_threshold: number;
  readonly cta_aggressiveness: BotCtaAggressiveness;
  readonly should_reply_to_spam: boolean;
  readonly stop_after_escalation: boolean;
}

export interface BotResponseStats {
  readonly total_replies: number;
  readonly total_escalations: number;
  readonly total_skipped: number;
  readonly avg_confidence: number;
  readonly last_active_at: string | null;
}

export class BotResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly social_account_id: string;

  readonly brand_voice_id: string | null;

  readonly name: string;

  readonly description: string;

  readonly status: 'draft' | 'active' | 'paused' | 'archived';

  readonly is_active: boolean;

  readonly behavior: BotResponseBehavior;

  readonly stats: BotResponseStats;

  readonly knowledge_source_ids: string[];

  readonly social_account: SocialAccountResponseDto | null;

  readonly brand_voice: BrandVoiceResponseDto | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    social_account_id: string;
    brand_voice_id: string | null;
    name: string;
    description: string;
    status: 'draft' | 'active' | 'paused' | 'archived';
    is_active: boolean;
    behavior: BotResponseBehavior;
    stats: BotResponseStats;
    knowledge_source_ids: string[];
    social_account?: SocialAccountResponseDto | null;
    brand_voice?: BrandVoiceResponseDto | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.social_account_id = parameters.social_account_id;
    this.brand_voice_id = parameters.brand_voice_id;
    this.name = parameters.name;
    this.description = parameters.description;
    this.status = parameters.status;
    this.is_active = parameters.is_active;
    this.behavior = parameters.behavior;
    this.stats = parameters.stats;
    this.knowledge_source_ids = parameters.knowledge_source_ids;
    this.social_account = parameters.social_account ?? null;
    this.brand_voice = parameters.brand_voice ?? null;
  }
}
