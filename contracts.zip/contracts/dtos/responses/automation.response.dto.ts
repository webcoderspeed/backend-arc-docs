import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';
import type { BotResponseDto } from './bot.response.dto';
import type { SocialAccountResponseDto } from './social-account.response.dto';
import type { UserResponseDto } from './user.response.dto';

export interface AutomationTrigger {
  readonly type: string;
  readonly condition: string;
  readonly value: string | number | boolean | null;
}

export class AutomationTriggerResponseDto {
  readonly type: string;

  readonly condition: string;

  readonly value: string | number | boolean | null;

  constructor(parameters: {
    type: string;
    condition: string;
    value: string | number | boolean | null;
  }) {
    this.type = parameters.type;
    this.condition = parameters.condition;
    this.value = parameters.value;
  }
}

export interface AutomationAction {
  readonly type: string;
  readonly target: string;
  readonly payload: string | number | boolean | null;
}

export class AutomationActionResponseDto {
  readonly type: string;

  readonly target: string;

  readonly payload: string | number | boolean | null;

  constructor(parameters: {
    type: string;
    target: string;
    payload: string | number | boolean | null;
  }) {
    this.type = parameters.type;
    this.target = parameters.target;
    this.payload = parameters.payload;
  }
}

export interface AutomationCondition {
  readonly field: string;
  readonly operator: string;
  readonly value: string | number | boolean | null;
}

export class AutomationConditionResponseDto {
  readonly field: string;

  readonly operator: string;

  readonly value: string | number | boolean | null;

  constructor(parameters: {
    field: string;
    operator: string;
    value: string | number | boolean | null;
  }) {
    this.field = parameters.field;
    this.operator = parameters.operator;
    this.value = parameters.value;
  }
}

export class AutomationResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly name: string;

  readonly description: string;

  readonly platform: string;

  readonly status: string;

  readonly execution_mode: string;

  readonly social_account_id: string;

  readonly bot_id: string | null;

  readonly is_template: boolean;

  readonly version: number;

  readonly execution_count: number;

  readonly success_count: number;

  readonly failure_count: number;

  readonly last_executed_at: string | null;

  readonly triggers: AutomationTriggerResponseDto[];

  readonly actions: AutomationActionResponseDto[];

  readonly conditions: AutomationConditionResponseDto[];

  readonly bot: BotResponseDto | null;

  readonly social_account: SocialAccountResponseDto | null;

  readonly user: UserResponseDto | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    name: string;
    description: string;
    platform: string;
    status: string;
    execution_mode: string;
    social_account_id: string;
    bot_id: string | null;
    is_template: boolean;
    version: number;
    execution_count: number;
    success_count: number;
    failure_count: number;
    last_executed_at: string | null;
    triggers: AutomationTriggerResponseDto[];
    actions: AutomationActionResponseDto[];
    conditions: AutomationConditionResponseDto[];
    bot?: BotResponseDto | null;
    social_account?: SocialAccountResponseDto | null;
    user?: UserResponseDto | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.name = parameters.name;
    this.description = parameters.description;
    this.platform = parameters.platform;
    this.status = parameters.status;
    this.execution_mode = parameters.execution_mode;
    this.social_account_id = parameters.social_account_id;
    this.bot_id = parameters.bot_id;
    this.is_template = parameters.is_template;
    this.version = parameters.version;
    this.execution_count = parameters.execution_count;
    this.success_count = parameters.success_count;
    this.failure_count = parameters.failure_count;
    this.last_executed_at = parameters.last_executed_at;
    this.triggers = parameters.triggers;
    this.actions = parameters.actions;
    this.conditions = parameters.conditions;
    this.bot = parameters.bot ?? null;
    this.social_account = parameters.social_account ?? null;
    this.user = parameters.user ?? null;
  }
}
