import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export type NotificationResponseType =
  | 'order_completed'
  | 'bot_triggered'
  | 'automation_failed'
  | 'lead_captured'
  | 'message_received'
  | 'conversation_started'
  | 'social_account_disconnected'
  | 'system_alert'
  | 'credit_low'
  | 'subscription_expiring';

export class NotificationResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly title: string;

  readonly message: string;

  readonly type: NotificationResponseType;

  readonly status: 'unread' | 'read' | 'archived' | 'deleted';

  readonly priority: 'high' | 'medium' | 'low' | 'urgent';

  readonly action_url: string | null;

  readonly read_at: string | null;

  readonly is_broadcast: boolean;

  readonly target_channels: string[];

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    title: string;
    message: string;
    type: NotificationResponseType;
    status: 'unread' | 'read' | 'archived' | 'deleted';
    priority: 'high' | 'medium' | 'low' | 'urgent';
    action_url: string | null;
    read_at: string | null;
    is_broadcast: boolean;
    target_channels: string[];
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.title = parameters.title;
    this.message = parameters.message;
    this.type = parameters.type;
    this.status = parameters.status;
    this.priority = parameters.priority;
    this.action_url = parameters.action_url;
    this.read_at = parameters.read_at;
    this.is_broadcast = parameters.is_broadcast;
    this.target_channels = parameters.target_channels;
  }
}
