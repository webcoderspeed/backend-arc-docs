import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class MediaResponseDto extends BaseResourceDto {
  readonly name: string;

  readonly original_name: string;

  readonly size_bytes: number;

  readonly mime_type: string;

  readonly url: string;

  readonly thumbnail_url: string | null;

  readonly width: number | null;

  readonly height: number | null;

  readonly duration_seconds: number | null;

  readonly status: 'active' | 'inactive' | 'processing' | 'failed';

  readonly tags: string[];

  readonly category: string | null;

  readonly alt_text: string | null;

  readonly is_public: boolean;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    name: string;
    original_name: string;
    size_bytes: number;
    mime_type: string;
    url: string;
    thumbnail_url: string | null;
    width: number | null;
    height: number | null;
    duration_seconds: number | null;
    status: 'active' | 'inactive' | 'processing' | 'failed';
    tags: string[];
    category: string | null;
    alt_text: string | null;
    is_public: boolean;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.name = parameters.name;
    this.original_name = parameters.original_name;
    this.size_bytes = parameters.size_bytes;
    this.mime_type = parameters.mime_type;
    this.url = parameters.url;
    this.thumbnail_url = parameters.thumbnail_url;
    this.width = parameters.width;
    this.height = parameters.height;
    this.duration_seconds = parameters.duration_seconds;
    this.status = parameters.status;
    this.tags = parameters.tags;
    this.category = parameters.category;
    this.alt_text = parameters.alt_text;
    this.is_public = parameters.is_public;
  }
}
