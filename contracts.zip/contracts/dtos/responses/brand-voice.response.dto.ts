import { BaseResourceDto, type ResourceLinks } from '../base-resource.dto';

export class BrandVoiceResponseDto extends BaseResourceDto {
  readonly user_id: string;

  readonly name: string;

  readonly description: string | null;

  readonly tone_primary: string;

  readonly tone_intensity: number;

  readonly formality: string;

  readonly language: string;

  readonly keywords_to_include: string[];

  readonly keywords_to_avoid: string[];

  readonly preferred_greetings: string[];

  readonly response_length: string;

  readonly use_emojis: boolean;

  readonly emoji_intensity: number;

  readonly company_name: string | null;

  readonly company_description: string | null;

  declare readonly _links?: ResourceLinks;

  constructor(parameters: {
    id: string;
    created_at: string;
    updated_at: string;
    user_id: string;
    name: string;
    description: string | null;
    tone_primary: string;
    tone_intensity: number;
    formality: string;
    language: string;
    keywords_to_include: string[];
    keywords_to_avoid: string[];
    preferred_greetings: string[];
    response_length: string;
    use_emojis: boolean;
    emoji_intensity: number;
    company_name: string | null;
    company_description: string | null;
    _links?: ResourceLinks;
  }) {
    super({
      id: parameters.id,
      created_at: parameters.created_at,
      updated_at: parameters.updated_at,
      _links: parameters._links,
    });
    this.user_id = parameters.user_id;
    this.name = parameters.name;
    this.description = parameters.description;
    this.tone_primary = parameters.tone_primary;
    this.tone_intensity = parameters.tone_intensity;
    this.formality = parameters.formality;
    this.language = parameters.language;
    this.keywords_to_include = parameters.keywords_to_include;
    this.keywords_to_avoid = parameters.keywords_to_avoid;
    this.preferred_greetings = parameters.preferred_greetings;
    this.response_length = parameters.response_length;
    this.use_emojis = parameters.use_emojis;
    this.emoji_intensity = parameters.emoji_intensity;
    this.company_name = parameters.company_name;
    this.company_description = parameters.company_description;
  }
}
