import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { UserResponseDto } from '../dtos/responses/user.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface UserSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly email: string;
  readonly first_name: string;
  readonly last_name: string;
  readonly phone?: string | null;
  readonly is_verified: boolean;
  readonly status:
    | 'active'
    | 'suspended'
    | 'banned'
    | 'pending_verification'
    | 'inactive';
  readonly avatar_id?: DocumentId | null;
  readonly timezone?: string | null;
  readonly language: string;
  readonly role: 'user' | 'admin';
  readonly last_login_at?: Date | null;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for User resources.
 * Converts Mongoose documents to UserResponseDto instances.
 */
export class UserSerializer {
  static serialize(
    document: UserSerializerDocument,
    options: SerializeOptions,
  ): UserResponseDto {
    const id = toPublicId('user', document._id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/users/${id}` },
          update: { href: `${options.basePath}/users/${id}`, method: 'PATCH' },
          delete: { href: `${options.basePath}/users/${id}`, method: 'DELETE' },
        }
      : undefined;

    return new UserResponseDto({
      id,
      created_at,
      updated_at,
      email: document.email,
      first_name: document.first_name,
      last_name: document.last_name,
      phone: document.phone ?? null,
      is_verified: document.is_verified,
      status: document.status,
      avatar_url: null, // Avatar URL would need to be fetched from media service
      timezone: document.timezone ?? null,
      language: document.language,
      role: document.role,
      last_login_at: document.last_login_at
        ? toIso(document.last_login_at)
        : null,
      _links,
    });
  }

  static serializeList(
    documents: UserSerializerDocument[],
    options: SerializeOptions,
  ): UserResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
