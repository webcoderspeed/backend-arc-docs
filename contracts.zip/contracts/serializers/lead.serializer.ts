import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { LeadResponseDto } from '../dtos/responses/lead.response.dto';
import {
  SocialAccountSerializer,
  type SocialAccountSerializerDocument,
} from './social-account.serializer';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface LeadSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly platform_user_id: string;
  readonly platform: string;
  readonly username: string;
  readonly full_name?: string | null;
  readonly profile_picture?: string | null;
  readonly tags: string[];
  readonly captured_from: string;
  readonly captured_at: Date;
  readonly last_engaged?: Date | null;
  readonly metadata: {
    readonly comment_id?: string;
    readonly message_id?: string;
    readonly post_url?: string;
    readonly automation_id?: string;
    readonly conversation_id?: string;
  };
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Lead resources.
 * Converts Mongoose documents to LeadResponseDto instances.
 * Supports expansion of social_account.
 */
export class LeadSerializer {
  static serialize(
    document: LeadSerializerDocument,
    options: SerializeOptions,
  ): LeadResponseDto {
    const id = toPublicId('lead', document._id);
    const userId = toPublicId('user', document.user_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Handle expanded social_account field
    const socialAccount =
      options.expand.has('social_account') &&
      options.expandedData?.get('social_account')
        ? SocialAccountSerializer.serialize(
            options.expandedData.get(
              'social_account',
            ) as SocialAccountSerializerDocument,
            options,
          )
        : null;

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/leads/${id}` },
          engage: {
            href: `${options.basePath}/leads/${id}/engage`,
            method: 'POST',
          },
          updateTags: {
            href: `${options.basePath}/leads/${id}/tags`,
            method: 'PATCH',
          },
        }
      : undefined;

    return new LeadResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      platform_user_id: document.platform_user_id,
      platform: document.platform,
      username: document.username,
      full_name: document.full_name ?? null,
      profile_picture: document.profile_picture ?? null,
      tags: document.tags,
      captured_from: document.captured_from,
      captured_at: toIso(document.captured_at) || new Date().toISOString(),
      last_engaged: document.last_engaged ? toIso(document.last_engaged) : null,
      metadata: { ...document.metadata },
      social_account: socialAccount,
      _links,
    });
  }

  static serializeList(
    documents: LeadSerializerDocument[],
    options: SerializeOptions,
  ): LeadResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
