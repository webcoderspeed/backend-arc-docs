// ─── Serializers ───────────────────────────────────────────────────────────
// Serializers convert Mongoose documents to typed response DTOs.
// Each serializer includes a static serialize() and serializeList() method.

export { UserSerializer, type UserSerializerDocument } from './user.serializer';
export {
  MediaSerializer,
  type MediaSerializerDocument,
} from './media.serializer';
export {
  SocialAccountSerializer,
  type SocialAccountSerializerDocument,
} from './social-account.serializer';
export {
  NotificationSerializer,
  type NotificationSerializerDocument,
} from './notification.serializer';
export {
  BrandVoiceSerializer,
  type BrandVoiceSerializerDocument,
} from './brand-voice.serializer';
export { BotSerializer, type BotSerializerDocument } from './bot.serializer';
export {
  VoiceDnaSerializer,
  type VoiceDnaSerializerDocument,
} from './voice-dna.serializer';
export { LeadSerializer, type LeadSerializerDocument } from './lead.serializer';
export {
  MessageSerializer,
  type MessageSerializerDocument,
} from './message.serializer';
export {
  ConversationSerializer,
  type ConversationSerializerDocument,
  type ConversationSerializerParticipant,
} from './conversation.serializer';
export {
  AutomationSerializer,
  type AutomationSerializerDocument,
  type AutomationTriggerDocument,
  type AutomationActionDocument,
  type AutomationConditionDocument,
} from './automation.serializer';
export {
  OrderSerializer,
  type OrderSerializerDocument,
} from './order.serializer';
export {
  PaymentSerializer,
  type PaymentSerializerDocument,
} from './payment.serializer';
