import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import {
  MessageResponseDto,
  type MessageAttachment,
} from '../dtos/responses/message.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface MessageSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly conversation_id: DocumentId;
  readonly platform_message_id: string;
  readonly sender_id: string;
  readonly recipient_id: string;
  readonly text?: string | null;
  readonly attachments?: {
    type: string;
    payload?: unknown;
    attachment_id?: DocumentId;
  }[];
  readonly timestamp: Date;
  readonly is_echo: boolean;
  readonly is_read: boolean;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Message resources.
 * Converts Mongoose documents to MessageResponseDto instances.
 */
export class MessageSerializer {
  static serialize(
    document: MessageSerializerDocument,
    options: SerializeOptions,
  ): MessageResponseDto {
    const id = toPublicId('message', document._id);
    const conversationId = toPublicId('conversation', document.conversation_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Transform attachments to match response DTO
    const attachments: MessageAttachment[] =
      document.attachments?.map((att) => ({
        type: att.type,
        url: '', // URL would need to be computed from attachment_id or payload
        name: undefined,
      })) ?? [];

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/messages/${id}` },
          markAsRead: {
            href: `${options.basePath}/messages/${id}/read`,
            method: 'POST',
          },
        }
      : undefined;

    return new MessageResponseDto({
      id,
      created_at,
      updated_at,
      conversation_id: conversationId,
      platform_message_id: document.platform_message_id,
      sender_id: document.sender_id,
      recipient_id: document.recipient_id,
      text: document.text ?? null,
      attachments,
      timestamp: toIso(document.timestamp) || new Date().toISOString(),
      is_echo: document.is_echo,
      is_read: document.is_read,
      _links,
    });
  }

  static serializeList(
    documents: MessageSerializerDocument[],
    options: SerializeOptions,
  ): MessageResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
