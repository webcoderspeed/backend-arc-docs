import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { PaymentResponseDto } from '../dtos/responses/payment.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface PaymentSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly order_id: DocumentId;
  readonly provider: string;
  readonly provider_payment_id: string;
  readonly status: string;
  readonly amount: number;
  readonly currency_id: DocumentId;
  readonly amount_refunded?: number | null;
  readonly paid_at?: Date | null;
  readonly failed_at?: Date | null;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Payment resources.
 * Converts Mongoose documents to PaymentResponseDto instances.
 */
export class PaymentSerializer {
  static serialize(
    document: PaymentSerializerDocument,
    options: SerializeOptions,
  ): PaymentResponseDto {
    const id = toPublicId('payment', document._id);
    const userId = toPublicId('user', document.user_id);
    const orderId = toPublicId('order', document.order_id);
    const currencyId = toPublicId('currency', document.currency_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/payments/${id}` },
          refund: {
            href: `${options.basePath}/payments/${id}/refund`,
            method: 'POST',
          },
          receipt: {
            href: `${options.basePath}/payments/${id}/receipt`,
            method: 'GET',
          },
        }
      : undefined;

    return new PaymentResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      order_id: orderId,
      provider: document.provider,
      provider_payment_id: document.provider_payment_id,
      status: document.status,
      amount: document.amount,
      currency_id: currencyId,
      amount_refunded: document.amount_refunded ?? null,
      paid_at: document.paid_at ? toIso(document.paid_at) : null,
      failed_at: document.failed_at ? toIso(document.failed_at) : null,
      _links,
    });
  }

  static serializeList(
    documents: PaymentSerializerDocument[],
    options: SerializeOptions,
  ): PaymentResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
