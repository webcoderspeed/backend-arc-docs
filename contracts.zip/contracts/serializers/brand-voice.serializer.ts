import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { BrandVoiceResponseDto } from '../dtos/responses/brand-voice.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface BrandVoiceSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly name: string;
  readonly description?: string | null;
  readonly tone_primary: string;
  readonly tone_intensity: number;
  readonly formality: string;
  readonly language: string;
  readonly keywords_to_include: string[];
  readonly keywords_to_avoid: string[];
  readonly preferred_greetings: string[];
  readonly response_length: string;
  readonly use_emojis: boolean;
  readonly emoji_intensity: number;
  readonly company_name?: string | null;
  readonly company_description?: string | null;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for BrandVoice resources.
 * Converts Mongoose documents to BrandVoiceResponseDto instances.
 */
export class BrandVoiceSerializer {
  static serialize(
    document: BrandVoiceSerializerDocument,
    options: SerializeOptions,
  ): BrandVoiceResponseDto {
    const id = toPublicId('brand_voice', document._id);
    const userId = toPublicId('user', document.user_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/brand-voices/${id}` },
          update: {
            href: `${options.basePath}/brand-voices/${id}`,
            method: 'PATCH',
          },
          delete: {
            href: `${options.basePath}/brand-voices/${id}`,
            method: 'DELETE',
          },
        }
      : undefined;

    return new BrandVoiceResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      name: document.name,
      description: document.description ?? null,
      tone_primary: document.tone_primary,
      tone_intensity: document.tone_intensity,
      formality: document.formality,
      language: document.language,
      keywords_to_include: document.keywords_to_include,
      keywords_to_avoid: document.keywords_to_avoid,
      preferred_greetings: document.preferred_greetings,
      response_length: document.response_length,
      use_emojis: document.use_emojis,
      emoji_intensity: document.emoji_intensity,
      company_name: document.company_name ?? null,
      company_description: document.company_description ?? null,
      _links,
    });
  }

  static serializeList(
    documents: BrandVoiceSerializerDocument[],
    options: SerializeOptions,
  ): BrandVoiceResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
