import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { ConversationResponseDto } from '../dtos/responses/conversation.response.dto';
import {
  SocialAccountSerializer,
  type SocialAccountSerializerDocument,
} from './social-account.serializer';
import {
  MessageSerializer,
  type MessageSerializerDocument,
} from './message.serializer';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface ConversationSerializerParticipant {
  readonly id: string;
  readonly username?: string;
  readonly name?: string;
  readonly avatar_url?: string;
}

export interface ConversationSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly social_account_id: DocumentId;
  readonly platform: string;
  readonly platform_conversation_id: string;
  readonly participants: ConversationSerializerParticipant[];
  readonly last_message_at: Date;
  readonly unread_count: number;
  readonly tags: string[];
  readonly detected_intent?: string | null;
  readonly language?: string | null;
  readonly sentiment: string;
  readonly total_interactions: number;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Conversation resources.
 * Converts Mongoose documents to ConversationResponseDto instances.
 * Supports expansion of social_account and messages.
 */
export class ConversationSerializer {
  static serialize(
    document: ConversationSerializerDocument,
    options: SerializeOptions,
  ): ConversationResponseDto {
    const id = toPublicId('conversation', document._id);
    const socialAccountId = toPublicId(
      'social_account',
      document.social_account_id,
    );
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Handle expanded social_account field
    const socialAccount =
      options.expand.has('social_account') &&
      options.expandedData?.get('social_account')
        ? SocialAccountSerializer.serialize(
            options.expandedData.get(
              'social_account',
            ) as SocialAccountSerializerDocument,
            options,
          )
        : null;

    // Handle expanded messages field
    const messages =
      options.expand.has('messages') && options.expandedData?.get('messages')
        ? (
            options.expandedData.get('messages') as MessageSerializerDocument[]
          ).map((message) => MessageSerializer.serialize(message, options))
        : null;

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/conversations/${id}` },
          sendMessage: {
            href: `${options.basePath}/conversations/${id}/messages`,
            method: 'POST',
          },
          markAsRead: {
            href: `${options.basePath}/conversations/${id}/read`,
            method: 'POST',
          },
          archive: {
            href: `${options.basePath}/conversations/${id}/archive`,
            method: 'POST',
          },
        }
      : undefined;

    return new ConversationResponseDto({
      id,
      created_at,
      updated_at,
      social_account_id: socialAccountId,
      platform: document.platform,
      platform_conversation_id: document.platform_conversation_id,
      participants: document.participants.map((p) => p.id),
      last_message_at:
        toIso(document.last_message_at) || new Date().toISOString(),
      unread_count: document.unread_count,
      tags: document.tags,
      detected_intent: document.detected_intent ?? null,
      language: document.language ?? null,
      sentiment: document.sentiment,
      total_interactions: document.total_interactions,
      social_account: socialAccount,
      messages,
      _links,
    });
  }

  static serializeList(
    documents: ConversationSerializerDocument[],
    options: SerializeOptions,
  ): ConversationResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
