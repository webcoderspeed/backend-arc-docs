import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { VoiceDnaResponseDto } from '../dtos/responses/voice-dna.response.dto';
import {
  BrandVoiceSerializer,
  type BrandVoiceSerializerDocument,
} from './brand-voice.serializer';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface VoiceDnaSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly brand_voice_id: DocumentId;
  readonly user_id: DocumentId;
  readonly status: 'pending' | 'analyzing' | 'ready' | 'failed';
  readonly source: 'user_configured' | 'auto_inferred' | 'hybrid';
  readonly samples_analyzed: number;
  readonly analysis_model?: string | null;
  readonly last_analyzed_at?: Date | null;
  readonly few_shot_examples?: {
    context: string;
    reply: string;
    tags: string[];
  }[];
  readonly negative_examples?: {
    context: string;
    reply: string;
    tags: string[];
  }[];
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for VoiceDna resources.
 * Converts Mongoose documents to VoiceDnaResponseDto instances.
 * Supports expansion of brand_voice.
 */
export class VoiceDnaSerializer {
  static serialize(
    document: VoiceDnaSerializerDocument,
    options: SerializeOptions,
  ): VoiceDnaResponseDto {
    const id = toPublicId('voice_dna', document._id);
    const brandVoiceId = toPublicId('brand_voice', document.brand_voice_id);
    const userId = toPublicId('user', document.user_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Handle expanded brand_voice field
    const brandVoice =
      options.expand.has('brand_voice') &&
      options.expandedData?.get('brand_voice')
        ? BrandVoiceSerializer.serialize(
            options.expandedData.get(
              'brand_voice',
            ) as BrandVoiceSerializerDocument,
            options,
          )
        : null;

    const fewShotCount = document.few_shot_examples?.length ?? 0;
    const negativeExampleCount = document.negative_examples?.length ?? 0;

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/voice-dna/${id}` },
          analyze: {
            href: `${options.basePath}/voice-dna/${id}/analyze`,
            method: 'POST',
          },
          update: {
            href: `${options.basePath}/voice-dna/${id}`,
            method: 'PATCH',
          },
        }
      : undefined;

    return new VoiceDnaResponseDto({
      id,
      created_at,
      updated_at,
      brand_voice_id: brandVoiceId,
      user_id: userId,
      status: document.status,
      source: document.source,
      samples_analyzed: document.samples_analyzed,
      analysis_model: document.analysis_model ?? null,
      last_analyzed_at: document.last_analyzed_at
        ? toIso(document.last_analyzed_at)
        : null,
      few_shot_count: fewShotCount,
      negative_example_count: negativeExampleCount,
      brand_voice: brandVoice,
      _links,
    });
  }

  static serializeList(
    documents: VoiceDnaSerializerDocument[],
    options: SerializeOptions,
  ): VoiceDnaResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
