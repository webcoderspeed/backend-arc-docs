import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { SocialAccountResponseDto } from '../dtos/responses/social-account.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface SocialAccountSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly platform:
    | 'twitter'
    | 'instagram'
    | 'facebook'
    | 'linkedin'
    | 'youtube'
    | 'tiktok'
    | 'pinterest';
  readonly platform_user_id: string;
  readonly username: string;
  readonly avatar_id?: DocumentId | null;
  readonly connected_at?: Date | null;
  readonly last_synced_at?: Date | null;
  readonly connection_status:
    | 'connected'
    | 'disconnected'
    | 'expired'
    | 'pending'
    | 'error';
  readonly is_active: boolean;
  readonly is_primary: boolean;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for SocialAccount resources.
 * Converts Mongoose documents to SocialAccountResponseDto instances.
 */
export class SocialAccountSerializer {
  static serialize(
    document: SocialAccountSerializerDocument,
    options: SerializeOptions,
  ): SocialAccountResponseDto {
    const id = toPublicId('social_account', document._id);
    const userId = toPublicId('user', document.user_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/social-accounts/${id}` },
          sync: {
            href: `${options.basePath}/social-accounts/${id}/sync`,
            method: 'POST',
          },
          disconnect: {
            href: `${options.basePath}/social-accounts/${id}/disconnect`,
            method: 'POST',
          },
        }
      : undefined;

    return new SocialAccountResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      platform: document.platform,
      platform_user_id: document.platform_user_id,
      username: document.username,
      avatar_url: null, // Avatar URL would need to be fetched from media service
      connected_at: document.connected_at ? toIso(document.connected_at) : null,
      last_synced_at: document.last_synced_at
        ? toIso(document.last_synced_at)
        : null,
      connection_status: document.connection_status,
      is_active: document.is_active,
      is_primary: document.is_primary,
      _links,
    });
  }

  static serializeList(
    documents: SocialAccountSerializerDocument[],
    options: SerializeOptions,
  ): SocialAccountResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
