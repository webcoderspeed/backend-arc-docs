import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { MediaResponseDto } from '../dtos/responses/media.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface MediaSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly name: string;
  readonly original_name: string;
  readonly size_bytes: number;
  readonly mime_type: string;
  readonly url: string;
  readonly thumbnail_url?: string | null;
  readonly width?: number | null;
  readonly height?: number | null;
  readonly duration_seconds?: number | null;
  readonly status: 'active' | 'inactive' | 'processing' | 'failed';
  readonly tags: string[];
  readonly category?: string | null;
  readonly alt_text?: string | null;
  readonly is_public: boolean;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Media resources.
 * Converts Mongoose documents to MediaResponseDto instances.
 */
export class MediaSerializer {
  static serialize(
    document: MediaSerializerDocument,
    options: SerializeOptions,
  ): MediaResponseDto {
    const id = toPublicId('media', document._id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/media/${id}` },
          download: {
            href: `${options.basePath}/media/${id}/download`,
            method: 'GET',
          },
          delete: { href: `${options.basePath}/media/${id}`, method: 'DELETE' },
        }
      : undefined;

    return new MediaResponseDto({
      id,
      created_at,
      updated_at,
      name: document.name,
      original_name: document.original_name,
      size_bytes: document.size_bytes,
      mime_type: document.mime_type,
      url: document.url,
      thumbnail_url: document.thumbnail_url ?? null,
      width: document.width ?? null,
      height: document.height ?? null,
      duration_seconds: document.duration_seconds ?? null,
      status: document.status,
      tags: document.tags,
      category: document.category ?? null,
      alt_text: document.alt_text ?? null,
      is_public: document.is_public,
      _links,
    });
  }

  static serializeList(
    documents: MediaSerializerDocument[],
    options: SerializeOptions,
  ): MediaResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
