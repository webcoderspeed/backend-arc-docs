import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import {
  AutomationResponseDto,
  AutomationTriggerResponseDto,
  AutomationActionResponseDto,
  AutomationConditionResponseDto,
} from '../dtos/responses/automation.response.dto';
import { BotSerializer, type BotSerializerDocument } from './bot.serializer';
import {
  SocialAccountSerializer,
  type SocialAccountSerializerDocument,
} from './social-account.serializer';
import { UserSerializer, type UserSerializerDocument } from './user.serializer';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interfaces for type safety
export interface AutomationTriggerDocument {
  readonly type: string;
  readonly condition: string;
  readonly value: string | number | boolean | null;
}

export interface AutomationActionDocument {
  readonly type: string;
  readonly target: string;
  readonly payload: string | number | boolean | null;
}

export interface AutomationConditionDocument {
  readonly field: string;
  readonly operator: string;
  readonly value: string | number | boolean | null;
}

export interface AutomationSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly name: string;
  readonly description?: string;
  readonly platform: string;
  readonly status: string;
  readonly execution_mode: string;
  readonly social_account_id: DocumentId;
  readonly bot_id?: DocumentId | null;
  readonly is_template: boolean;
  readonly version: number;
  readonly execution_count: number;
  readonly success_count: number;
  readonly failure_count: number;
  readonly last_executed_at?: Date | null;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Automation resources.
 * Converts Mongoose documents to AutomationResponseDto instances.
 * Supports expansion of bot, social_account, and user.
 */
export class AutomationSerializer {
  static serialize(
    document: AutomationSerializerDocument,
    options: SerializeOptions,
    triggers: AutomationTriggerDocument[] = [],
    actions: AutomationActionDocument[] = [],
    conditions: AutomationConditionDocument[] = [],
  ): AutomationResponseDto {
    const id = toPublicId('automation', document._id);
    const userId = toPublicId('user', document.user_id);
    const socialAccountId = toPublicId(
      'social_account',
      document.social_account_id,
    );
    const botId = document.bot_id ? toPublicId('bot', document.bot_id) : null;
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Handle expanded bot field
    const bot =
      options.expand.has('bot') && options.expandedData?.get('bot')
        ? BotSerializer.serialize(
            options.expandedData.get('bot') as BotSerializerDocument,
            options,
          )
        : null;

    // Handle expanded social_account field
    const socialAccount =
      options.expand.has('social_account') &&
      options.expandedData?.get('social_account')
        ? SocialAccountSerializer.serialize(
            options.expandedData.get(
              'social_account',
            ) as SocialAccountSerializerDocument,
            options,
          )
        : null;

    // Handle expanded user field
    const user =
      options.expand.has('user') && options.expandedData?.get('user')
        ? UserSerializer.serialize(
            options.expandedData.get('user') as UserSerializerDocument,
            options,
          )
        : null;

    // Serialize trigger documents
    const triggerDtos = triggers.map(
      (t) =>
        new AutomationTriggerResponseDto({
          type: t.type,
          condition: t.condition,
          value: t.value,
        }),
    );

    // Serialize action documents
    const actionDtos = actions.map(
      (a) =>
        new AutomationActionResponseDto({
          type: a.type,
          target: a.target,
          payload: a.payload,
        }),
    );

    // Serialize condition documents
    const conditionDtos = conditions.map(
      (c) =>
        new AutomationConditionResponseDto({
          field: c.field,
          operator: c.operator,
          value: c.value,
        }),
    );

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/automations/${id}` },
          activate: {
            href: `${options.basePath}/automations/${id}/activate`,
            method: 'POST',
          },
          pause: {
            href: `${options.basePath}/automations/${id}/pause`,
            method: 'POST',
          },
          execute: {
            href: `${options.basePath}/automations/${id}/execute`,
            method: 'POST',
          },
          update: {
            href: `${options.basePath}/automations/${id}`,
            method: 'PATCH',
          },
          delete: {
            href: `${options.basePath}/automations/${id}`,
            method: 'DELETE',
          },
        }
      : undefined;

    return new AutomationResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      name: document.name,
      description: document.description ?? '',
      platform: document.platform,
      status: document.status,
      execution_mode: document.execution_mode,
      social_account_id: socialAccountId,
      bot_id: botId,
      is_template: document.is_template,
      version: document.version,
      execution_count: document.execution_count,
      success_count: document.success_count,
      failure_count: document.failure_count,
      last_executed_at: document.last_executed_at
        ? toIso(document.last_executed_at)
        : null,
      triggers: triggerDtos,
      actions: actionDtos,
      conditions: conditionDtos,
      bot,
      social_account: socialAccount,
      user,
      _links,
    });
  }

  static serializeList(
    documents: {
      doc: AutomationSerializerDocument;
      triggers?: AutomationTriggerDocument[];
      actions?: AutomationActionDocument[];
      conditions?: AutomationConditionDocument[];
    }[],
    options: SerializeOptions,
  ): AutomationResponseDto[] {
    return documents.map((item) =>
      this.serialize(
        item.doc,
        options,
        item.triggers ?? [],
        item.actions ?? [],
        item.conditions ?? [],
      ),
    );
  }
}
