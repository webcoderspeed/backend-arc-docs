import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import { OrderResponseDto } from '../dtos/responses/order.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface OrderSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly credit_package_id: DocumentId;
  readonly status: string;
  readonly amount: number;
  readonly currency_id: DocumentId;
  readonly payment_provider?: string | null;
  readonly total_amount: number;
  readonly tax_rate: number;
  readonly discount_amount: number;
  readonly paid_at?: Date | null;
  readonly cancelled_at?: Date | null;
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Order resources.
 * Converts Mongoose documents to OrderResponseDto instances.
 */
export class OrderSerializer {
  static serialize(
    document: OrderSerializerDocument,
    options: SerializeOptions,
  ): OrderResponseDto {
    const id = toPublicId('order', document._id);
    const userId = toPublicId('user', document.user_id);
    const creditPackageId = toPublicId(
      'credit_package',
      document.credit_package_id,
    );
    const currencyId = toPublicId('currency', document.currency_id);
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/orders/${id}` },
          pay: { href: `${options.basePath}/orders/${id}/pay`, method: 'POST' },
          cancel: {
            href: `${options.basePath}/orders/${id}/cancel`,
            method: 'POST',
          },
          invoice: {
            href: `${options.basePath}/orders/${id}/invoice`,
            method: 'GET',
          },
        }
      : undefined;

    return new OrderResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      credit_package_id: creditPackageId,
      status: document.status,
      amount: document.amount,
      currency_id: currencyId,
      payment_provider: document.payment_provider ?? null,
      total_amount: document.total_amount,
      tax_rate: document.tax_rate,
      discount_amount: document.discount_amount,
      paid_at: document.paid_at ? toIso(document.paid_at) : null,
      cancelled_at: document.cancelled_at ? toIso(document.cancelled_at) : null,
      _links,
    });
  }

  static serializeList(
    documents: OrderSerializerDocument[],
    options: SerializeOptions,
  ): OrderResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
