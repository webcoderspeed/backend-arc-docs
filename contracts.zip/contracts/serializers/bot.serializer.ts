import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import {
  BotResponseDto,
  type BotResponseBehavior,
  type BotResponseStats,
} from '../dtos/responses/bot.response.dto';
import type { BotCtaAggressiveness } from '../dtos/responses/bot.response.dto';
import {
  BrandVoiceSerializer,
  type BrandVoiceSerializerDocument,
} from './brand-voice.serializer';
import {
  SocialAccountSerializer,
  type SocialAccountSerializerDocument,
} from './social-account.serializer';
import type { SerializeOptions } from '../dtos/envelope.dto';

/** Input behavior shape from the Mongoose BotBehavior schema */
export interface BotInputBehavior {
  readonly auto_reply_enabled: boolean;
  readonly max_replies_per_hour: number;
  readonly max_replies_per_day: number;
  readonly reply_delay_min_seconds: number;
  readonly reply_delay_max_seconds: number;
  readonly escalation_threshold: number;
  readonly cta_aggressiveness: BotCtaAggressiveness;
  readonly should_reply_to_spam: boolean;
  readonly stop_after_escalation: boolean;
}

/** Input stats shape from the Mongoose BotStats schema */
export interface BotInputStats {
  readonly total_replies: number;
  readonly total_escalations: number;
  readonly total_skipped: number;
  readonly avg_confidence: number;
  readonly last_active_at?: Date;
}

/** Minimal document interface for type safety representing actual Mongoose document */
export interface BotSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id: DocumentId;
  readonly social_account_id: DocumentId;
  readonly brand_voice_id?: DocumentId | null;
  readonly name: string;
  readonly description: string;
  readonly status: 'draft' | 'active' | 'paused' | 'archived';
  readonly is_active: boolean;
  readonly behavior: BotInputBehavior;
  readonly stats: BotInputStats;
  readonly knowledge_sources?: {
    source_id: Types.ObjectId | string;
    weight: number;
  }[];
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Bot resources.
 * Converts Mongoose documents to BotResponseDto instances.
 * Supports expansion of social_account and brand_voice.
 */
export class BotSerializer {
  static serialize(
    document: BotSerializerDocument,
    options: SerializeOptions,
  ): BotResponseDto {
    const id = toPublicId('bot', document._id);
    const userId = toPublicId('user', document.user_id);
    const socialAccountId = toPublicId(
      'social_account',
      document.social_account_id,
    );
    const brandVoiceId = document.brand_voice_id
      ? toPublicId('brand_voice', document.brand_voice_id)
      : null;
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    // Handle expanded fields
    const socialAccount =
      options.expand.has('social_account') &&
      options.expandedData?.get('social_account')
        ? SocialAccountSerializer.serialize(
            options.expandedData.get(
              'social_account',
            ) as SocialAccountSerializerDocument,
            options,
          )
        : null;

    const brandVoice =
      options.expand.has('brand_voice') &&
      options.expandedData?.get('brand_voice')
        ? BrandVoiceSerializer.serialize(
            options.expandedData.get(
              'brand_voice',
            ) as BrandVoiceSerializerDocument,
            options,
          )
        : null;

    const knowledgeSourceIds =
      document.knowledge_sources?.map((ks) =>
        toPublicId('bot_knowledge_source', ks.source_id),
      ) ?? [];

    // Map input behavior (from Mongoose schema) to output behavior (for DTO)
    const behavior: BotResponseBehavior = {
      auto_reply_enabled: document.behavior.auto_reply_enabled,
      max_replies_per_hour: document.behavior.max_replies_per_hour,
      max_replies_per_day: document.behavior.max_replies_per_day,
      reply_delay_min_seconds: document.behavior.reply_delay_min_seconds,
      reply_delay_max_seconds: document.behavior.reply_delay_max_seconds,
      escalation_threshold: document.behavior.escalation_threshold,
      cta_aggressiveness: document.behavior.cta_aggressiveness,
      should_reply_to_spam: document.behavior.should_reply_to_spam,
      stop_after_escalation: document.behavior.stop_after_escalation,
    };

    // Map input stats (from Mongoose schema) to output stats (for DTO)
    // Transforms last_active_at from Date | undefined to string | null
    const stats: BotResponseStats = {
      total_replies: document.stats.total_replies,
      total_escalations: document.stats.total_escalations,
      total_skipped: document.stats.total_skipped,
      avg_confidence: document.stats.avg_confidence,
      last_active_at: document.stats.last_active_at
        ? toIso(document.stats.last_active_at)
        : null,
    };

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/bots/${id}` },
          activate: {
            href: `${options.basePath}/bots/${id}/activate`,
            method: 'POST',
          },
          pause: {
            href: `${options.basePath}/bots/${id}/pause`,
            method: 'POST',
          },
          update: { href: `${options.basePath}/bots/${id}`, method: 'PATCH' },
          delete: { href: `${options.basePath}/bots/${id}`, method: 'DELETE' },
        }
      : undefined;

    return new BotResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      social_account_id: socialAccountId,
      brand_voice_id: brandVoiceId,
      name: document.name,
      description: document.description,
      status: document.status,
      is_active: document.is_active,
      behavior,
      stats,
      knowledge_source_ids: knowledgeSourceIds,
      social_account: socialAccount,
      brand_voice: brandVoice,
      _links,
    });
  }

  static serializeList(
    documents: BotSerializerDocument[],
    options: SerializeOptions,
  ): BotResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
