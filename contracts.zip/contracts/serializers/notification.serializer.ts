import type { Types } from 'mongoose';
import { toPublicId, type DocumentId } from '../ids/resource-id.service';
import { toIso } from '../timestamps/timestamp.serializer';
import {
  NotificationResponseDto,
  type NotificationResponseType,
} from '../dtos/responses/notification.response.dto';
import type { SerializeOptions } from '../dtos/envelope.dto';

// Minimal document interface for type safety
export interface NotificationSerializerDocument {
  readonly _id: Types.ObjectId | string;
  readonly user_id?: DocumentId;
  readonly title: string;
  readonly message: string;
  readonly type: string;
  readonly status: 'unread' | 'read' | 'archived' | 'deleted';
  readonly priority: 'high' | 'medium' | 'low' | 'urgent';
  readonly action_url?: string | null;
  readonly read_at?: Date | null;
  readonly is_broadcast: boolean;
  readonly target_channels: string[];
  readonly created_at?: Date;
  readonly updated_at?: Date;
}

/**
 * Serializer for Notification resources.
 * Converts Mongoose documents to NotificationResponseDto instances.
 */
export class NotificationSerializer {
  static serialize(
    document: NotificationSerializerDocument,
    options: SerializeOptions,
  ): NotificationResponseDto {
    const id = toPublicId('notification', document._id);
    const userId = document.user_id ? toPublicId('user', document.user_id) : '';
    const created_at = toIso(document.created_at) || new Date().toISOString();
    const updated_at = toIso(document.updated_at) || new Date().toISOString();

    const _links = options.includeLinks
      ? {
          self: { href: `${options.basePath}/notifications/${id}` },
          markAsRead: {
            href: `${options.basePath}/notifications/${id}/read`,
            method: 'POST',
          },
          archive: {
            href: `${options.basePath}/notifications/${id}/archive`,
            method: 'POST',
          },
        }
      : undefined;

    return new NotificationResponseDto({
      id,
      created_at,
      updated_at,
      user_id: userId,
      title: document.title,
      message: document.message,
      type: document.type as NotificationResponseType,
      status: document.status,
      priority: document.priority,
      action_url: document.action_url ?? null,
      read_at: document.read_at ? toIso(document.read_at) : null,
      is_broadcast: document.is_broadcast,
      target_channels: document.target_channels,
      _links,
    });
  }

  static serializeList(
    documents: NotificationSerializerDocument[],
    options: SerializeOptions,
  ): NotificationResponseDto[] {
    return documents.map((document) => this.serialize(document, options));
  }
}
