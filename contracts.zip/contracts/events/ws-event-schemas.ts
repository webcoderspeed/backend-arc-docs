// ─── WebSocket Event Schemas ──────────────────────────────────────────
// Typed interfaces for WebSocket event payloads.
// Ensures type safety for all real-time events.
// Uses WsEventMeta and WsEventEnvelope from responses module.

/** Data for notification events */
export interface WsNotificationEventData {
  /** Notification ID (prefixed or raw ObjectId) */
  readonly notification_id: string;
  /** Notification title */
  readonly title: string;
  /** Notification message body */
  readonly message: string;
  /** Notification type (e.g., 'info', 'warning', 'error') */
  readonly type: string;
  /** Priority level (e.g., 'low', 'normal', 'high', 'critical') */
  readonly priority: string;
}

/** Data for conversation message events */
export interface WsMessageEventData {
  /** Conversation ID (prefixed or raw ObjectId) */
  readonly conversation_id: string;
  /** Message ID (prefixed or raw ObjectId) */
  readonly message_id: string;
  /** Message text content (may be null for media-only messages) */
  readonly text: string | null;
  /** ID of message sender (prefixed or raw ObjectId) */
  readonly sender_id: string;
  /** ISO 8601 timestamp when message was created */
  readonly timestamp: string;
}

/** Data for automation execution events */
export interface WsAutomationEventData {
  /** Automation ID (prefixed or raw ObjectId) */
  readonly automation_id: string;
  /** Execution run ID (prefixed or raw ObjectId) */
  readonly execution_id: string;
  /** Current execution status (e.g., 'pending', 'running', 'completed', 'failed') */
  readonly status: string;
  /** Original trigger event ID (prefixed or raw ObjectId) */
  readonly trigger_event_id: string;
}

/** Union type of all WebSocket event data types */
export type AllWsEventData =
  | WsNotificationEventData
  | WsMessageEventData
  | WsAutomationEventData;

// Re-export the envelope types from responses for convenience
export type {
  WsEventMeta,
  WsEventEnvelope,
} from '../responses/ws-event.response';
