// ─── Job Schemas ──────────────────────────────────────────────────────
// Typed interfaces for BullMQ job data payloads.
// Ensures type safety for all background job types.

/** Base data shared by all background jobs */
export interface BaseJobData {
  /** Unique job identifier */
  readonly job_id: string;
  /** Distributed trace ID for correlation */
  readonly trace_id: string;
  /** ISO 8601 timestamp when job was enqueued */
  readonly enqueued_at: string;
  /** Current attempt number (1-based) */
  readonly attempt: number;
}

/** Job data for automation trigger execution */
export interface AutomationJobData extends BaseJobData {
  /** Automation ID (prefixed or raw ObjectId) */
  readonly automation_id: string;
  /** User ID (prefixed or raw ObjectId) */
  readonly user_id: string;
  /** Social account ID (prefixed or raw ObjectId) */
  readonly social_account_id: string;
  /** Trigger event ID (prefixed or raw ObjectId) */
  readonly trigger_event_id: string;
  /** Trigger data payload (arbitrary key-value pairs) */
  readonly trigger_data: Record<string, string | number | boolean>;
}

/** Job data for AI/Intelligence pipeline processing */
export interface IntelligencePipelineJobData extends BaseJobData {
  /** Conversation ID (prefixed or raw ObjectId) */
  readonly conversation_id: string;
  /** Message ID (prefixed or raw ObjectId) */
  readonly message_id: string;
  /** Bot ID (prefixed or raw ObjectId) */
  readonly bot_id: string;
  /** Social account ID (prefixed or raw ObjectId) */
  readonly social_account_id: string;
}

/** Job data for webhook payload ingestion */
export interface WebhookIngestJobData extends BaseJobData {
  /** Social platform name (e.g., 'instagram', 'facebook') */
  readonly platform: string;
  /** Raw webhook payload as JSON string */
  readonly raw_payload: string;
  /** ISO 8601 timestamp when webhook was received */
  readonly received_at: string;
}

/** Job data for media processing operations */
export interface MediaProcessingJobData extends BaseJobData {
  /** Media asset ID (prefixed or raw ObjectId) */
  readonly media_id: string;
  /** User ID (prefixed or raw ObjectId) */
  readonly user_id: string;
  /** Processing operation type */
  readonly operation: 'thumbnail' | 'compress' | 'transcode';
}

/** Union type of all job data types */
export type AllJobData =
  | AutomationJobData
  | IntelligencePipelineJobData
  | WebhookIngestJobData
  | MediaProcessingJobData;
