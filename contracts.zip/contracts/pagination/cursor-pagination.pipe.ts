// ─── Cursor Pagination Pipe ────────────────────────────────────────────
// Validates cursor pagination query parameters.
// Parses ?cursor=, ?limit=, ?direction= and returns typed params.
// Falls back to offset-based pagination if ?page= is present (backward compat).

import { Injectable, BadRequestException } from '@nestjs/common';
import type { PipeTransform } from '@nestjs/common';
import { decodeCursor } from '../dtos/cursor-pagination.dto';

/** Typed cursor pagination parameters after validation */
export interface CursorPaginationParams {
  /** Decoded cursor string (if provided) */
  readonly cursor?: string;
  /** Page size (validated: 1-100) */
  readonly limit: number;
  /** Direction: 'forward' or 'backward' */
  readonly direction: 'forward' | 'backward';
  /** True if legacy ?page= parameter was used */
  readonly isLegacyOffset: boolean;
  /** Page number (only set if legacy offset pagination) */
  readonly page?: number;
}

/** Query parameters shape for type safety */
interface PaginationQueryParams {
  cursor?: string;
  limit?: string;
  direction?: string;
  page?: string;
}

/** Default and bounds for pagination */
const DEFAULT_LIMIT = 25;
const MIN_LIMIT = 1;
const MAX_LIMIT = 100;
const VALID_DIRECTIONS = ['forward', 'backward'] as const;

@Injectable()
export class CursorPaginationPipe implements PipeTransform<
  PaginationQueryParams,
  CursorPaginationParams
> {
  /**
   * Transform and validate cursor pagination query parameters.
   *
   * @param value - Raw query parameters from request
   * @returns Typed, validated CursorPaginationParams
   * @throws BadRequestException if validation fails
   */
  transform(value: PaginationQueryParams): CursorPaginationParams {
    const query = value || {};

    // Check for legacy offset pagination (?page=)
    if (query.page !== undefined) {
      return this.handleLegacyOffset(query);
    }

    // Standard cursor pagination
    const limit = this.validateLimit(query.limit);
    const direction = this.validateDirection(query.direction);
    const cursor = this.validateCursor(query.cursor);

    return {
      cursor,
      limit,
      direction,
      isLegacyOffset: false,
    };
  }

  /** Validate and parse the limit parameter */
  private validateLimit(limit: string | undefined): number {
    if (!limit) {
      return DEFAULT_LIMIT;
    }

    const parsed = parseInt(limit, 10);

    if (Number.isNaN(parsed)) {
      throw new BadRequestException(
        `Invalid limit: "${limit}". Must be an integer between ${MIN_LIMIT} and ${MAX_LIMIT}.`,
      );
    }

    if (parsed < MIN_LIMIT || parsed > MAX_LIMIT) {
      throw new BadRequestException(
        `Limit out of range: ${parsed}. Must be between ${MIN_LIMIT} and ${MAX_LIMIT}.`,
      );
    }

    return parsed;
  }

  /** Validate the direction parameter */
  private validateDirection(
    direction: string | undefined,
  ): 'forward' | 'backward' {
    if (!direction) {
      return 'forward';
    }

    if (!VALID_DIRECTIONS.includes(direction as 'forward' | 'backward')) {
      throw new BadRequestException(
        `Invalid direction: "${direction}". Must be "forward" or "backward".`,
      );
    }

    return direction as 'forward' | 'backward';
  }

  /** Validate and decode the cursor parameter */
  private validateCursor(cursor: string | undefined): string | undefined {
    if (!cursor) {
      return undefined;
    }

    try {
      decodeCursor(cursor);
      return cursor;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      throw new BadRequestException(`Invalid cursor: ${message}`);
    }
  }

  /** Handle legacy ?page= offset-based pagination (backward compat) */
  private handleLegacyOffset(
    query: PaginationQueryParams,
  ): CursorPaginationParams {
    const page = query.page ? parseInt(query.page, 10) : 1;

    if (Number.isNaN(page) || page < 1) {
      throw new BadRequestException(
        `Invalid page: "${query.page}". Must be a positive integer.`,
      );
    }

    const limit = this.validateLimit(query.limit);

    return {
      limit,
      direction: 'forward',
      isLegacyOffset: true,
      page,
    };
  }
}
