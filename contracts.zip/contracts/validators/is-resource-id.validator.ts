// ─── Is Resource ID Validator ──────────────────────────────────────────
// Custom class-validator decorator that validates resource IDs.
// Accepts both prefixed IDs (e.g., "aut_...") and raw ObjectIds.

import {
  registerDecorator,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { isPublicId, isRawObjectId } from '../ids/resource-id.service';

/** Custom validator constraint for resource IDs */
@ValidatorConstraint({ name: 'isResourceId', async: false })
export class IsResourceIdConstraint implements ValidatorConstraintInterface {
  /**
   * Validate that the value is either a prefixed ID or raw ObjectId.
   *
   * @param value - The value to validate
   * @returns True if valid, false otherwise
   */
  validate(value: unknown): boolean {
    if (typeof value !== 'string') {
      return false;
    }

    return isPublicId(value) || isRawObjectId(value);
  }

  /**
   * Error message if validation fails.
   *
   * @returns Human-readable error message
   */
  defaultMessage(): string {
    return 'Value must be either a prefixed ID (e.g., "aut_507f1f77bcf86cd799439011") or a raw ObjectId (24 hex chars).';
  }
}

/**
 * Decorator to validate that a property is a valid resource ID.
 * Accepts both prefixed IDs (3 chars + underscore + 24 hex) and raw ObjectIds (24 hex).
 *
 * Usage example:
 * ```
 * class GetAutomationParamDto {
 *   @IsResourceId()
 *   automation_id: string;
 * }
 * ```
 *
 * @param options - Optional validation options
 */
export function IsResourceId(options?: ValidationOptions): PropertyDecorator {
  return (target: object, propertyKey: string | symbol | undefined): void => {
    if (typeof propertyKey !== 'string') {
      throw new Error(
        'IsResourceId decorator must be applied to a string property',
      );
    }

    registerDecorator({
      target: target.constructor,
      propertyName: propertyKey,
      options,
      constraints: [],
      validator: IsResourceIdConstraint,
    });
  };
}
