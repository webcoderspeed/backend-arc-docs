// ─── Is Trimmed String Validator ──────────────────────────────────────
// Composite decorator that applies string validation and trimming.
// Validates: string type, trims whitespace, enforces max length.

import { applyDecorators } from '@nestjs/common';
import { IsString, MaxLength } from 'class-validator';
import { Transform } from 'class-transformer';

/**
 * Composite decorator for validated, trimmed string properties.
 * Applies: @IsString(), @Transform(trim), @MaxLength(maxLength).
 *
 * Usage example:
 * ```
 * class CreateBotDto {
 *   @IsTrimmedString(100)
 *   name: string;
 * }
 * ```
 *
 * @param maxLength - Maximum length after trimming
 */
export function IsTrimmedString(maxLength: number): PropertyDecorator {
  const trimTransform = Transform(({ value }) => {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    return typeof value === 'string' ? value.trim() : value;
  });

  return applyDecorators(
    IsString({ message: 'Must be a string' }),
    trimTransform,
    MaxLength(maxLength, {
      message: `Must not exceed ${maxLength} characters`,
    }),
  );
}
