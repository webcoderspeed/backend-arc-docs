// ─── Job Validator ─────────────────────────────────────────────────────
// Runtime type validation for BullMQ job data payloads.
// Validates required fields before processing.

import { Logger } from '@nestjs/common';

const jobLogger = new Logger('JobValidator');

/**
 * Validate that required string fields are present and non-empty.
 * Throws if validation fails with descriptive error.
 *
 * @param jobName - Name of the job type for error messages
 * @param data - Job data to validate (read-only record)
 * @param requiredFields - Array of field names that must be non-empty strings
 */
export function validateJobData(
  jobName: string,
  data: Readonly<Record<string, unknown>>,
  requiredFields: readonly string[],
): void {
  const missingFields: string[] = [];

  for (const field of requiredFields) {
    const value = data[field];
    if (value === undefined || value === null || value === '') {
      missingFields.push(field);
    }
  }

  if (missingFields.length > 0) {
    const message = `[${jobName}] Missing required fields: ${missingFields.join(', ')}`;
    jobLogger.error(message);
    throw new Error(message);
  }
}
