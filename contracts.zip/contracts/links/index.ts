// ─── Links — HATEOAS Link Building (Phase 7) ──────────────────────────

export { LinkBuilder } from './link-builder';
