// ─── Link Builder ──────────────────────────────────────────────────────
// HATEOAS link builder utility.
// Constructs self, related, action, collection, and pagination links.

import type { ResourceLink } from '../dtos/base-resource.dto';

/**
 * Utility class for building HATEOAS links.
 * All methods are static for convenient use without instantiation.
 *
 * @example
 * const selfLink = LinkBuilder.self('/api', 'automations', 'aut_123');
 * // → { href: '/api/automations/aut_123' }
 */
export class LinkBuilder {
  /**
   * Build a self-reference link.
   *
   * @param basePath - API base path (e.g., '/api/v1')
   * @param resource - Resource type (e.g., 'automations')
   * @param id - Resource ID
   * @returns HATEOAS link object
   */
  static self(basePath: string, resource: string, id: string): ResourceLink {
    return {
      href: `${basePath}/${resource}/${id}`,
    };
  }

  /**
   * Build a related-resource link.
   *
   * @param basePath - API base path
   * @param resource - Parent resource type
   * @param id - Parent resource ID
   * @param relation - Related resource name (e.g., 'executions')
   * @returns HATEOAS link object
   */
  static related(
    basePath: string,
    resource: string,
    id: string,
    relation: string,
  ): ResourceLink {
    return {
      href: `${basePath}/${resource}/${id}/${relation}`,
    };
  }

  /**
   * Build an action link with HTTP method.
   *
   * @param basePath - API base path
   * @param resource - Resource type
   * @param id - Resource ID
   * @param actionName - Action name (e.g., 'enable', 'trigger')
   * @param method - HTTP method (e.g., 'POST', 'PUT')
   * @returns HATEOAS link object with method
   */
  static action(
    basePath: string,
    resource: string,
    id: string,
    actionName: string,
    method: string,
  ): ResourceLink {
    return {
      href: `${basePath}/${resource}/${id}/${actionName}`,
      method,
    };
  }

  /**
   * Build a collection list link.
   *
   * @param basePath - API base path
   * @param resource - Resource type
   * @returns HATEOAS link object
   */
  static collection(basePath: string, resource: string): ResourceLink {
    return {
      href: `${basePath}/${resource}`,
    };
  }

  /**
   * Build pagination links with cursor parameters.
   *
   * @param basePath - API base path
   * @param resource - Resource type
   * @param nextCursor - Opaque cursor for next page (optional)
   * @param previousCursor - Opaque cursor for previous page (optional)
   * @returns Object with 'next' and 'previous' links (may be null if not available)
   */
  static pagination(
    basePath: string,
    resource: string,
    nextCursor?: string,
    previousCursor?: string,
  ): Readonly<{
    next: ResourceLink | null;
    previous: ResourceLink | null;
  }> {
    const next = nextCursor
      ? {
          href: `${basePath}/${resource}?cursor=${encodeURIComponent(nextCursor)}&direction=forward`,
        }
      : null;

    const previous = previousCursor
      ? {
          href: `${basePath}/${resource}?cursor=${encodeURIComponent(previousCursor)}&direction=backward`,
        }
      : null;

    return { next, previous };
  }
}
