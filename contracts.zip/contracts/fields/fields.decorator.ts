// ─── @Fields() Decorator ──────────────────────────────────────────────
// Method decorator declaring the valid fields for a controller endpoint.

import { SetMetadata } from '@nestjs/common';

/** Metadata key for the fields decorator */
export const FIELDS_METADATA_KEY = 'pe:valid_fields';

/**
 * Declares valid field names for sparse fieldset support on a controller method.
 * Used by FieldsPipe to validate ?fields= query parameter.
 *
 * Usage: Apply Fields(['id', 'name', 'status']) decorator to a controller method.
 */
export const Fields = (validFields: readonly string[]): MethodDecorator =>
  SetMetadata(FIELDS_METADATA_KEY, new Set(validFields));
