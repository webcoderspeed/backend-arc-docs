// ─── Fields Pipe ──────────────────────────────────────────────────────
// Validates ?fields= query param against allowed fields for a resource.

import { Injectable, BadRequestException } from '@nestjs/common';
import type { PipeTransform } from '@nestjs/common';
import { parseFields, validateFields } from './field-selector';

@Injectable()
export class FieldsPipe implements PipeTransform<
  string | undefined,
  Set<string> | undefined
> {
  private readonly validFields: ReadonlySet<string>;

  /**
   * @param validFields - Set of all valid field names for the resource
   */
  constructor(validFields: ReadonlySet<string>) {
    this.validFields = validFields;
  }

  /**
   * Validate and parse ?fields= query parameter.
   *
   * @param value - Raw fields parameter string
   * @returns Set of validated field names, or undefined for all fields
   */
  transform(value: string | undefined): Set<string> | undefined {
    if (!value) {
      return undefined;
    }

    const fields = parseFields(value);

    if (!fields) {
      return undefined;
    }

    const invalidFields = validateFields(fields, this.validFields);

    if (invalidFields.length > 0) {
      throw new BadRequestException(
        `Invalid field(s): [${invalidFields.join(', ')}]. ` +
          `Valid fields: [${[...this.validFields].join(', ')}].`,
      );
    }

    return fields;
  }
}
