// ─── Field Selector ───────────────────────────────────────────────────
// Implements sparse fieldsets (?fields=id,name,status).
// Allows clients to request only the fields they need, reducing payload size.

/** Fields that are always included regardless of field selection */
const ALWAYS_INCLUDED_FIELDS: ReadonlySet<string> = new Set([
  'id',
  'created_at',
  'updated_at',
  '_links',
]);

/**
 * Parse a fields query parameter string into a Set of field names.
 *
 * @example
 * parseFields('id,name,status') // → Set { 'id', 'name', 'status', 'created_at', 'updated_at', '_links' }
 */
export function parseFields(
  fieldsParameter: string | undefined,
): Set<string> | undefined {
  if (!fieldsParameter || fieldsParameter.trim().length === 0) {
    return undefined; // No field selection = return all fields
  }

  const requestedFields = new Set(
    fieldsParameter
      .split(',')
      .map((f) => f.trim())
      .filter(Boolean),
  );

  // Always include mandatory fields
  for (const mandatory of ALWAYS_INCLUDED_FIELDS) {
    requestedFields.add(mandatory);
  }

  return requestedFields;
}

/**
 * Apply field selection to a serialized DTO.
 * Removes any fields not in the selection set.
 * If fields is undefined, returns the object unchanged.
 *
 * @example
 * applyFieldSelection({ id: '1', name: 'Test', status: 'active', description: 'Hello' }, new Set(['id', 'name', 'status']))
 * // → { id: '1', name: 'Test', status: 'active' }
 */
export function applyFieldSelection<T extends Record<string, unknown>>(
  dto: T,
  fields: ReadonlySet<string> | undefined,
): Partial<T> {
  if (!fields) {
    return dto;
  }

  const result: Record<string, unknown> = {};

  for (const key of Object.keys(dto)) {
    if (fields.has(key) || ALWAYS_INCLUDED_FIELDS.has(key)) {
      result[key] = dto[key];
    }
  }

  return result as Partial<T>;
}

/**
 * Apply field selection to a list of serialized DTOs.
 */
export function applyFieldSelectionToList<T extends Record<string, unknown>>(
  dtos: readonly T[],
  fields: ReadonlySet<string> | undefined,
): Partial<T>[] {
  if (!fields) {
    return [...dtos];
  }

  return dtos.map((dto) => applyFieldSelection(dto, fields));
}

/**
 * Validate that all requested fields exist on the DTO type.
 * Returns an array of invalid field names.
 *
 * @param requestedFields - Fields requested by the client
 * @param validFields - All valid field names for this resource
 */
export function validateFields(
  requestedFields: ReadonlySet<string>,
  validFields: ReadonlySet<string>,
): string[] {
  const invalid: string[] = [];

  for (const field of requestedFields) {
    if (!validFields.has(field) && !ALWAYS_INCLUDED_FIELDS.has(field)) {
      invalid.push(field);
    }
  }

  return invalid;
}
