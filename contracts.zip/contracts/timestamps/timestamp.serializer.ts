// ─── Timestamp Serializer ──────────────────────────────────────────────
// Standardizes all timestamp handling in the API layer.
// Responses: Always ISO 8601 strings (e.g., "2026-03-01T14:30:00.000Z")
// Requests: Accept ISO 8601 strings or Unix ms timestamps
// Internal: Always store as Date objects in MongoDB

/**
 * Convert a Date, string, or number to an ISO 8601 string.
 * Used in serializers when building response DTOs.
 *
 * @example
 * toIso(new Date())         // → "2026-03-01T14:30:00.000Z"
 * toIso('2026-03-01')       // → "2026-03-01T00:00:00.000Z"
 * toIso(1740835800000)      // → "2026-03-01T14:30:00.000Z"
 */
export function toIso(
  value: Date | string | number | null | undefined,
): string | null {
  if (value === null || value === undefined) {
    return null;
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (typeof value === 'number') {
    return new Date(value).toISOString();
  }

  if (typeof value === 'string') {
    const parsed = new Date(value);

    if (Number.isNaN(parsed.getTime())) {
      throw new Error(`Invalid timestamp string: "${value}"`);
    }

    return parsed.toISOString();
  }

  throw new Error(`Unsupported timestamp type: ${typeof value}`);
}

/**
 * Convert an incoming request value (ISO 8601 string or Unix ms number) to a Date.
 * Used in request DTOs with @Transform() decorators.
 *
 * @example
 * fromInput('2026-03-01T14:30:00.000Z') // → Date
 * fromInput(1740835800000)                // → Date
 */
export function fromInput(value: string | number): Date {
  if (typeof value === 'number') {
    return new Date(value);
  }

  if (typeof value === 'string') {
    const parsed = new Date(value);

    if (Number.isNaN(parsed.getTime())) {
      throw new Error(
        `Invalid timestamp input: "${value}". Expected ISO 8601 string or Unix ms number.`,
      );
    }

    return parsed;
  }

  throw new Error(
    `Unsupported timestamp input type: ${typeof value}. Expected string or number.`,
  );
}

/**
 * Get the current timestamp as an ISO 8601 string.
 * Convenience wrapper used in meta blocks.
 */
export function nowIso(): string {
  return new Date().toISOString();
}
