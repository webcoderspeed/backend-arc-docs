// ─── Contracts — Central Barrel Export ─────────────────────────────────

// Response types (existing)
export * from './responses';

// Resource ID system (Phase 1)
export * from './ids';

// Timestamp utilities (Phase 1)
export * from './timestamps';

// DTOs — Base, Cursor Pagination, List Query, Envelope (Phase 1)
export * from './dtos';

// Serializers — Response serialization (Phase 2)
export * from './serializers';

// Expandable Objects — ?expand[] system (Phase 3)
export * from './expand';

// Sparse Fieldsets — ?fields= system (Phase 4)
export * from './fields';

// Cursor Pagination Pipe — ?cursor=, ?limit=, ?direction= (Phase 5)
export * from './pagination';

// Request DTO Validators — @IsResourceId(), @IsTrimmedString() (Phase 6)
export * from './validators';

// HATEOAS Links — Self, related, action, collection links (Phase 7)
export * from './links';

// API Versioning — PE-API-Version header management (Phase 8)
export * from './versioning';

// Worker & WebSocket Contracts — Job and event schemas (Phase 9)
export * from './events';
