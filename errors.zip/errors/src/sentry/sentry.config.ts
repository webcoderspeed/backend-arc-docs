import * as Sentry from '@sentry/node';
import { Logger } from '@nestjs/common';

/**
 * SentryConfig — centralized Sentry initialization for all PostEngage services.
 *
 * Call `SentryConfig.init()` in each service's main.ts BEFORE NestFactory.create().
 *
 * Features:
 * - Environment-aware sampling (production: 20%, dev: 100%)
 * - PII stripping via beforeSend
 * - Ignores expected client errors (401, 404, 429)
 * - Tags every event with service name
 * - Graceful no-op when SENTRY_DSN is not set
 */

export interface SentryInitOptions {
  /** Service name: 'gatekeeper' | 'pulse' | 'scheduler' | 'worker' */
  serviceName: string;
  /** Sentry DSN — if not provided, reads from SENTRY_DSN env var */
  dsn?: string;
  /** Environment — defaults to NODE_ENV */
  environment?: string;
  /** App version / release tag */
  release?: string;
  /** Traces sample rate override (default: 0.2 prod, 1.0 dev) */
  tracesSampleRate?: number;
}

/** HTTP status codes that should NOT be reported to Sentry (expected client errors) */
const IGNORED_STATUS_CODES = new Set([400, 401, 403, 404, 405, 409, 422, 429]);

/** Error class names to silently ignore */
const IGNORED_ERROR_NAMES = new Set([
  'UnauthorizedException',
  'ForbiddenException',
  'NotFoundException',
  'ThrottlerException',
  'BadRequestException',
  'ConflictException',
]);

/** Fields to strip from Sentry events for PII protection */
const PII_FIELDS = new Set([
  'password',
  'token',
  'secret',
  'authorization',
  'cookie',
  'creditCard',
  'credit_card',
  'ssn',
  'apiKey',
  'api_key',
  'refreshToken',
  'refresh_token',
  'accessToken',
  'access_token',
]);

export class SentryConfig {
  private static readonly logger = new Logger(SentryConfig.name);
  private static initialized = false;

  /**
   * Initialize Sentry for a service.
   * Safe to call even without SENTRY_DSN — will log a warning and no-op.
   */
  static init(options: SentryInitOptions): void {
    if (this.initialized) {
      this.logger.warn('Sentry already initialized, skipping duplicate init');
      return;
    }

    const dsn = options.dsn ?? process.env.SENTRY_DSN;

    if (!dsn) {
      this.logger.warn(
        'SENTRY_DSN not configured — Sentry error tracking is disabled. ' +
          'Set SENTRY_DSN in your environment to enable production monitoring.',
      );
      this.initialized = true;
      return;
    }

    const environment =
      options.environment ?? process.env.NODE_ENV ?? 'development';
    const isProduction = environment === 'production';

    Sentry.init({
      dsn,
      environment,
      release: options.release ?? process.env.APP_VERSION ?? undefined,
      serverName: options.serviceName,

      // Performance: sample 20% in prod, 100% in dev
      tracesSampleRate: options.tracesSampleRate ?? (isProduction ? 0.2 : 1.0),

      // Tag every event with service name
      initialScope: {
        tags: {
          service: options.serviceName,
        },
      },

      // Filter out expected errors and strip PII
      beforeSend(event, hint) {
        if (SentryConfig.shouldIgnoreError(hint?.originalException)) {
          return null;
        }

        SentryConfig.stripPiiFromEvent(event);
        return event;
      },
    });

    this.initialized = true;
    this.logger.log(
      `Sentry initialized for ${options.serviceName} (env: ${environment}, ` +
        `traces: ${options.tracesSampleRate ?? (isProduction ? '20%' : '100%')})`,
    );
  }

  /**
   * Report an exception to Sentry with PostEngage-specific context.
   * Only reports 5xx errors — client errors (4xx) are filtered out.
   */
  static captureException(
    exception: unknown,
    context: {
      httpStatus: number;
      errorCode: string;
      requestId: string;
      path: string;
      service?: string;
      metadata?: Record<string, unknown>;
    },
  ): void {
    // Only report server errors (5xx)
    if (context.httpStatus < 500) {
      return;
    }

    Sentry.captureException(exception, {
      tags: {
        error_code: context.errorCode,
        service: context.service ?? 'unknown',
        http_status: String(context.httpStatus),
      },
      extra: {
        request_id: context.requestId,
        path: context.path,
        ...(context.metadata
          ? { metadata: this.redactPII(context.metadata) }
          : {}),
      },
    });
  }

  /**
   * Flush pending Sentry events — call during graceful shutdown.
   * @param timeout Max wait time in ms (default: 5000)
   */
  static async flush(timeout = 5000): Promise<void> {
    try {
      await Sentry.flush(timeout);
    } catch {
      // Silently fail — shutdown should not be blocked by Sentry
    }
  }

  /**
   * Determine if an error should be ignored based on class name or HTTP status.
   */
  private static shouldIgnoreError(error: unknown): boolean {
    if (!error || typeof error !== 'object') return false;

    const errorObject = error as Record<string, unknown>;

    // Check by class name
    const className = (error as Error).constructor?.name;
    if (className && IGNORED_ERROR_NAMES.has(className)) {
      return true;
    }

    // Check by HTTP status (NestJS HttpException pattern)
    const status = errorObject.status ?? errorObject.statusCode;
    if (typeof status === 'number' && IGNORED_STATUS_CODES.has(status)) {
      return true;
    }

    return false;
  }

  /**
   * Strip PII from Sentry event request data, headers, and cookies.
   */
  private static stripPiiFromEvent(event: Sentry.Event): void {
    // Strip PII from request data
    if (event.request?.data && typeof event.request.data === 'object') {
      event.request.data = SentryConfig.redactPII(
        event.request.data as Record<string, unknown>,
      );
    }

    // Strip PII from request headers
    if (event.request?.headers) {
      const headers = event.request.headers;
      for (const key of Object.keys(headers)) {
        if (PII_FIELDS.has(key.toLowerCase())) {
          headers[key] = '[REDACTED]';
        }
      }
    }

    // Strip cookies
    if (event.request?.cookies) {
      event.request.cookies = {};
    }
  }

  /**
   * Redact PII fields from an object (shallow clone).
   */
  private static redactPII(
    object: Record<string, unknown>,
  ): Record<string, unknown> {
    const redacted: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(object)) {
      if (PII_FIELDS.has(key.toLowerCase())) {
        redacted[key] = '[REDACTED]';
      } else if (value && typeof value === 'object' && !Array.isArray(value)) {
        redacted[key] = this.redactPII(value as Record<string, unknown>);
      } else {
        redacted[key] = value;
      }
    }
    return redacted;
  }
}
