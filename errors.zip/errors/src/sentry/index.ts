export { SentryConfig, type SentryInitOptions } from './sentry.config';
