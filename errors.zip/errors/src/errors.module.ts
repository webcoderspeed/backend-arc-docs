import { type DynamicModule, Module } from '@nestjs/common';

/**
 * ErrorsModule — NestJS module for the error system.
 *
 * This module doesn't have providers by default since most of the
 * error system is used statically (PostEngageException, filters, etc.).
 *
 * Use forRoot() if you need to register the GlobalExceptionFilter
 * as a provider via the APP_FILTER token.
 */
@Module({})
export class ErrorsModule {
  static forRoot(): DynamicModule {
    return {
      module: ErrorsModule,
      global: true,
    };
  }
}
