import { PostEngageException } from '../core/postengage.exception';
import type { ErrorDetail } from '../types/error-response.types';

/**
 * MongooseErrorHandler — converts Mongoose-specific errors into PostEngageException.
 *
 * Handles:
 * - MongoServerError code 11000 (duplicate key) → PE-DB-001
 * - CastError (invalid ObjectId) → PE-DB-002
 * - Mongoose ValidationError → PE-DB-003
 * - DocumentNotFoundError → PE-DB-004
 * - VersionError (optimistic locking) → PE-DB-005
 * - MongoNetworkError → PE-DB-006
 *
 * Returns null if the error is not a Mongoose/MongoDB error.
 */
export class MongooseErrorHandler {
  static handle(error: unknown): PostEngageException | null {
    if (!error || typeof error !== 'object') return null;

    const error_ = error as Record<string, unknown>;

    // MongoServerError — E11000 duplicate key
    if (error_.code === 11000 || error_.code === 11001) {
      return this.handleDuplicateKey(error_);
    }

    // Mongoose CastError — invalid ObjectId or type
    if (error_.name === 'CastError') {
      return this.handleCastError(error_);
    }

    // Mongoose ValidationError — schema validation failed
    if (error_.name === 'ValidationError' && 'errors' in error_) {
      return this.handleValidationError(error_);
    }

    // DocumentNotFoundError
    if (error_.name === 'DocumentNotFoundError') {
      return new PostEngageException('PE-DB-004', {
        message: 'Document not found.',
        cause: error instanceof Error ? error : undefined,
      });
    }

    // VersionError — optimistic locking conflict
    if (error_.name === 'VersionError') {
      return new PostEngageException('PE-DB-005', {
        message: 'This record was modified by another request. Please retry.',
        cause: error instanceof Error ? error : undefined,
      });
    }

    // MongoNetworkError, MongoServerSelectionError — connection issues
    if (
      error_.name === 'MongoNetworkError' ||
      error_.name === 'MongoServerSelectionError' ||
      error_.name === 'MongoNetworkTimeoutError'
    ) {
      return new PostEngageException('PE-DB-006', {
        cause: error instanceof Error ? error : undefined,
      });
    }

    return null;
  }

  private static handleDuplicateKey(
    error: Record<string, unknown>,
  ): PostEngageException {
    // Extract the duplicate field from keyPattern or keyValue
    let field = 'unknown';
    let value: unknown;

    if (error.keyPattern && typeof error.keyPattern === 'object') {
      field =
        Object.keys(error.keyPattern as Record<string, unknown>)[0] ??
        'unknown';
    }

    if (error.keyValue && typeof error.keyValue === 'object') {
      value = (error.keyValue as Record<string, unknown>)[field];
    }

    const details: ErrorDetail[] = [
      {
        field,
        message: `A record with this ${field} already exists.`,
        code: 'duplicate',
      },
    ];

    return new PostEngageException('PE-DB-001', {
      message: `Duplicate value for ${field}.`,
      param: field,
      details,
      cause: error instanceof Error ? error : undefined,
      metadata: { duplicateField: field, duplicateValue: value },
    });
  }

  private static handleCastError(
    error: Record<string, unknown>,
  ): PostEngageException {
    const path = (error.path as string) ?? 'unknown';
    const kind = (error.kind as string) ?? 'unknown';

    const details: ErrorDetail[] = [
      {
        field: path,
        message: `Invalid ${kind} format.`,
        code: 'invalid_format',
      },
    ];

    return new PostEngageException('PE-DB-002', {
      message: `Invalid ${path} format.`,
      param: path,
      details,
      cause: error instanceof Error ? error : undefined,
    });
  }

  private static handleValidationError(
    error: Record<string, unknown>,
  ): PostEngageException {
    const errors = error.errors as Record<
      string,
      { message?: string; path?: string; kind?: string }
    >;

    const details: ErrorDetail[] = Object.entries(errors).map(
      ([field, fieldError]) => ({
        field,
        message: fieldError.message ?? 'Validation failed.',
        code: fieldError.kind ?? 'invalid',
      }),
    );

    return new PostEngageException('PE-DB-003', {
      message: 'Schema validation failed.',
      details,
      cause: error instanceof Error ? error : undefined,
    });
  }
}
