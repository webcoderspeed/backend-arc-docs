import { PostEngageException } from '../core/postengage.exception';

/**
 * ThrottlerErrorHandler — converts @nestjs/throttler ThrottlerException
 * into a PostEngageException with PE-RATE-001.
 *
 * Returns null if the error is not a ThrottlerException.
 */
export class ThrottlerErrorHandler {
  static handle(error: unknown): PostEngageException | null {
    if (!error || typeof error !== 'object') return null;

    const error_ = error as Record<string, unknown>;

    // ThrottlerException has name 'ThrottlerException' and status 429
    if (
      error_.name === 'ThrottlerException' ||
      (error_.constructor &&
        (error_.constructor as { name?: string }).name === 'ThrottlerException')
    ) {
      return new PostEngageException('PE-RATE-001', {
        message: 'Too many requests. Please slow down.',
        cause: error instanceof Error ? error : undefined,
      });
    }

    return null;
  }
}
