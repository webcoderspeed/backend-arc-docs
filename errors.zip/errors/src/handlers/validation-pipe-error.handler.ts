import type { ErrorDetail } from '../types/error-response.types';

/**
 * Represents a class-validator ValidationError shape
 */
interface ClassValidatorError {
  property: string;
  constraints?: Record<string, string>;
  children?: ClassValidatorError[];
}

/**
 * ValidationPipeErrorHandler — converts class-validator ValidationError[]
 * into our ErrorDetail[] format.
 *
 * Handles nested validation errors by recursively flattening with dot-notation paths.
 *
 * Usage in ValidationPipe:
 * new ValidationPipe({
 * exceptionFactory: (errors) => {
 * const details = ValidationPipeErrorHandler.formatErrors(errors);
 * return new ValidationException(details);
 * },
 * });
 */
export class ValidationPipeErrorHandler {
  /**
   * Convert class-validator errors to ErrorDetail[]
   */
  static formatErrors(errors: ClassValidatorError[]): ErrorDetail[] {
    const details: ErrorDetail[] = [];
    this.flattenErrors(errors, '', details);
    return details;
  }

  private static flattenErrors(
    errors: ClassValidatorError[],
    parentPath: string,
    details: ErrorDetail[],
  ): void {
    for (const error of errors) {
      const fieldPath = parentPath
        ? `${parentPath}.${error.property}`
        : error.property;

      // Add constraint violations for this field
      if (error.constraints) {
        for (const [constraintKey, constraintMessage] of Object.entries(
          error.constraints,
        )) {
          details.push({
            field: fieldPath,
            message: constraintMessage,
            code: this.mapConstraintToCode(constraintKey),
          });
        }
      }

      // Recurse into nested (child) validation errors
      if (error.children && error.children.length > 0) {
        this.flattenErrors(error.children, fieldPath, details);
      }
    }
  }

  /**
   * Map class-validator constraint names to machine-readable codes
   */
  private static mapConstraintToCode(constraint: string): string {
    const constraintMap: Record<string, string> = {
      isNotEmpty: 'required',
      isDefined: 'required',
      isString: 'invalid_type',
      isNumber: 'invalid_type',
      isBoolean: 'invalid_type',
      isArray: 'invalid_type',
      isObject: 'invalid_type',
      isEmail: 'invalid_format',
      isUrl: 'invalid_format',
      isUUID: 'invalid_format',
      isDateString: 'invalid_format',
      isISO8601: 'invalid_format',
      isMongoId: 'invalid_format',
      matches: 'invalid_format',
      minLength: 'too_short',
      maxLength: 'too_long',
      min: 'too_small',
      max: 'too_large',
      isIn: 'invalid_enum',
      isEnum: 'invalid_enum',
      arrayMinSize: 'too_few_items',
      arrayMaxSize: 'too_many_items',
      isPositive: 'must_be_positive',
      isNegative: 'must_be_negative',
      isInt: 'must_be_integer',
    };

    return constraintMap[constraint] ?? constraint;
  }
}
