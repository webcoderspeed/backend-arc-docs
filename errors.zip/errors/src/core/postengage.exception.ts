import { HttpException } from '@nestjs/common';

import type { ErrorDetail } from '../types/error-response.types';
import type { ErrorCodeDefinition } from '../types/error-definition.types';
import type { ErrorType } from '../types/error-code.types';
import { ErrorDomain, ErrorSeverity } from '../types/error-code.types';

/**
 * Options for creating a PostEngageException
 */
export interface PostEngageExceptionOptions {
  /** Override the default user-facing message */
  message?: string;

  /** Which field caused this error (Stripe pattern), e.g. "email" */
  param?: string;

  /** Multiple field-level errors (GitHub pattern) */
  details?: ErrorDetail[];

  /** Original error for error chaining */
  cause?: Error;

  /** Extra context for logging (not sent to client) */
  metadata?: Record<string, unknown>;
}

/**
 * Registry lookup function — set by the codes module at import time.
 * This avoids circular dependencies between core/ and codes/.
 */
let registryLookup: ((code: string) => ErrorCodeDefinition | undefined) | null =
  null;

/**
 * Called by the codes/index.ts module to register the lookup function.
 * This breaks the circular dependency: core ← codes
 */
export function setErrorRegistryLookup(
  function_: (code: string) => ErrorCodeDefinition | undefined,
): void {
  registryLookup = function_;
}

/**
 * Fallback definition when a code is not found in the registry
 */
function getFallbackDefinition(code: string): ErrorCodeDefinition {
  return {
    code,
    type: 'server_error' as ErrorType,
    domain: ErrorDomain.INT,
    httpStatus: 500,
    message: 'An unexpected error occurred.',
    developerMessage: `Unknown error code: ${code}`,
    severity: ErrorSeverity.HIGH,
    retryable: false,
  };
}

/**
 * PostEngageException — the main exception class for the entire application.
 *
 * Every business error in PostEngage should throw this exception with a
 * registered error code (PE-AUTH-001, PE-VAL-002, etc.).
 *
 * Usage:
 * throw new PostEngageException('PE-AUTH-001');
 * throw new PostEngageException('PE-VAL-001', {
 * message: 'Email is invalid',
 * param: 'email',
 * details: [{ field: 'email', message: 'must be a valid email', code: 'invalid_format' }],
 * });
 */
export class PostEngageException extends HttpException {
  /** The PE-xxx error code */
  public readonly errorCode: string;

  /** The error type (validation_error, authentication_error, etc.) */
  public readonly errorType: ErrorType;

  /** The full error code definition from the registry */
  public readonly definition: ErrorCodeDefinition;

  /** Which field caused this error (Stripe pattern) */
  public readonly param?: string;

  /** Multiple field-level errors (GitHub pattern) */
  public readonly details?: ErrorDetail[];

  /** Extra context for logging — never sent to client */
  public readonly metadata?: Record<string, unknown>;

  /** Original error that caused this exception */
  public readonly originalCause?: Error;

  constructor(code: string, options?: PostEngageExceptionOptions) {
    const definition = registryLookup?.(code) ?? getFallbackDefinition(code);
    const message = options?.message ?? definition.message;
    const status = definition.httpStatus;

    super(message, status, { cause: options?.cause });

    this.errorCode = code;
    this.errorType = definition.type;
    this.definition = definition;
    this.param = options?.param;
    this.details = options?.details;
    this.metadata = options?.metadata;
    this.originalCause = options?.cause;
  }

  /**
   * Whether the client can retry this request
   */
  get retryable(): boolean {
    return this.definition.retryable;
  }

  /**
   * Recommended retry delay in seconds (if retryable)
   */
  get retryAfterSeconds(): number | undefined {
    return this.definition.retryAfterSeconds;
  }

  /**
   * Error severity for logging decisions
   */
  get severity(): ErrorSeverity {
    return this.definition.severity;
  }
}
