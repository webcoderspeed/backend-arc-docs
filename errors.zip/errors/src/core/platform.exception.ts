import {
  PostEngageException,
  type PostEngageExceptionOptions,
} from './postengage.exception';

/**
 * PlatformException — for external platform errors (Instagram, Facebook, etc.)
 *
 * Wraps errors from social media APIs and other external services,
 * preserving the original platform error code and message for debugging
 * while presenting a clean PostEngage error to the client.
 *
 * Usage:
 * throw new PlatformException('instagram', 'PE-SOC-002', {
 * platformCode: 4,
 * platformMessage: 'Application request limit reached',
 * message: 'Instagram rate limit reached. Try again in 5 minutes.',
 * });
 */
export class PlatformException extends PostEngageException {
  /** The external platform name (lowercase) */
  public readonly platform: string;

  /** The original error code from the platform */
  public readonly platformCode?: string | number;

  /** The original error message from the platform */
  public readonly platformMessage?: string;

  constructor(
    platform: string,
    code: string,
    options?: PostEngageExceptionOptions & {
      platformCode?: string | number;
      platformMessage?: string;
    },
  ) {
    super(code, {
      ...options,
      metadata: {
        ...options?.metadata,
        platform,
        platformCode: options?.platformCode,
        platformMessage: options?.platformMessage,
      },
    });

    this.platform = platform;
    this.platformCode = options?.platformCode;
    this.platformMessage = options?.platformMessage;
  }
}
