import type { ErrorDetail } from '../types/error-response.types';
import {
  PostEngageException,
  type PostEngageExceptionOptions,
} from './postengage.exception';

/**
 * ValidationException — specialized exception for input validation errors.
 *
 * Used by the ValidationPipe exceptionFactory to convert class-validator
 * errors into a structured PostEngageException with field-level details.
 *
 * Usage:
 * throw new ValidationException([
 * { field: 'email', message: 'must be a valid email', code: 'invalid_format' },
 * { field: 'password', message: 'must be at least 8 characters', code: 'too_short' },
 * ]);
 *
 * throw new ValidationException(
 * [{ field: 'name', message: 'is required', code: 'required' }],
 * { message: 'Please fill in all required fields' },
 * );
 */
export class ValidationException extends PostEngageException {
  constructor(
    details: ErrorDetail[],
    options?: Omit<PostEngageExceptionOptions, 'details'>,
  ) {
    super('PE-VAL-001', {
      message: options?.message ?? 'Validation failed.',
      details,
      ...options,
    });
  }
}
