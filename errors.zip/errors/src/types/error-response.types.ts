import type { ErrorType } from './error-code.types';

/**
 * PostEngage Unified Error Response
 *
 * Every error — HTTP, WebSocket, Queue, RPC — produces this exact shape.
 * Inspired by: Stripe (type + param), GitHub (details[]), Twilio (doc_url), Cloudflare (success: false)
 */
export interface PostEngageErrorResponse {
  success: false;

  error: {
    /** Error type — tells the client HOW to handle it */
    type: ErrorType;

    /** Machine-readable error code, e.g. "PE-AUTH-001" — never changes */
    code: string;

    /** Human-readable message — can change between versions */
    message: string;

    /** Which field caused this error (Stripe pattern), e.g. "email" */
    param?: string;

    /** Multiple field-level errors (GitHub pattern) */
    details?: ErrorDetail[];

    /** Link to error documentation (Twilio pattern) */
    doc_url?: string;
  };

  meta: ResponseMeta;

  /** Only included in development/staging — NEVER in production */
  debug?: DebugInfo;
}

/**
 * Field-level error detail — used for validation errors
 */
export interface ErrorDetail {
  /** Field path, e.g. "email" or "metadata.name" */
  field: string;

  /** Human-readable error message for this field */
  message: string;

  /** Machine-readable code for this specific issue */
  code: string;
}

/**
 * Response metadata — always included
 */
export interface ResponseMeta {
  /** Unique request identifier, e.g. "req_01HXYZ..." */
  request_id: string;

  /** ISO 8601 timestamp */
  timestamp: string;

  /** Request path, e.g. "/api/v1/auth/login" */
  path: string;

  /** HTTP status code */
  status: number;
}

/**
 * Debug info — development/staging only
 */
export interface DebugInfo {
  /** Error stack trace */
  stack?: string;

  /** Original cause message (error chaining) */
  cause?: string;

  /** Which microservice produced this error */
  service?: string;

  /** Request processing time in milliseconds */
  duration_ms?: number;
}
