import type { ErrorDomain, ErrorSeverity, ErrorType } from './error-code.types';

/**
 * Definition for a single error code in the registry
 *
 * Each error code (e.g. PE-AUTH-001) has exactly one definition
 * that determines its HTTP status, type, message, and behavior.
 */
export interface ErrorCodeDefinition {
  /** The error code, e.g. "PE-AUTH-001" */
  code: string;

  /** Error type — how the client should handle it */
  type: ErrorType;

  /** Domain category */
  domain: ErrorDomain;

  /** HTTP status code to return */
  httpStatus: number;

  /** User-facing error message */
  message: string;

  /** Internal message for developer logs */
  developerMessage: string;

  /** Severity for logging and alerting */
  severity: ErrorSeverity;

  /** Whether the client can retry this request */
  retryable: boolean;

  /** If retryable, recommended wait time in seconds */
  retryAfterSeconds?: number;

  /** Link to documentation for this error */
  docUrl?: string;
}
