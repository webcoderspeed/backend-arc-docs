/**
 * Error Type — tells the client HOW to handle this error (Stripe-inspired)
 *
 * validation_error    → Show field-level errors in form
 * authentication_error → Redirect to login / refresh token
 * authorization_error  → Show "no permission" UI
 * not_found_error      → Show 404 page
 * conflict_error       → Show "already exists" or retry
 * rate_limit_error     → Show "slow down" + retry after X
 * payment_error        → Show payment failure + retry
 * api_error            → Bad API usage (wrong method, bad params)
 * platform_error       → External platform is down (Instagram, etc.)
 * server_error         → Show "something went wrong" + report
 */
export enum ErrorType {
  VALIDATION = 'validation_error',
  AUTHENTICATION = 'authentication_error',
  AUTHORIZATION = 'authorization_error',
  NOT_FOUND = 'not_found_error',
  CONFLICT = 'conflict_error',
  RATE_LIMIT = 'rate_limit_error',
  PAYMENT = 'payment_error',
  API = 'api_error',
  PLATFORM = 'platform_error',
  SERVER = 'server_error',
}

/**
 * Error Domain — the category prefix in error codes (PE-{DOMAIN}-xxx)
 */
export enum ErrorDomain {
  AUTH = 'AUTH',
  USR = 'USR',
  VAL = 'VAL',
  RATE = 'RATE',
  PAY = 'PAY',
  SOC = 'SOC',
  ENG = 'ENG',
  FILE = 'FILE',
  WS = 'WS',
  QUEUE = 'QUEUE',
  INT = 'INT',
  EXT = 'EXT',
  API = 'API',
  DB = 'DB',
}

/**
 * Error Severity — used for logging level and alerting decisions
 */
export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}
