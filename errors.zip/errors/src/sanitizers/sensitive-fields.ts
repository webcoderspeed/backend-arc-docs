/**
 * Fields that should be redacted from error metadata and logs.
 * Comparison is case-insensitive.
 */
export const SENSITIVE_FIELDS = new Set([
  'password',
  'passwd',
  'secret',
  'token',
  'accesstoken',
  'access_token',
  'refreshtoken',
  'refresh_token',
  'apikey',
  'api_key',
  'apiSecret',
  'api_secret',
  'authorization',
  'cookie',
  'session',
  'creditcard',
  'credit_card',
  'cardnumber',
  'card_number',
  'cvv',
  'cvc',
  'ssn',
  'privatekey',
  'private_key',
]);

/**
 * Patterns in error messages that should be stripped in production.
 * These could leak sensitive infrastructure details.
 */
export const SENSITIVE_PATTERNS: { pattern: RegExp; replacement: string }[] = [
  // File system paths
  {
    pattern: /\/[\w/.-]+\.(ts|js|mjs):\d+:\d+/g,
    replacement: '[path:redacted]',
  },
  { pattern: /at\s+[\w.]+\s+\(\/[\w/.-]+\)/g, replacement: '[stack:redacted]' },

  // MongoDB connection strings
  {
    pattern: /mongodb(\+srv)?:\/\/[^\s,]+/g,
    replacement: '[mongodb:redacted]',
  },

  // Redis connection strings
  { pattern: /redis:\/\/[^\s,]+/g, replacement: '[redis:redacted]' },

  // Generic URIs with credentials
  { pattern: /\w+:\/\/\w+:[^@]+@[^\s]+/g, replacement: '[uri:redacted]' },

  // IP addresses
  {
    pattern: /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?/g,
    replacement: '[ip:redacted]',
  },
];
