import type { DebugInfo } from '../types/error-response.types';
import { SENSITIVE_FIELDS, SENSITIVE_PATTERNS } from './sensitive-fields';

/**
 * ErrorSanitizer — environment-aware error sanitization.
 *
 * Production: no stack traces, no internal details, redacted messages
 * Development: full debug info included
 * Staging: stack traces but sensitive fields redacted
 */
export class ErrorSanitizer {
  private static readonly isProduction = process.env.NODE_ENV === 'production';

  /**
   * Build debug info object — returns undefined in production.
   */
  static buildDebugInfo(
    error: unknown,
    service?: string,
    startTime?: number,
  ): DebugInfo | undefined {
    if (this.isProduction) {
      return undefined;
    }

    const debug: DebugInfo = {};

    if (error instanceof Error) {
      debug.stack = error.stack;
      if (error.cause instanceof Error) {
        debug.cause = error.cause.message;
      }
    }

    if (service) {
      debug.service = service;
    }

    if (startTime) {
      debug.duration_ms = Date.now() - startTime;
    }

    return Object.keys(debug).length > 0 ? debug : undefined;
  }

  /**
   * Sanitize an error message for production.
   * Strips file paths, connection strings, and IPs.
   */
  static sanitizeMessage(message: string): string {
    if (!this.isProduction) {
      return message;
    }

    let sanitized = message;
    for (const { pattern, replacement } of SENSITIVE_PATTERNS) {
      sanitized = sanitized.replace(pattern, replacement);
    }

    return sanitized;
  }

  /**
   * Redact sensitive fields from an object (for logging metadata).
   * Performs a shallow copy — does not mutate the original.
   */
  static redactSensitiveFields(
    object: Record<string, unknown>,
  ): Record<string, unknown> {
    const redacted: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(object)) {
      if (SENSITIVE_FIELDS.has(key.toLowerCase())) {
        redacted[key] = '[REDACTED]';
      } else if (value && typeof value === 'object' && !Array.isArray(value)) {
        redacted[key] = this.redactSensitiveFields(
          value as Record<string, unknown>,
        );
      } else {
        redacted[key] = value;
      }
    }

    return redacted;
  }
}
