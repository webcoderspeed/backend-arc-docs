import {
  type ArgumentsHost,
  Catch,
  type ExceptionFilter,
  Logger,
} from '@nestjs/common';
import type { Request, Response } from 'express';

import { PostEngageException } from '../core/postengage.exception';
import { ErrorResponseBuilder } from '../utils/error-response.builder';
import { ErrorSanitizer } from '../sanitizers/error-sanitizer';
import { SentryConfig } from '../sentry/sentry.config';

/**
 * GlobalExceptionFilter — the single HTTP exception filter for all services.
 *
 * Catches ALL exceptions and produces a unified PostEngageErrorResponse.
 *
 * Priority:
 * 1. PostEngageException → use error code, type, details
 * 2. Mongoose errors → MongooseErrorHandler → PostEngageException
 * 3. ThrottlerException → PE-RATE-001
 * 4. HttpException → map status to generic PE code
 * 5. Unknown → PE-INT-001
 *
 * Logging:
 * - 4xx → logger.warn (client errors)
 * - 5xx → logger.error (server errors)
 *
 * Production safety:
 * - Stack traces stripped from response
 * - Sensitive fields redacted
 * - Generic messages for 5xx
 *
 * Usage:
 * app.useGlobalFilters(new GlobalExceptionFilter());
 */
@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const context = host.switchToHttp();
    const request = context.getRequest<
      Request & { id?: string; startTime?: number }
    >();
    const response = context.getResponse<Response>();

    const requestId =
      request.id ??
      (request.headers['x-request-id'] as string) ??
      this.generateRequestId();

    const startTime = request.startTime;

    // Build the unified error response
    const { response: errorResponse, httpStatus } = ErrorResponseBuilder.build({
      exception,
      requestId,
      path: request.url,
      service: process.env.SERVICE_NAME,
      startTime,
    });

    // Log with appropriate level
    const logPayload = {
      error_code: errorResponse.error.code,
      error_type: errorResponse.error.type,
      status: httpStatus,
      path: request.url,
      method: request.method,
      request_id: requestId,
      ...(exception instanceof PostEngageException && exception.metadata
        ? { metadata: ErrorSanitizer.redactSensitiveFields(exception.metadata) }
        : {}),
    };

    if (httpStatus >= 500) {
      this.logger.error(
        errorResponse.error.message,
        exception instanceof Error ? exception.stack : undefined,
        logPayload,
      );
    } else {
      this.logger.warn(errorResponse.error.message, logPayload);
    }

    // Report to Sentry (only 5xx — client errors are filtered by SentryConfig)
    SentryConfig.captureException(exception, {
      httpStatus,
      errorCode: errorResponse.error.code,
      requestId,
      path: request.url,
      service: process.env.SERVICE_NAME,
      metadata:
        exception instanceof PostEngageException
          ? exception.metadata
          : undefined,
    });

    // Add retry-after header for rate limit errors
    if (
      httpStatus === 429 &&
      exception instanceof PostEngageException &&
      exception.retryAfterSeconds
    ) {
      response.setHeader('Retry-After', String(exception.retryAfterSeconds));
    }

    // Set standard headers
    response.setHeader('X-Request-ID', requestId);

    // Send response
    response.status(httpStatus).json(errorResponse);
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
  }
}
