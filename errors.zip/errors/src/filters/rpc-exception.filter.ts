import {
  type ArgumentsHost,
  Catch,
  type ExceptionFilter,
  Logger,
} from '@nestjs/common';
import { Observable, throwError } from 'rxjs';

import { PostEngageException } from '../core/postengage.exception';
import { ErrorResponseBuilder } from '../utils/error-response.builder';
import { ErrorSanitizer } from '../sanitizers/error-sanitizer';

/**
 * RpcExceptionFilter — exception filter for BullMQ job processors
 * (Worker and Scheduler services).
 *
 * Catches ALL exceptions in queue job handlers, logs them,
 * and re-throws with structured error data for BullMQ to handle.
 *
 * Note: Does not depend on @nestjs/microservices — uses plain Error re-throw.
 * If @nestjs/microservices is installed, wrap with RpcException in the service layer.
 *
 * Usage:
 * app.useGlobalFilters(new RpcExceptionFilter());
 */
@Catch()
export class RpcExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(RpcExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): Observable<never> {
    void host;
    const requestId = this.generateRequestId();

    // Build the unified error response (same shape as HTTP)
    const { response: errorResponse, httpStatus } = ErrorResponseBuilder.build({
      exception,
      requestId,
      path: 'rpc',
      service: process.env.SERVICE_NAME ?? 'worker',
    });

    // Log
    const logPayload = {
      error_code: errorResponse.error.code,
      status: httpStatus,
      request_id: requestId,
      ...(exception instanceof PostEngageException && exception.metadata
        ? { metadata: ErrorSanitizer.redactSensitiveFields(exception.metadata) }
        : {}),
    };

    this.logger.error(
      errorResponse.error.message,
      exception instanceof Error ? exception.stack : undefined,
      logPayload,
    );

    // Re-throw as a structured error for BullMQ to handle (retries, DLQ, etc.)
    return throwError(() => {
      const error = new Error(errorResponse.error.message) as unknown as Record<
        string,
        unknown
      >;
      error.code = errorResponse.error.code;
      error.type = errorResponse.error.type;
      error.request_id = requestId;
      return error;
    });
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
  }
}
