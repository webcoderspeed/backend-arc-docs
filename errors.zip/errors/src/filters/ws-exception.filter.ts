import { type ArgumentsHost, Catch, Logger } from '@nestjs/common';
import { BaseWsExceptionFilter } from '@nestjs/websockets';

import { PostEngageException } from '../core/postengage.exception';
import { ErrorResponseBuilder } from '../utils/error-response.builder';
import { ErrorSanitizer } from '../sanitizers/error-sanitizer';
import { SentryConfig } from '../sentry/sentry.config';

/**
 * WsExceptionFilter — WebSocket exception filter for Pulse service.
 *
 * Catches ALL exceptions in Socket.io gateway handlers and emits
 * a structured PostEngageErrorResponse to the client via the 'error' event.
 *
 * Usage:
 * `@UseFilters(new WsExceptionFilter())`
 * `@WebSocketGateway()`
 * `export class PulseGateway { ... }`
 */
@Catch()
export class WsExceptionFilter extends BaseWsExceptionFilter {
  private readonly logger = new Logger(WsExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const wsContext = host.switchToWs();
    const client: { emit?: (event: string, data: unknown) => void } =
      wsContext.getClient();

    const requestId = this.generateRequestId();

    // Build the unified error response (same shape as HTTP)
    const { response: errorResponse, httpStatus } = ErrorResponseBuilder.build({
      exception,
      requestId,
      path: 'ws',
      service: process.env.SERVICE_NAME ?? 'pulse',
    });

    // Log
    const logPayload = {
      error_code: errorResponse.error.code,
      status: httpStatus,
      request_id: requestId,
      ...(exception instanceof PostEngageException && exception.metadata
        ? { metadata: ErrorSanitizer.redactSensitiveFields(exception.metadata) }
        : {}),
    };

    if (httpStatus >= 500) {
      this.logger.error(
        errorResponse.error.message,
        exception instanceof Error ? exception.stack : undefined,
        logPayload,
      );
    } else {
      this.logger.warn(errorResponse.error.message, logPayload);
    }

    // Report to Sentry (only 5xx)
    SentryConfig.captureException(exception, {
      httpStatus,
      errorCode: errorResponse.error.code,
      requestId,
      path: 'ws',
      service: process.env.SERVICE_NAME ?? 'pulse',
      metadata:
        exception instanceof PostEngageException
          ? exception.metadata
          : undefined,
    });

    // Emit error to client
    if (client && typeof client.emit === 'function') {
      client.emit('error', errorResponse);
    }
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
  }
}
