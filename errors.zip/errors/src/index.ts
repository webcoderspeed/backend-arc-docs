// ─── Module ───────────────────────────────────────────────────────────────────
export { ErrorsModule } from './errors.module';

// ─── Core Exception Classes ──────────────────────────────────────────────────
export {
  PostEngageException,
  type PostEngageExceptionOptions,
} from './core/postengage.exception';
export { ValidationException } from './core/validation.exception';
export { PlatformException } from './core/platform.exception';

// ─── Types ───────────────────────────────────────────────────────────────────
export {
  ErrorType,
  ErrorDomain,
  ErrorSeverity,
} from './types/error-code.types';
export type {
  PostEngageErrorResponse,
  ErrorDetail,
  ResponseMeta,
  DebugInfo,
} from './types/error-response.types';
export type { ErrorCodeDefinition } from './types/error-definition.types';

// ─── Error Code Registry ─────────────────────────────────────────────────────
// IMPORTANT: This import registers the lookup function with PostEngageException.
// It MUST be imported before any PostEngageException is thrown.
export {
  ERROR_REGISTRY,
  ERROR_CODES,
  type ErrorCode,
  getErrorDefinition,
  isValidErrorCode,
  getErrorCodesByDomain,
  getErrorCodesBySeverity,
  getAllErrorCodes,
} from './codes/index';

// Re-export individual code sets for direct access
export { AUTH_ERROR_CODES } from './codes/auth.codes';
export { USER_ERROR_CODES } from './codes/user.codes';
export { VALIDATION_ERROR_CODES } from './codes/validation.codes';
export { RATE_LIMIT_ERROR_CODES } from './codes/rate-limit.codes';
export { PAYMENT_ERROR_CODES } from './codes/payment.codes';
export { SOCIAL_ERROR_CODES } from './codes/social.codes';
export { ENGAGEMENT_ERROR_CODES } from './codes/engagement.codes';
export { FILE_ERROR_CODES } from './codes/file.codes';
export { WEBSOCKET_ERROR_CODES } from './codes/websocket.codes';
export { QUEUE_ERROR_CODES } from './codes/queue.codes';
export { INTERNAL_ERROR_CODES } from './codes/internal.codes';
export { EXTERNAL_ERROR_CODES } from './codes/external.codes';
export { API_ERROR_CODES } from './codes/api.codes';
export { DATABASE_ERROR_CODES } from './codes/database.codes';

// ─── Exception Filters ──────────────────────────────────────────────────────
export { GlobalExceptionFilter } from './filters/global-exception.filter';
export { WsExceptionFilter } from './filters/ws-exception.filter';
export { RpcExceptionFilter } from './filters/rpc-exception.filter';

// ─── Error Handlers ─────────────────────────────────────────────────────────
export { MongooseErrorHandler } from './handlers/mongoose-error.handler';
export { ThrottlerErrorHandler } from './handlers/throttler-error.handler';
export { ValidationPipeErrorHandler } from './handlers/validation-pipe-error.handler';

// ─── Sanitizers ─────────────────────────────────────────────────────────────
export { ErrorSanitizer } from './sanitizers/error-sanitizer';

// ─── Utils ──────────────────────────────────────────────────────────────────
export { ErrorResponseBuilder } from './utils/error-response.builder';
export {
  getErrorMessage,
  getErrorInfo,
  getErrorStack,
  type ErrorInfo,
} from './utils/error-message.utilities';
export {
  httpStatusToErrorType,
  httpStatusToErrorCode,
} from './utils/http-status.mapper';

// ─── Sentry ─────────────────────────────────────────────────────────────────
export { SentryConfig, type SentryInitOptions } from './sentry/index';

// ─── Resilience ─────────────────────────────────────────────────────────────
export {
  CircuitBreaker,
  CircuitState,
  type CircuitBreakerOptions,
} from './resilience/circuit-breaker';
export { withRetry, type RetryOptions } from './resilience/retry';
export {
  GracefulShutdown,
  type GracefulShutdownOptions,
} from './resilience/graceful-shutdown';
