import { Logger } from '@nestjs/common';
import type { INestApplication } from '@nestjs/common';
import { SentryConfig } from '../sentry/sentry.config';

/**
 * GracefulShutdown — handles SIGTERM/SIGINT for clean service teardown.
 *
 * Shutdown sequence:
 * 1. Stop accepting new requests
 * 2. Wait for in-flight requests to complete (with timeout)
 * 3. Close database / Redis / queue connections (NestJS shutdown hooks)
 * 4. Flush Sentry events
 * 5. Exit cleanly
 *
 * Usage (in main.ts, after app.listen):
 * GracefulShutdown.register(app, { serviceName: 'gatekeeper' });
 */

export interface GracefulShutdownOptions {
  /** Service name for logging */
  serviceName: string;
  /** Max time to wait for in-flight requests in ms (default: 30000) */
  shutdownTimeoutMs?: number;
  /** Max time to wait for Sentry flush in ms (default: 5000) */
  sentryFlushTimeoutMs?: number;
  /** Additional cleanup functions to run during shutdown */
  onShutdown?: () => Promise<void>;
}

export class GracefulShutdown {
  private static readonly logger = new Logger(GracefulShutdown.name);
  private static isShuttingDown = false;

  /**
   * Register shutdown handlers for a NestJS application.
   * Call this AFTER app.listen() in main.ts.
   */
  static register(
    app: INestApplication,
    options: GracefulShutdownOptions,
  ): void {
    const {
      serviceName,
      shutdownTimeoutMs = 30_000,
      sentryFlushTimeoutMs = 5000,
      onShutdown,
    } = options;

    // NestJS shutdown hooks handle DB/Redis/Queue cleanup
    app.enableShutdownHooks();

    const shutdown = async (signal: string) => {
      if (this.isShuttingDown) {
        this.logger.warn(
          `[${serviceName}] Duplicate ${signal} received, ignoring`,
        );
        return;
      }

      this.isShuttingDown = true;
      this.logger.log(
        `[${serviceName}] ${signal} received — starting graceful shutdown ` +
          `(timeout: ${shutdownTimeoutMs}ms)`,
      );

      // Force-kill safety net
      const forceKillTimer = setTimeout(() => {
        this.logger.error(
          `[${serviceName}] Shutdown timed out after ${shutdownTimeoutMs}ms — forcing exit`,
        );
        process.exit(1);
      }, shutdownTimeoutMs);

      // Prevent the timer from keeping the process alive
      forceKillTimer.unref();

      try {
        // 1. Run custom cleanup
        if (onShutdown) {
          this.logger.log(`[${serviceName}] Running custom shutdown hooks...`);
          await onShutdown();
        }

        // 2. Close NestJS app (triggers onModuleDestroy, onApplicationShutdown hooks)
        // This handles: Mongoose disconnect, Redis disconnect, BullMQ close, etc.
        this.logger.log(`[${serviceName}] Closing NestJS application...`);
        await app.close();

        // 3. Flush Sentry
        this.logger.log(`[${serviceName}] Flushing Sentry events...`);
        await SentryConfig.flush(sentryFlushTimeoutMs);

        this.logger.log(`[${serviceName}] Graceful shutdown complete`);
        clearTimeout(forceKillTimer);
        process.exit(0);
      } catch (error) {
        this.logger.error(
          `[${serviceName}] Error during shutdown: ${error instanceof Error ? error.message : error}`,
        );
        clearTimeout(forceKillTimer);
        process.exit(1);
      }
    };

    process.on('SIGTERM', () => void shutdown('SIGTERM'));
    process.on('SIGINT', () => void shutdown('SIGINT'));
  }
}
