import { Logger } from '@nestjs/common';

/**
 * withRetry — Retry with exponential backoff for transient failures.
 *
 * Only retries on transient errors:
 * - Network: ECONNRESET, ETIMEDOUT, ECONNREFUSED, EPIPE, EAI_AGAIN
 * - HTTP: 502, 503, 504, 408
 *
 * Never retries on:
 * - Client errors: 400, 401, 403, 404, 409, 422
 * - Business logic errors (PostEngageException with 4xx status)
 *
 * Usage:
 * const profile = await withRetry(
 * () => instagramClient.getProfile(id),
 * { maxRetries: 3, serviceName: 'instagram-api' },
 * );
 */

export interface RetryOptions {
  /** Maximum number of retry attempts (default: 3) */
  maxRetries?: number;
  /** Base delay in ms for exponential backoff (default: 1000) */
  baseDelayMs?: number;
  /** Maximum delay in ms cap (default: 30000) */
  maxDelayMs?: number;
  /** Jitter factor 0-1 to randomize delays (default: 0.2) */
  jitterFactor?: number;
  /** Service name for logging */
  serviceName?: string;
  /** Custom function to determine if an error is retryable */
  isRetryable?: (error: unknown) => boolean;
  /** Called before each retry — return false to abort */
  onRetry?: (
    error: unknown,
    attempt: number,
    delayMs: number,
  ) => boolean | void;
}

/** Network error codes that indicate transient failures */
const RETRYABLE_NETWORK_CODES = new Set([
  'ECONNRESET',
  'ETIMEDOUT',
  'ECONNREFUSED',
  'EPIPE',
  'EAI_AGAIN',
  'ENOTFOUND',
  'EHOSTUNREACH',
  'ENETUNREACH',
  'UND_ERR_CONNECT_TIMEOUT',
  'UND_ERR_SOCKET',
]);

/** HTTP status codes that indicate transient failures */
const RETRYABLE_HTTP_STATUSES = new Set([408, 429, 500, 502, 503, 504]);

/** HTTP status codes that should NEVER be retried */
const NON_RETRYABLE_HTTP_STATUSES = new Set([
  400, 401, 403, 404, 405, 409, 422,
]);

const logger = new Logger('Retry');

export async function withRetry<T>(
  function_: () => Promise<T>,
  options: RetryOptions = {},
): Promise<T> {
  const {
    maxRetries = 3,
    baseDelayMs = 1000,
    maxDelayMs = 30_000,
    jitterFactor = 0.2,
    serviceName = 'unknown',
    isRetryable: customIsRetryable,
    onRetry,
  } = options;

  let lastError: unknown;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await function_();
    } catch (error) {
      lastError = error;

      const shouldAbort = await handleRetryAttempt(
        error,
        attempt,
        maxRetries,
        baseDelayMs,
        maxDelayMs,
        jitterFactor,
        serviceName,
        customIsRetryable,
        onRetry,
      );

      if (shouldAbort) {
        break;
      }
    }
  }

  throw lastError;
}

async function handleRetryAttempt(
  error: unknown,
  attempt: number,
  maxRetries: number,
  baseDelayMs: number,
  maxDelayMs: number,
  jitterFactor: number,
  serviceName: string,
  customIsRetryable: ((error: unknown) => boolean) | undefined,
  onRetry:
    | ((error: unknown, attempt: number, delay: number) => boolean | void)
    | undefined,
): Promise<boolean> {
  if (attempt >= maxRetries) {
    return true;
  }

  const retryable = customIsRetryable
    ? customIsRetryable(error)
    : isTransientError(error);
  if (!retryable) {
    return true;
  }

  const delay = calculateDelay(attempt, baseDelayMs, maxDelayMs, jitterFactor);
  const retryAfter = getRetryAfterMs(error);
  const effectiveDelay = retryAfter ? Math.max(delay, retryAfter) : delay;

  if (onRetry) {
    const shouldContinue = onRetry(error, attempt + 1, effectiveDelay);
    if (shouldContinue === false) {
      return true;
    }
  }

  logger.warn(
    `[${serviceName}] Attempt ${attempt + 1}/${maxRetries} failed, ` +
      `retrying in ${effectiveDelay}ms: ${getErrorSummary(error)}`,
  );

  await sleep(effectiveDelay);
  return false;
}

/**
 * Determine if an error is a transient failure worth retrying.
 */
function isTransientError(error: unknown): boolean {
  if (!error || typeof error !== 'object') {
    return false;
  }

  const errorObject = error as Record<string, unknown>;

  if (isRetryableNetworkCode(errorObject)) {
    return true;
  }

  if (isRetryableHttpStatus(errorObject)) {
    return true;
  }

  if (isTimeoutError(errorObject)) {
    return true;
  }

  return false;
}

function isRetryableNetworkCode(error: Record<string, unknown>): boolean {
  const code = error.code ?? (error.cause as Record<string, unknown>)?.code;
  return typeof code === 'string' && RETRYABLE_NETWORK_CODES.has(code);
}

function isRetryableHttpStatus(error: Record<string, unknown>): boolean {
  const status =
    error.status ??
    error.statusCode ??
    (error.response as Record<string, unknown>)?.status;

  if (typeof status !== 'number') {
    return false;
  }

  if (NON_RETRYABLE_HTTP_STATUSES.has(status)) {
    return false;
  }

  return RETRYABLE_HTTP_STATUSES.has(status);
}

function isTimeoutError(error: Record<string, unknown>): boolean {
  const message = error.message as string;
  if (typeof message !== 'string') {
    return false;
  }

  const lowerMessage = message.toLowerCase();
  return (
    lowerMessage.includes('timeout') ||
    lowerMessage.includes('econnreset') ||
    lowerMessage.includes('socket hang up')
  );
}

/**
 * Calculate delay with exponential backoff + jitter.
 * Formula: min(maxDelay, baseDelay * 2^attempt * (1 + random * jitter))
 */
function calculateDelay(
  attempt: number,
  baseDelayMs: number,
  maxDelayMs: number,
  jitterFactor: number,
): number {
  const exponential = baseDelayMs * Math.pow(2, attempt);
  const jitter = 1 + Math.random() * jitterFactor;
  return Math.min(maxDelayMs, Math.round(exponential * jitter));
}

/**
 * Extract Retry-After value from error (for 429 responses).
 * Returns delay in milliseconds, or undefined if not present.
 */
function getRetryAfterMs(error: unknown): number | undefined {
  if (!error || typeof error !== 'object') return undefined;

  const error_ = error as Record<string, unknown>;
  const headers =
    (error_.headers as Record<string, string>) ??
    ((error_.response as Record<string, unknown>)?.headers as Record<
      string,
      string
    >);

  if (!headers) return undefined;

  const retryAfter = headers['retry-after'] ?? headers['Retry-After'];
  if (!retryAfter) return undefined;

  // Could be seconds (integer) or HTTP date
  const seconds = Number(retryAfter);
  if (!isNaN(seconds)) {
    return seconds * 1000;
  }

  // Try parsing as HTTP date
  const date = new Date(retryAfter);
  if (!isNaN(date.getTime())) {
    return Math.max(0, date.getTime() - Date.now());
  }

  return undefined;
}

function getErrorSummary(error: unknown): string {
  if (error instanceof Error) {
    return error.message.substring(0, 120);
  }
  return String(error).substring(0, 120);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
