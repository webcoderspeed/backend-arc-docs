import { Logger } from '@nestjs/common';
import { PostEngageException } from '../core/postengage.exception';

/**
 * CircuitBreaker — prevents cascading failures from external services.
 *
 * States:
 * CLOSED   → Normal operation, requests go through
 * OPEN     → Too many failures, requests are rejected immediately
 * HALF_OPEN → After timeout, allow ONE request to test recovery
 *
 * Usage:
 * const breaker = new CircuitBreaker('instagram-api', { failureThreshold: 5 });
 *
 * const result = await breaker.execute(() => instagramClient.getProfile(id));
 *
 * When open, throws PostEngageException(PE-EXT-003) — "External service unavailable"
 */

export enum CircuitState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN',
  HALF_OPEN = 'HALF_OPEN',
}

export interface CircuitBreakerOptions {
  /** Number of consecutive failures before opening the circuit (default: 5) */
  failureThreshold?: number;
  /** Time in ms to wait before transitioning from OPEN → HALF_OPEN (default: 30000) */
  resetTimeoutMs?: number;
  /** Maximum number of requests to allow in HALF_OPEN state (default: 1) */
  halfOpenMaxRequests?: number;
  /** Error code to throw when circuit is open (default: 'PE-EXT-003') */
  openErrorCode?: string;
  /** Called on state transitions */
  onStateChange?: (
    from: CircuitState,
    to: CircuitState,
    serviceName: string,
  ) => void;
}

export interface CircuitStats {
  failures: number;
  successes: number;
  lastFailureTime: number;
  halfOpenAttempts: number;
}

export class CircuitBreaker {
  private readonly logger: Logger;
  private state: CircuitState = CircuitState.CLOSED;
  private stats: CircuitStats = {
    failures: 0,
    successes: 0,
    lastFailureTime: 0,
    halfOpenAttempts: 0,
  };

  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private readonly halfOpenMaxRequests: number;
  private readonly openErrorCode: string;
  private readonly onStateChange?: CircuitBreakerOptions['onStateChange'];

  constructor(
    private readonly serviceName: string,
    options: CircuitBreakerOptions = {},
  ) {
    this.logger = new Logger(`CircuitBreaker:${serviceName}`);
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 30_000;
    this.halfOpenMaxRequests = options.halfOpenMaxRequests ?? 1;
    this.openErrorCode = options.openErrorCode ?? 'PE-EXT-003';
    this.onStateChange = options.onStateChange;
  }

  /**
   * Execute a function through the circuit breaker.
   * @throws PostEngageException if circuit is open
   */
  async execute<T>(function_: () => Promise<T>): Promise<T> {
    // Check if we should transition from OPEN → HALF_OPEN
    if (this.state === CircuitState.OPEN) {
      if (this.shouldAttemptReset()) {
        this.transitionTo(CircuitState.HALF_OPEN);
      } else {
        throw new PostEngageException(this.openErrorCode, {
          message: `Service "${this.serviceName}" is temporarily unavailable (circuit open).`,
          metadata: {
            service: this.serviceName,
            circuit_state: this.state,
            failures: this.stats.failures,
            retry_after_ms: this.getRetryAfterMs(),
          },
        });
      }
    }

    // In HALF_OPEN, limit concurrent attempts
    if (
      this.state === CircuitState.HALF_OPEN &&
      this.stats.halfOpenAttempts >= this.halfOpenMaxRequests
    ) {
      throw new PostEngageException(this.openErrorCode, {
        message: `Service "${this.serviceName}" is recovering (circuit half-open, max attempts reached).`,
        metadata: {
          service: this.serviceName,
          circuit_state: this.state,
        },
      });
    }

    try {
      if (this.state === CircuitState.HALF_OPEN) {
        this.stats.halfOpenAttempts++;
      }

      const result = await function_();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  /** Get current circuit state */
  getState(): CircuitState {
    return this.state;
  }

  /** Get current stats (for monitoring) */
  getStats(): Readonly<
    CircuitStats & { state: CircuitState; serviceName: string }
  > {
    return {
      ...this.stats,
      state: this.state,
      serviceName: this.serviceName,
    };
  }

  /** Manually reset the circuit to CLOSED */
  reset(): void {
    this.transitionTo(CircuitState.CLOSED);
    this.resetStats();
  }

  private onSuccess(): void {
    if (this.state === CircuitState.HALF_OPEN) {
      // Recovery confirmed — close the circuit
      this.logger.log(
        `Service "${this.serviceName}" recovered — closing circuit`,
      );
      this.transitionTo(CircuitState.CLOSED);
      this.resetStats();
    } else {
      this.stats.successes++;
      // Reset failure count on success (consecutive failures model)
      this.stats.failures = 0;
    }
  }

  private onFailure(): void {
    this.stats.failures++;
    this.stats.lastFailureTime = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      // Recovery failed — reopen the circuit
      this.logger.warn(
        `Service "${this.serviceName}" recovery failed — reopening circuit`,
      );
      this.transitionTo(CircuitState.OPEN);
      this.stats.halfOpenAttempts = 0;
    } else if (this.stats.failures >= this.failureThreshold) {
      // Too many failures — open the circuit
      this.logger.error(
        `Service "${this.serviceName}" hit failure threshold (${this.stats.failures}/${this.failureThreshold}) — opening circuit`,
      );
      this.transitionTo(CircuitState.OPEN);
    }
  }

  private shouldAttemptReset(): boolean {
    return Date.now() - this.stats.lastFailureTime >= this.resetTimeoutMs;
  }

  private getRetryAfterMs(): number {
    const elapsed = Date.now() - this.stats.lastFailureTime;
    return Math.max(0, this.resetTimeoutMs - elapsed);
  }

  private transitionTo(newState: CircuitState): void {
    const oldState = this.state;
    if (oldState === newState) return;

    this.state = newState;
    this.logger.log(`Circuit "${this.serviceName}": ${oldState} → ${newState}`);

    if (newState === CircuitState.HALF_OPEN) {
      this.stats.halfOpenAttempts = 0;
    }

    this.onStateChange?.(oldState, newState, this.serviceName);
  }

  private resetStats(): void {
    this.stats = {
      failures: 0,
      successes: 0,
      lastFailureTime: 0,
      halfOpenAttempts: 0,
    };
  }
}
