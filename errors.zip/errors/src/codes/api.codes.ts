import type { ErrorCodeDefinition } from '../types/error-definition.types';
import {
  ErrorDomain,
  ErrorSeverity,
  ErrorType,
} from '../types/error-code.types';

export const API_ERROR_CODES = {
  'PE-API-001': {
    code: 'PE-API-001',
    type: ErrorType.NOT_FOUND,
    domain: ErrorDomain.API,
    httpStatus: 404,
    message: 'Endpoint not found.',
    developerMessage: 'No route handler for this URL',
    severity: ErrorSeverity.LOW,
    retryable: false,
  },
  'PE-API-002': {
    code: 'PE-API-002',
    type: ErrorType.API,
    domain: ErrorDomain.API,
    httpStatus: 405,
    message: 'HTTP method not allowed.',
    developerMessage: 'This endpoint does not support the given HTTP method',
    severity: ErrorSeverity.LOW,
    retryable: false,
  },
  'PE-API-003': {
    code: 'PE-API-003',
    type: ErrorType.API,
    domain: ErrorDomain.API,
    httpStatus: 406,
    message: 'Not acceptable.',
    developerMessage: 'Cannot produce a response matching the Accept headers',
    severity: ErrorSeverity.LOW,
    retryable: false,
  },
  'PE-API-004': {
    code: 'PE-API-004',
    type: ErrorType.API,
    domain: ErrorDomain.API,
    httpStatus: 400,
    message: 'Invalid API version.',
    developerMessage: 'Requested API version is not supported',
    severity: ErrorSeverity.LOW,
    retryable: false,
  },
  'PE-API-005': {
    code: 'PE-API-005',
    type: ErrorType.VALIDATION,
    domain: ErrorDomain.API,
    httpStatus: 400,
    message: 'Malformed request body.',
    developerMessage: 'Request body could not be parsed (invalid JSON, etc.)',
    severity: ErrorSeverity.LOW,
    retryable: false,
  },
} as const satisfies Record<string, ErrorCodeDefinition>;
