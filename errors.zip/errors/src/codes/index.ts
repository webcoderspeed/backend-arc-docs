import type { ErrorCodeDefinition } from '../types/error-definition.types';
import type { ErrorDomain, ErrorSeverity } from '../types/error-code.types';
import { setErrorRegistryLookup } from '../core/postengage.exception';

import { AUTH_ERROR_CODES } from './auth.codes';
import { USER_ERROR_CODES } from './user.codes';
import { VALIDATION_ERROR_CODES } from './validation.codes';
import { RATE_LIMIT_ERROR_CODES } from './rate-limit.codes';
import { PAYMENT_ERROR_CODES } from './payment.codes';
import { SOCIAL_ERROR_CODES } from './social.codes';
import { ENGAGEMENT_ERROR_CODES } from './engagement.codes';
import { FILE_ERROR_CODES } from './file.codes';
import { WEBSOCKET_ERROR_CODES } from './websocket.codes';
import { QUEUE_ERROR_CODES } from './queue.codes';
import { INTERNAL_ERROR_CODES } from './internal.codes';
import { EXTERNAL_ERROR_CODES } from './external.codes';
import { API_ERROR_CODES } from './api.codes';
import { DATABASE_ERROR_CODES } from './database.codes';

// Re-export all code sets for direct access
export { AUTH_ERROR_CODES } from './auth.codes';
export { USER_ERROR_CODES } from './user.codes';
export { VALIDATION_ERROR_CODES } from './validation.codes';
export { RATE_LIMIT_ERROR_CODES } from './rate-limit.codes';
export { PAYMENT_ERROR_CODES } from './payment.codes';
export { SOCIAL_ERROR_CODES } from './social.codes';
export { ENGAGEMENT_ERROR_CODES } from './engagement.codes';
export { FILE_ERROR_CODES } from './file.codes';
export { WEBSOCKET_ERROR_CODES } from './websocket.codes';
export { QUEUE_ERROR_CODES } from './queue.codes';
export { INTERNAL_ERROR_CODES } from './internal.codes';
export { EXTERNAL_ERROR_CODES } from './external.codes';
export { API_ERROR_CODES } from './api.codes';
export { DATABASE_ERROR_CODES } from './database.codes';

// ─── Human-readable error code constants ─────────────────────────
export { ERROR_CODES } from './constants';
export {
  AUTH,
  USER,
  VALIDATION,
  RATE_LIMIT,
  PAYMENT,
  SOCIAL,
  ENGAGEMENT,
  FILE,
  WEBSOCKET,
  QUEUE,
  INTERNAL,
  EXTERNAL,
  API,
  DATABASE,
} from './constants';

/**
 * Complete error code registry — every PE-xxx code in the system
 */
export const ERROR_REGISTRY = {
  ...AUTH_ERROR_CODES,
  ...USER_ERROR_CODES,
  ...VALIDATION_ERROR_CODES,
  ...RATE_LIMIT_ERROR_CODES,
  ...PAYMENT_ERROR_CODES,
  ...SOCIAL_ERROR_CODES,
  ...ENGAGEMENT_ERROR_CODES,
  ...FILE_ERROR_CODES,
  ...WEBSOCKET_ERROR_CODES,
  ...QUEUE_ERROR_CODES,
  ...INTERNAL_ERROR_CODES,
  ...EXTERNAL_ERROR_CODES,
  ...API_ERROR_CODES,
  ...DATABASE_ERROR_CODES,
} as const;

/** Union type of all valid error codes */
export type ErrorCode = keyof typeof ERROR_REGISTRY;

/**
 * Register the lookup function with PostEngageException.
 * This runs at import time — as soon as codes/index.ts is imported,
 * PostEngageException can look up definitions.
 */
setErrorRegistryLookup((code: string) => {
  return ERROR_REGISTRY[code as ErrorCode] as ErrorCodeDefinition | undefined;
});

/**
 * Look up an error code definition from the registry.
 * Returns undefined if the code is not found.
 */
export function getErrorDefinition(
  code: string,
): ErrorCodeDefinition | undefined {
  return ERROR_REGISTRY[code as ErrorCode] as ErrorCodeDefinition | undefined;
}

/**
 * Check if a string is a valid error code
 */
export function isValidErrorCode(code: string): code is ErrorCode {
  return code in ERROR_REGISTRY;
}

/**
 * Get all error codes for a specific domain
 */
export function getErrorCodesByDomain(
  domain: ErrorDomain,
): ErrorCodeDefinition[] {
  return Object.values(ERROR_REGISTRY).filter(
    (definition) => definition.domain === domain,
  ) as ErrorCodeDefinition[];
}

/**
 * Get all error codes with a specific severity
 */
export function getErrorCodesBySeverity(
  severity: ErrorSeverity,
): ErrorCodeDefinition[] {
  return Object.values(ERROR_REGISTRY).filter(
    (definition) => definition.severity === severity,
  ) as ErrorCodeDefinition[];
}

/**
 * Get all error code definitions as an array
 */
export function getAllErrorCodes(): ErrorCodeDefinition[] {
  return Object.values(ERROR_REGISTRY) as ErrorCodeDefinition[];
}
