/**
 * Error Code Constants — human-readable accessors for all PE-xxx error codes.
 *
 * Usage:
 * import { ERROR_CODES } from '@app/errors';
 * throw new PostEngageException(ERROR_CODES.AUTH.INVALID_CREDENTIALS);
 * throw new PostEngageException(ERROR_CODES.AUTH.SESSION_EXPIRED, { message: 'Custom message' });
 *
 * Each constant maps to a PE-xxx string that is registered in the error code registry.
 * Never use hardcoded strings like 'PE-AUTH-001' — always use these constants.
 */

// ─── AUTH (PE-AUTH-001 → PE-AUTH-020) ────────────────────────────
export const AUTH = {
  INVALID_CREDENTIALS: 'PE-AUTH-001',
  SESSION_EXPIRED: 'PE-AUTH-002',
  MISSING_AUTH: 'PE-AUTH-003',
  SESSION_REVOKED: 'PE-AUTH-004',
  ACCOUNT_LOCKED: 'PE-AUTH-005',
  ACCOUNT_SUSPENDED: 'PE-AUTH-006',
  EMAIL_NOT_VERIFIED: 'PE-AUTH-007',
  PASSWORD_RESET_REQUIRED: 'PE-AUTH-008',
  OAUTH_FAILED: 'PE-AUTH-009',
  SOCIAL_ACCOUNT_LINKED: 'PE-AUTH-010',
  RATE_LIMIT: 'PE-AUTH-011',
  SECURITY_VIOLATION: 'PE-AUTH-012',
  DUPLICATE_EMAIL: 'PE-AUTH-013',
  INVALID_TOKEN: 'PE-AUTH-014',
  TOKEN_EXPIRED: 'PE-AUTH-015',
  ALREADY_VERIFIED: 'PE-AUTH-016',
  VERIFICATION_ACTIVE: 'PE-AUTH-017',
  INSUFFICIENT_PERMISSIONS: 'PE-AUTH-018',
  PLAN_REQUIRED: 'PE-AUTH-019',
  INVALID_REFRESH_TOKEN: 'PE-AUTH-020',
} as const;

// ─── USER (PE-USR-001 → PE-USR-008) ─────────────────────────────
export const USER = {
  NOT_FOUND: 'PE-USR-001',
  DUPLICATE_EMAIL: 'PE-USR-002',
  DUPLICATE_USERNAME: 'PE-USR-003',
  INVALID_PROFILE: 'PE-USR-004',
  DEACTIVATED: 'PE-USR-005',
  WEAK_PASSWORD: 'PE-USR-006',
  SESSION_NOT_FOUND: 'PE-USR-007',
  SOCIAL_ALREADY_CONNECTED: 'PE-USR-008',
} as const;

// ─── VALIDATION (PE-VAL-001 → PE-VAL-008) ───────────────────────
export const VALIDATION = {
  FAILED: 'PE-VAL-001',
  REQUIRED_FIELD: 'PE-VAL-002',
  INVALID_FORMAT: 'PE-VAL-003',
  OUT_OF_RANGE: 'PE-VAL-004',
  INVALID_ENUM: 'PE-VAL-005',
  STRING_TOO_LONG: 'PE-VAL-006',
  INVALID_PAGINATION: 'PE-VAL-007',
  UNSUPPORTED_CONTENT_TYPE: 'PE-VAL-008',
} as const;

// ─── RATE LIMIT (PE-RATE-001 → PE-RATE-005) ─────────────────────
export const RATE_LIMIT = {
  GLOBAL: 'PE-RATE-001',
  PER_ENDPOINT: 'PE-RATE-002',
  LOGIN: 'PE-RATE-003',
  SIGNUP: 'PE-RATE-004',
  DAILY_QUOTA: 'PE-RATE-005',
} as const;

// ─── PAYMENT (PE-PAY-001 → PE-PAY-008) ──────────────────────────
export const PAYMENT = {
  PROCESSING_FAILED: 'PE-PAY-001',
  VERIFICATION_FAILED: 'PE-PAY-002',
  SUBSCRIPTION_EXPIRED: 'PE-PAY-003',
  PLAN_LIMIT_REACHED: 'PE-PAY-004',
  REFUND_FAILED: 'PE-PAY-005',
  ORDER_NOT_FOUND: 'PE-PAY-006',
  INVALID_METHOD: 'PE-PAY-007',
  SUBSCRIPTION_ACTIVE: 'PE-PAY-008',
} as const;

// ─── SOCIAL (PE-SOC-001 → PE-SOC-008) ───────────────────────────
export const SOCIAL = {
  AUTH_EXPIRED: 'PE-SOC-001',
  RATE_LIMIT: 'PE-SOC-002',
  POST_REJECTED: 'PE-SOC-003',
  ACCOUNT_SUSPENDED: 'PE-SOC-004',
  PLATFORM_UNAVAILABLE: 'PE-SOC-005',
  ACCOUNT_NOT_FOUND: 'PE-SOC-006',
  INVALID_MEDIA: 'PE-SOC-007',
  DUPLICATE_POST: 'PE-SOC-008',
} as const;

// ─── ENGAGEMENT (PE-ENG-001 → PE-ENG-008) ───────────────────────
export const ENGAGEMENT = {
  AUTOMATION_NOT_FOUND: 'PE-ENG-001',
  AUTOMATION_LIMIT: 'PE-ENG-002',
  INVALID_CONFIG: 'PE-ENG-003',
  ALREADY_RUNNING: 'PE-ENG-004',
  EXECUTION_FAILED: 'PE-ENG-005',
  LEAD_FORM_NOT_FOUND: 'PE-ENG-006',
  INVALID_TRIGGER: 'PE-ENG-007',
  NOTIFICATION_FAILED: 'PE-ENG-008',
} as const;

// ─── FILE (PE-FILE-001 → PE-FILE-006) ───────────────────────────
export const FILE = {
  TOO_LARGE: 'PE-FILE-001',
  UNSUPPORTED_TYPE: 'PE-FILE-002',
  UPLOAD_FAILED: 'PE-FILE-003',
  STORAGE_QUOTA: 'PE-FILE-004',
  NOT_FOUND: 'PE-FILE-005',
  INVALID_DIMENSIONS: 'PE-FILE-006',
} as const;

// ─── WEBSOCKET (PE-WS-001 → PE-WS-005) ─────────────────────────
export const WEBSOCKET = {
  AUTH_FAILED: 'PE-WS-001',
  CHANNEL_NOT_FOUND: 'PE-WS-002',
  MESSAGE_TOO_LARGE: 'PE-WS-003',
  TOO_MANY_CONNECTIONS: 'PE-WS-004',
  INVALID_EVENT: 'PE-WS-005',
} as const;

// ─── QUEUE (PE-QUEUE-001 → PE-QUEUE-006) ────────────────────────
export const QUEUE = {
  JOB_FAILED: 'PE-QUEUE-001',
  JOB_TIMEOUT: 'PE-QUEUE-002',
  QUEUE_FULL: 'PE-QUEUE-003',
  JOB_NOT_FOUND: 'PE-QUEUE-004',
  DUPLICATE_JOB: 'PE-QUEUE-005',
  MAX_RETRIES: 'PE-QUEUE-006',
} as const;

// ─── INTERNAL (PE-INT-001 → PE-INT-005) ─────────────────────────
export const INTERNAL = {
  UNEXPECTED: 'PE-INT-001',
  TIMEOUT: 'PE-INT-002',
  SERVICE_UNAVAILABLE: 'PE-INT-003',
  CONFIG_ERROR: 'PE-INT-004',
  UNCAUGHT: 'PE-INT-005',
} as const;

// ─── EXTERNAL (PE-EXT-001 → PE-EXT-005) ─────────────────────────
export const EXTERNAL = {
  SERVICE_ERROR: 'PE-EXT-001',
  TIMEOUT: 'PE-EXT-002',
  UNAVAILABLE: 'PE-EXT-003',
  INVALID_RESPONSE: 'PE-EXT-004',
  CONFIG_ERROR: 'PE-EXT-005',
} as const;

// ─── API (PE-API-001 → PE-API-005) ──────────────────────────────
export const API = {
  NOT_FOUND: 'PE-API-001',
  METHOD_NOT_ALLOWED: 'PE-API-002',
  NOT_ACCEPTABLE: 'PE-API-003',
  INVALID_VERSION: 'PE-API-004',
  MALFORMED_BODY: 'PE-API-005',
} as const;

// ─── DATABASE (PE-DB-001 → PE-DB-006) ───────────────────────────
export const DATABASE = {
  DUPLICATE: 'PE-DB-001',
  INVALID_ID: 'PE-DB-002',
  SCHEMA_VALIDATION: 'PE-DB-003',
  DOCUMENT_NOT_FOUND: 'PE-DB-004',
  VERSION_CONFLICT: 'PE-DB-005',
  CONNECTION_ERROR: 'PE-DB-006',
} as const;

// ─── Unified ERROR_CODES namespace ──────────────────────────────
/**
 * Main entry point for all error codes.
 *
 * Usage:
 * import { ERROR_CODES } from '@app/errors';
 *
 * throw new PostEngageException(ERROR_CODES.AUTH.INVALID_TOKEN);
 * throw new PostEngageException(ERROR_CODES.SOCIAL.ACCOUNT_NOT_FOUND, {
 * message: 'Social account not found',
 * });
 */
export const ERROR_CODES = {
  AUTH,
  USER,
  VALIDATION,
  RATE_LIMIT,
  PAYMENT,
  SOCIAL,
  ENGAGEMENT,
  FILE,
  WEBSOCKET,
  QUEUE,
  INTERNAL,
  EXTERNAL,
  API,
  DATABASE,
} as const;
