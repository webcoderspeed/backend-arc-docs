import type { ErrorCodeDefinition } from '../types/error-definition.types';
import {
  ErrorDomain,
  ErrorSeverity,
  ErrorType,
} from '../types/error-code.types';

export const EXTERNAL_ERROR_CODES = {
  'PE-EXT-001': {
    code: 'PE-EXT-001',
    type: ErrorType.PLATFORM,
    domain: ErrorDomain.EXT,
    httpStatus: 502,
    message: 'External service returned an error.',
    developerMessage: 'Third-party API responded with an error status',
    severity: ErrorSeverity.HIGH,
    retryable: true,
    retryAfterSeconds: 10,
  },
  'PE-EXT-002': {
    code: 'PE-EXT-002',
    type: ErrorType.PLATFORM,
    domain: ErrorDomain.EXT,
    httpStatus: 504,
    message: 'External service timed out.',
    developerMessage: 'Third-party API request exceeded timeout',
    severity: ErrorSeverity.HIGH,
    retryable: true,
    retryAfterSeconds: 15,
  },
  'PE-EXT-003': {
    code: 'PE-EXT-003',
    type: ErrorType.PLATFORM,
    domain: ErrorDomain.EXT,
    httpStatus: 503,
    message: 'External service unavailable.',
    developerMessage: 'Third-party API is down or unreachable',
    severity: ErrorSeverity.HIGH,
    retryable: true,
    retryAfterSeconds: 60,
  },
  'PE-EXT-004': {
    code: 'PE-EXT-004',
    type: ErrorType.PLATFORM,
    domain: ErrorDomain.EXT,
    httpStatus: 502,
    message: 'Invalid response from external service.',
    developerMessage: 'Third-party API returned an unparseable response',
    severity: ErrorSeverity.HIGH,
    retryable: true,
    retryAfterSeconds: 10,
  },
  'PE-EXT-005': {
    code: 'PE-EXT-005',
    type: ErrorType.SERVER,
    domain: ErrorDomain.EXT,
    httpStatus: 500,
    message: 'External service configuration error.',
    developerMessage:
      'Missing API key, secret, or endpoint for external service',
    severity: ErrorSeverity.CRITICAL,
    retryable: false,
  },
} as const satisfies Record<string, ErrorCodeDefinition>;
