import { ErrorType } from '../types/error-code.types';

/**
 * Maps HTTP status codes to the most appropriate ErrorType.
 * Used when catching generic HttpException (not PostEngageException).
 */
const HTTP_STATUS_TO_ERROR_TYPE: Record<number, ErrorType> = {
  400: ErrorType.VALIDATION,
  401: ErrorType.AUTHENTICATION,
  402: ErrorType.PAYMENT,
  403: ErrorType.AUTHORIZATION,
  404: ErrorType.NOT_FOUND,
  405: ErrorType.API,
  408: ErrorType.SERVER,
  409: ErrorType.CONFLICT,
  413: ErrorType.VALIDATION,
  415: ErrorType.API,
  422: ErrorType.VALIDATION,
  429: ErrorType.RATE_LIMIT,
  502: ErrorType.PLATFORM,
  503: ErrorType.SERVER,
  504: ErrorType.PLATFORM,
};

export function httpStatusToErrorType(status: number): ErrorType {
  if (HTTP_STATUS_TO_ERROR_TYPE[status]) {
    return HTTP_STATUS_TO_ERROR_TYPE[status];
  }
  if (status >= 400 && status < 500) return ErrorType.API;
  return ErrorType.SERVER;
}

/**
 * Maps HTTP status codes to a generic PE-xxx error code.
 * Used as fallback when the original exception has no PE code.
 */
export function httpStatusToErrorCode(status: number): string {
  const codeMap: Record<number, string> = {
    400: 'PE-VAL-001',
    401: 'PE-AUTH-003',
    403: 'PE-AUTH-018',
    404: 'PE-API-001',
    405: 'PE-API-002',
    408: 'PE-INT-002',
    409: 'PE-DB-001',
    413: 'PE-FILE-001',
    415: 'PE-VAL-008',
    422: 'PE-VAL-001',
    429: 'PE-RATE-001',
    500: 'PE-INT-001',
    502: 'PE-EXT-001',
    503: 'PE-INT-003',
    504: 'PE-EXT-002',
  };

  return codeMap[status] ?? 'PE-INT-001';
}
