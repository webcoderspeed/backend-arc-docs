import { HttpException, HttpStatus } from '@nestjs/common';

import { PostEngageException } from '../core/postengage.exception';
import type { PostEngageErrorResponse } from '../types/error-response.types';
import { ErrorType } from '../types/error-code.types';
import { ErrorSanitizer } from '../sanitizers/error-sanitizer';
import { MongooseErrorHandler } from '../handlers/mongoose-error.handler';
import { ThrottlerErrorHandler } from '../handlers/throttler-error.handler';
import { getErrorMessage } from './error-message.utilities';
import {
  httpStatusToErrorType,
  httpStatusToErrorCode,
} from './http-status.mapper';

export interface BuildErrorParams {
  exception: unknown;
  requestId: string;
  path: string;
  service?: string;
  startTime?: number;
}

export interface BuildErrorResult {
  response: PostEngageErrorResponse;
  httpStatus: number;
}

/**
 * ErrorResponseBuilder — the single function that builds a PostEngageErrorResponse
 * from any exception type.
 *
 * Priority order:
 * 1. PostEngageException → use its error code, type, details, param
 * 2. Mongoose error → MongooseErrorHandler → PostEngageException
 * 3. ThrottlerException → PE-RATE-001
 * 4. HttpException → map status to ErrorType + generic code
 * 5. Unknown → PE-INT-001
 */
export class ErrorResponseBuilder {
  static build(params: BuildErrorParams): BuildErrorResult {
    const { exception, requestId, path, service, startTime } = params;

    // 1. Already a PostEngageException — use directly
    if (exception instanceof PostEngageException) {
      return this.fromPostEngageException(
        exception,
        requestId,
        path,
        service,
        startTime,
      );
    }

    // 2. Try Mongoose handler
    const mongooseResult = MongooseErrorHandler.handle(exception);
    if (mongooseResult) {
      return this.fromPostEngageException(
        mongooseResult,
        requestId,
        path,
        service,
        startTime,
      );
    }

    // 3. Try Throttler handler
    const throttlerResult = ThrottlerErrorHandler.handle(exception);
    if (throttlerResult) {
      return this.fromPostEngageException(
        throttlerResult,
        requestId,
        path,
        service,
        startTime,
      );
    }

    // 4. Generic HttpException
    if (exception instanceof HttpException) {
      return this.fromHttpException(
        exception,
        requestId,
        path,
        service,
        startTime,
      );
    }

    // 5. Unknown error — PE-INT-001
    return this.fromUnknownError(
      exception,
      requestId,
      path,
      service,
      startTime,
    );
  }

  private static fromPostEngageException(
    exception: PostEngageException,
    requestId: string,
    path: string,
    service?: string,
    startTime?: number,
  ): BuildErrorResult {
    const httpStatus = exception.getStatus();

    const response: PostEngageErrorResponse = {
      success: false,
      error: {
        type: exception.errorType,
        code: exception.errorCode,
        message: ErrorSanitizer.sanitizeMessage(exception.message),
        ...(exception.param && { param: exception.param }),
        ...(exception.details &&
          exception.details.length > 0 && { details: exception.details }),
        ...(exception.definition.docUrl && {
          doc_url: exception.definition.docUrl,
        }),
      },
      meta: {
        request_id: requestId,
        timestamp: new Date().toISOString(),
        path,
        status: httpStatus,
      },
      debug: ErrorSanitizer.buildDebugInfo(exception, service, startTime),
    };

    return { response, httpStatus };
  }

  private static fromHttpException(
    exception: HttpException,
    requestId: string,
    path: string,
    service?: string,
    startTime?: number,
  ): BuildErrorResult {
    const httpStatus = exception.getStatus();
    const message = getErrorMessage(exception);

    const response: PostEngageErrorResponse = {
      success: false,
      error: {
        type: httpStatusToErrorType(httpStatus),
        code: httpStatusToErrorCode(httpStatus),
        message: ErrorSanitizer.sanitizeMessage(message),
      },
      meta: {
        request_id: requestId,
        timestamp: new Date().toISOString(),
        path,
        status: httpStatus,
      },
      debug: ErrorSanitizer.buildDebugInfo(exception, service, startTime),
    };

    return { response, httpStatus };
  }

  private static fromUnknownError(
    exception: unknown,
    requestId: string,
    path: string,
    service?: string,
    startTime?: number,
  ): BuildErrorResult {
    const httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

    const response: PostEngageErrorResponse = {
      success: false,
      error: {
        type: ErrorType.SERVER,
        code: 'PE-INT-001',
        message: 'An unexpected error occurred.',
      },
      meta: {
        request_id: requestId,
        timestamp: new Date().toISOString(),
        path,
        status: httpStatus,
      },
      debug: ErrorSanitizer.buildDebugInfo(exception, service, startTime),
    };

    return { response, httpStatus };
  }
}
