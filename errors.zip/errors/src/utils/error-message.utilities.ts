import { HttpException } from '@nestjs/common';

/**
 * Error info extracted from any error type
 */
export interface ErrorInfo {
  message: string;
  stack?: string;
}

/**
 * Extract a human-readable message from any error type.
 * Handles: HttpException, Error, string, objects with message/error.
 */
export function getErrorMessage(error: unknown): string {
  return getErrorInfo(error).message;
}

/**
 * Extract message + stack from any error type.
 */
export function getErrorInfo(error: unknown): ErrorInfo {
  if (error instanceof HttpException) {
    return extractHttpExceptionInfo(error);
  }

  if (error instanceof Error) {
    return { message: error.message, stack: error.stack };
  }

  if (typeof error === 'string') {
    return { message: error };
  }

  if (error && typeof error === 'object' && 'message' in error) {
    return extractObjectMessage(error);
  }

  return { message: 'An unexpected error occurred.' };
}

function extractHttpExceptionInfo(exception: HttpException): ErrorInfo {
  const response = exception.getResponse();
  const message = extractMessageFromResponse(response, exception.message);
  return { message, stack: exception.stack };
}

function extractMessageFromResponse(
  response: unknown,
  fallback: string,
): string {
  if (typeof response === 'string') {
    return response;
  }

  if (
    typeof response === 'object' &&
    response !== null &&
    'message' in response
  ) {
    const responseObject = response as Record<string, unknown>;
    const message = responseObject.message;

    if (Array.isArray(message)) {
      return (message as string[]).join(', ');
    }

    return String(message);
  }

  return fallback;
}

function extractObjectMessage(error: unknown): ErrorInfo {
  const errorObject = error as Record<string, unknown>;
  const message = String(errorObject.message);
  const stack = 'stack' in errorObject ? String(errorObject.stack) : undefined;
  return { message, stack };
}

/**
 * Extract the stack trace from any error type.
 */
export function getErrorStack(error: unknown): string | undefined {
  return getErrorInfo(error).stack;
}
