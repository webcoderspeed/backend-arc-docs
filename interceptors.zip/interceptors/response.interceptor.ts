import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  HttpStatus,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import type { Request, Response } from 'express';
import { ulid } from 'ulid';
import {
  PaginationResult,
  CursorPaginationResult,
} from '../utils/pagination.utility';
import {
  RESPONSE_CONSTANTS,
  type ResponseMeta,
} from '../contracts/responses/base.response';
import {
  CREATED_RESPONSE_MARKER,
  type CreatedResponseMarker,
} from '../contracts/responses/created.response';
import {
  ACCEPTED_RESPONSE_MARKER,
  type AcceptedResponseMarker,
} from '../contracts/responses/accepted.response';
import {
  NO_CONTENT_MARKER,
  type NoContentMarker,
} from '../contracts/responses/no-content.response';
import {
  MULTI_STATUS_MARKER,
  type MultiStatusMarker,
} from '../contracts/responses/multi-status.response';
import type { SuccessResponse } from '../contracts/responses/success.response';
import type { CreatedResponse } from '../contracts/responses/created.response';
import type { AcceptedResponse } from '../contracts/responses/accepted.response';
import type { MultiStatusResponse } from '../contracts/responses/multi-status.response';
import type {
  PaginatedResponse,
  CursorPaginatedResponse,
} from '../contracts/responses/paginated.response';

// ─── Union of all possible response shapes ──────────────────────────────

type ApiResponse<T> =
  | SuccessResponse<T>
  | CreatedResponse<T>
  | AcceptedResponse
  | MultiStatusResponse<T>
  | PaginatedResponse<T>
  | CursorPaginatedResponse<T>
  | undefined; // 204 No Content

// ─── Re-export legacy interfaces for backward compatibility ─────────────

export type { ResponseMeta } from '../contracts/responses/base.response';

export type ApiSuccessResponse<T> = SuccessResponse<T>;
export type ApiPaginatedResponse<T> = PaginatedResponse<T>;
export type ApiCursorPaginatedResponse<T> = CursorPaginatedResponse<T>;

// ─── Response Interceptor (SUCCESS ONLY) ─────────────────────────────────
// Errors are handled exclusively by GlobalExceptionFilter.
// This interceptor wraps successful responses in the standard envelope
// and handles all response type variants: 200, 201, 202, 204, 207.

@Injectable()
export class ResponseInterceptor<T> implements NestInterceptor<
  T,
  ApiResponse<T>
> {
  intercept(
    context: ExecutionContext,
    next: CallHandler<T>,
  ): Observable<ApiResponse<T>> {
    const context_ = context.switchToHttp();
    const request = context_.getRequest<
      Request & { id?: string; startTime?: number }
    >();
    const response = context_.getResponse<Response>();

    // Bypass interceptor for webhook endpoints
    if (request.url.toLowerCase().includes('webhook')) {
      return next.handle() as unknown as Observable<ApiResponse<T>>;
    }

    // Track response time
    const startTime = Date.now();

    const requestId =
      (request.id as string) ||
      (request.headers[
        RESPONSE_CONSTANTS.HEADERS.REQUEST_ID.toLowerCase()
      ] as string) ||
      this.generateRequestId();

    // Set standard response headers
    response.setHeader(RESPONSE_CONSTANTS.HEADERS.REQUEST_ID, requestId);
    response.setHeader(
      RESPONSE_CONSTANTS.HEADERS.API_VERSION,
      RESPONSE_CONSTANTS.API_VERSION,
    );

    return next.handle().pipe(
      map((data) => {
        // Set response time header
        response.setHeader(
          RESPONSE_CONSTANTS.HEADERS.RESPONSE_TIME,
          `${Date.now() - startTime}ms`,
        );

        return this.formatResponse(data, requestId, request, response);
      }),
    );
  }

  // ─── Response Formatting (detects markers and formats accordingly) ──

  private formatResponse(
    data: unknown,
    requestId: string,
    request: Request,
    response: Response,
  ): ApiResponse<T> {
    const meta: ResponseMeta = {
      request_id: requestId,
      timestamp: new Date().toISOString(),
      api_version: RESPONSE_CONSTANTS.API_VERSION,
      path: request.url,
      status: response.statusCode,
    };

    // ─── 204 No Content ──────────────────────────────────────────
    if (this.isNoContentMarker(data)) {
      response.status(HttpStatus.NO_CONTENT);
      return undefined;
    }

    // ─── 201 Created ─────────────────────────────────────────────
    if (this.isCreatedMarker(data)) {
      response.status(HttpStatus.CREATED);
      response.setHeader(RESPONSE_CONSTANTS.HEADERS.LOCATION, data.location);
      meta.status = HttpStatus.CREATED;

      return {
        success: true,
        data: data.data as T,
        meta: {
          ...meta,
          location: data.location,
        },
      } as CreatedResponse<T>;
    }

    // ─── 202 Accepted ────────────────────────────────────────────
    if (this.isAcceptedMarker(data)) {
      response.status(HttpStatus.ACCEPTED);
      response.setHeader(RESPONSE_CONSTANTS.HEADERS.LOCATION, data.status_url);
      response.setHeader(RESPONSE_CONSTANTS.HEADERS.RETRY_AFTER, '5');
      meta.status = HttpStatus.ACCEPTED;

      return {
        success: true,
        data: {
          job_id: data.job_id,
          status: 'queued' as const,
          status_url: data.status_url,
          estimated_completion: data.estimated_completion,
        },
        meta,
      } as AcceptedResponse;
    }

    // ─── 207 Multi-Status ────────────────────────────────────────
    if (this.isMultiStatusMarker(data)) {
      response.status(207);
      meta.status = 207;

      const succeeded = data.results.filter(
        (r) => r.status >= 200 && r.status < 300,
      ).length;
      const failed = data.results.length - succeeded;

      return {
        success: true,
        data: {
          total: data.results.length,
          succeeded,
          failed,
          results: data.results,
        },
        meta,
      } as MultiStatusResponse<T>;
    }

    // ─── Paginated (offset-based) ────────────────────────────────
    if (this.isPaginationResult(data)) {
      return {
        success: true,
        data: data.data as T[],
        pagination: data.pagination,
        meta,
      } as PaginatedResponse<T>;
    }

    // ─── Paginated (cursor-based) ────────────────────────────────
    if (this.isCursorPaginationResult(data)) {
      return {
        success: true,
        data: data.data as T[],
        pagination: data.pagination,
        meta,
      } as CursorPaginatedResponse<T>;
    }

    // ─── null/undefined → standard success with null data ────────
    if (data === null || data === undefined) {
      return {
        success: true,
        data: null as T,
        meta,
      };
    }

    // ─── 200 OK — Standard success ──────────────────────────────
    return {
      success: true,
      data: data as T,
      meta,
    };
  }

  // ─── Marker Type Guards ──────────────────────────────────────────────

  private isNoContentMarker(data: unknown): data is NoContentMarker {
    return (
      data !== null &&
      data !== undefined &&
      typeof data === 'object' &&
      NO_CONTENT_MARKER in (data as Record<symbol, unknown>)
    );
  }

  private isCreatedMarker(
    data: unknown,
  ): data is CreatedResponseMarker<unknown> {
    return (
      data !== null &&
      data !== undefined &&
      typeof data === 'object' &&
      CREATED_RESPONSE_MARKER in (data as Record<symbol, unknown>)
    );
  }

  private isAcceptedMarker(data: unknown): data is AcceptedResponseMarker {
    return (
      data !== null &&
      data !== undefined &&
      typeof data === 'object' &&
      ACCEPTED_RESPONSE_MARKER in (data as Record<symbol, unknown>)
    );
  }

  private isMultiStatusMarker(
    data: unknown,
  ): data is MultiStatusMarker<unknown> {
    return (
      data !== null &&
      data !== undefined &&
      typeof data === 'object' &&
      MULTI_STATUS_MARKER in (data as Record<symbol, unknown>)
    );
  }

  // ─── Pagination Type Guards ──────────────────────────────────────────

  private isPaginationResult(data: unknown): data is PaginationResult<unknown> {
    if (!data || typeof data !== 'object' || data === null) return false;
    const p = data as Record<string, unknown>;

    return (
      'data' in p &&
      'pagination' in p &&
      Array.isArray(p.data) &&
      typeof p.pagination === 'object' &&
      p.pagination !== null &&
      'total' in (p.pagination as Record<string, unknown>) &&
      'page' in (p.pagination as Record<string, unknown>) &&
      'per_page' in (p.pagination as Record<string, unknown>)
    );
  }

  private isCursorPaginationResult(
    data: unknown,
  ): data is CursorPaginationResult<unknown> {
    if (!data || typeof data !== 'object' || data === null) return false;
    const p = data as Record<string, unknown>;

    return (
      'data' in p &&
      'pagination' in p &&
      Array.isArray(p.data) &&
      typeof p.pagination === 'object' &&
      p.pagination !== null &&
      'limit' in (p.pagination as Record<string, unknown>) &&
      ('next_cursor' in (p.pagination as Record<string, unknown>) ||
        'previous_cursor' in (p.pagination as Record<string, unknown>))
    );
  }

  // ─── Utilities ─────────────────────────────────────────────────────

  private generateRequestId(): string {
    return `${RESPONSE_CONSTANTS.REQUEST_ID_PREFIX}${ulid()}`;
  }
}
