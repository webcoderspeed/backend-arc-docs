// ─── ETag Interceptor ──────────────────────────────────────────────────
// Generates an ETag from the response body hash and supports conditional
// requests via If-None-Match → 304 Not Modified.
//
// Only applies to GET requests. Returns 304 with no body when the client
// sends a matching ETag, saving bandwidth and processing.
//
// Usage:
//   @Get('profile')
//   @UseInterceptors(ETagInterceptor)
//   async getProfile() { ... }

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  HttpStatus,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { createHash } from 'node:crypto';
import type { Request, Response } from 'express';
import { RESPONSE_CONSTANTS } from '../contracts/responses/base.response';

@Injectable()
export class ETagInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<Request>();
    const response = context.switchToHttp().getResponse<Response>();

    // Only generate ETags for GET requests
    if (request.method !== 'GET') {
      return next.handle();
    }

    return next.handle().pipe(
      map((data) => {
        // Generate ETag from response body hash
        const etag = this.generateETag(data);
        response.setHeader(RESPONSE_CONSTANTS.HEADERS.ETAG, `"${etag}"`);

        // Always set Vary header for proper caching
        response.setHeader(
          RESPONSE_CONSTANTS.HEADERS.VARY,
          'Accept, Authorization',
        );

        // Check If-None-Match header
        const ifNoneMatch = request.headers[
          RESPONSE_CONSTANTS.HEADERS.IF_NONE_MATCH.toLowerCase()
        ] as string;

        if (ifNoneMatch && ifNoneMatch === `"${etag}"`) {
          // Client has the same version — return 304 with no body
          response.status(HttpStatus.NOT_MODIFIED);
          return undefined;
        }

        return data as unknown;
      }),
    );
  }

  /**
   * Generate a short MD5 hash from the response body.
   * Using MD5 is fine here — this is not security-sensitive, just cache validation.
   */
  private generateETag(data: unknown): string {
    const hash = createHash('md5')
      .update(JSON.stringify(data))
      .digest('hex')
      .substring(0, 16);
    return hash;
  }
}
