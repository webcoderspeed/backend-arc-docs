// ─── Field Selection Interceptor ───────────────────────────────────────
// Supports sparse fieldsets via `?fields=id,name,status`.
// Strips all fields from the response data except those requested.
// Always includes 'id' and '_id' fields.
//
// Usage: GET /api/v1/automations?fields=id,name,status,platform
//
// Works with both single-object and paginated (array) responses.
// Operates AFTER the ResponseInterceptor wraps the response.

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import type { Request } from 'express';

@Injectable()
export class FieldSelectionInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<Request>();
    const fieldsParameter = request.query.fields as string | undefined;

    // No fields param → return full response
    if (!fieldsParameter) {
      return next.handle();
    }

    const fields = fieldsParameter
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f.length > 0);

    if (fields.length === 0) {
      return next.handle();
    }

    return next.handle().pipe(
      map((data) => {
        if (!data || typeof data !== 'object') return data as unknown;

        const response = data as Record<string, unknown>;

        // Paginated response: filter each item in data array
        if (Array.isArray(response.data)) {
          return {
            ...response,
            data: response.data.map((item: unknown) => this.pick(item, fields)),
          };
        }

        // Single resource response: filter the data object
        if (response.data && typeof response.data === 'object') {
          return {
            ...response,
            data: this.pick(response.data, fields),
          };
        }

        return data as unknown;
      }),
    );
  }

  /**
   * Pick only specified fields from an object.
   * Always includes 'id' and '_id' fields.
   */
  private pick(object: unknown, fields: string[]): Record<string, unknown> {
    if (!object || typeof object !== 'object')
      return object as Record<string, unknown>;

    const source = object as Record<string, unknown>;
    const result: Record<string, unknown> = {};

    // Always include identifiers
    const allFields = new Set(['id', '_id', ...fields]);

    for (const field of allFields) {
      if (field in source) {
        result[field] = source[field];
      }
    }

    return result;
  }
}
