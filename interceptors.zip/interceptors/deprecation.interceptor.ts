// ─── Deprecation Interceptor ───────────────────────────────────────────
// Reads @Deprecated() metadata and sets deprecation headers on the response.
// Register globally or per-controller.

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import type { Response } from 'express';
import {
  DEPRECATED_KEY,
  type DeprecatedOptions,
  buildDeprecationHeaders,
} from '../decorators/deprecated.decorator';

@Injectable()
export class DeprecationInterceptor implements NestInterceptor {
  constructor(private readonly reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const deprecatedOptions = this.reflector.get<DeprecatedOptions | undefined>(
      DEPRECATED_KEY,
      context.getHandler(),
    );

    if (!deprecatedOptions) {
      return next.handle();
    }

    const response = context.switchToHttp().getResponse<Response>();
    const headers = buildDeprecationHeaders(deprecatedOptions);

    for (const [key, value] of Object.entries(headers)) {
      response.setHeader(key, value);
    }

    return next.handle();
  }
}
