// ─── Rate Limit Headers Interceptor ────────────────────────────────────
// Exposes rate limit state on every HTTP response.
// Reads from the existing RateLimitingService (Redis-backed) and sets:
//   X-RateLimit-Limit     → max requests in the current window
//   X-RateLimit-Remaining → requests remaining before throttling
//   X-RateLimit-Reset     → UNIX timestamp when the window resets
//
// When the client is throttled (429), also sets Retry-After header.

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable, from } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import type { Request, Response } from 'express';
import { RateLimitingService } from '../rate-limiting/rate-limiting.service';
import { RESPONSE_CONSTANTS } from '../contracts/responses/base.response';
import { APP_CONSTANTS } from '../constants/app.constants';

/** Default max requests per window (from APP_CONSTANTS) */
const DEFAULT_MAX_REQUESTS = APP_CONSTANTS.RATE_LIMIT_MAX_REQUESTS;

@Injectable()
export class RateLimitHeadersInterceptor implements NestInterceptor {
  private readonly logger = new Logger(RateLimitHeadersInterceptor.name);

  constructor(private readonly rateLimitingService: RateLimitingService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const httpContext = context.switchToHttp();
    const request = httpContext.getRequest<
      Request & { user?: { sub?: string } }
    >();
    const response = httpContext.getResponse<Response>();

    // Build rate limit key: user ID + IP
    const userId = request.user?.sub ?? 'anonymous';
    const rateLimitKey = `${userId}:${String(request.ip)}`;

    return next.handle().pipe(
      switchMap((data) => {
        return from(this.setRateLimitHeaders(data, rateLimitKey, response));
      }),
    );
  }

  /**
   * Set rate limit headers on the response, then return original data.
   */
  private async setRateLimitHeaders(
    data: unknown,
    rateLimitKey: string,
    response: Response,
  ): Promise<unknown> {
    try {
      const remaining = await this.rateLimitingService.getRemainingAttempts(
        rateLimitKey,
        DEFAULT_MAX_REQUESTS,
      );

      const resetMs =
        await this.rateLimitingService.getTimeUntilReset(rateLimitKey);

      const resetTimestamp = Math.ceil((Date.now() + resetMs) / 1000);

      // Set rate limit headers
      response.setHeader(
        RESPONSE_CONSTANTS.HEADERS.RATE_LIMIT_LIMIT,
        String(DEFAULT_MAX_REQUESTS),
      );
      response.setHeader(
        RESPONSE_CONSTANTS.HEADERS.RATE_LIMIT_REMAINING,
        String(remaining),
      );
      response.setHeader(
        RESPONSE_CONSTANTS.HEADERS.RATE_LIMIT_RESET,
        String(resetTimestamp),
      );

      // If rate limited (remaining is 0 and status is 429), add Retry-After
      if (remaining <= 0 && response.statusCode === 429) {
        const retryAfterSeconds = Math.ceil(resetMs / 1000);
        response.setHeader(
          RESPONSE_CONSTANTS.HEADERS.RETRY_AFTER,
          String(retryAfterSeconds),
        );
      }
    } catch (error) {
      // Fail silently — missing rate limit headers is better than crashing
      this.logger.warn(
        'Failed to set rate limit headers',
        error instanceof Error ? error.message : String(error),
      );
    }

    return data;
  }
}
